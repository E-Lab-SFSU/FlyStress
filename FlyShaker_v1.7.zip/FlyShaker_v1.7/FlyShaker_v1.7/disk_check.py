"""Free-space pre-flight check for the experiment save destination (no GUI imports)."""
from __future__ import annotations

import math
import shutil
from pathlib import Path

# ESTIMATES - tune after looking at real file sizes in an experiment's frames/ folder.
# 1280x800 PNGs from a USB camera are typically ~1-2 MB; 2 MB is deliberately conservative.
EST_BYTES_PER_IMAGE = 2_000_000
OVERHEAD_FACTOR = 1.10        # video, CSVs, plots, calibration files
RESERVE_BYTES = 1_000_000_000  # always leave ~1 GB free on the drive


def fmt_bytes(n: float) -> str:
    n = float(n)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(n) < 1000 or unit == "TB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1000.0


def nearest_existing_parent(path) -> Path:
    """First existing ancestor of path. Raises OSError for a dangling link (e.g. an unmounted
    external drive), because measuring a parent folder would silently report the wrong disk."""
    p = Path(path).expanduser().absolute()
    while True:
        if p.is_symlink() and not p.exists():
            raise OSError(f"{p} is a link to a location that is not available. "
                          "Is the external drive connected and mounted?")
        if p.exists():
            return p
        if p.parent == p:
            raise OSError(f"No part of {path} exists on this computer.")
        p = p.parent


def estimate_required_bytes(images_per_second: float, session_s: float, initiation_s: float):
    images = math.ceil((float(session_s) + float(initiation_s)) * float(images_per_second))
    return int(images * EST_BYTES_PER_IMAGE * OVERHEAD_FACTOR + RESERVE_BYTES), images


def check_free_space(root, images_per_second, session_s, initiation_s):
    """Return (ok, required_bytes, free_bytes, checked_path, image_count). May raise OSError."""
    where = nearest_existing_parent(root)
    free = shutil.disk_usage(where).free
    required, images = estimate_required_bytes(images_per_second, session_s, initiation_s)
    return free >= required, required, free, where, images
