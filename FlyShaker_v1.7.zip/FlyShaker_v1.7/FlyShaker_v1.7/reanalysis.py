"""At-home analysis: run the CAMS pipeline on a finished experiment folder. No GUI imports.

Uses only <folder>/frames (initiation_frames is ignored). Every output goes to a new
<folder>/reanalysis_<timestamp>/ directory, so the original data and results are never touched.
"""
from __future__ import annotations

import csv
import shutil
import statistics
from datetime import datetime
from pathlib import Path

from cams.shake_frames import (buffer_seconds_from_settings, burst_seconds_from_settings, list_frames,
                               load_settings, load_windows)
from calibration_tools import (complete_counts, copy_grid, copy_thresholds, uncalibrated_wells,
                               wells_csv_in)
from config_writer import write_cams_config
from live_engine import LiveSleepEngine, replay_frames
from timestamp_sync import build_alignment
from video_tools import make_video

CALIBRATION_SAVED = "saved"   # grid + thresholds + counts stored in the experiment folder itself
CALIBRATION_OTHER = "other"   # grid + thresholds from a different experiment (counts reset)
CALIBRATION_NEW = "new"       # draw grid / pick thresholds with the CAMS tuners on this experiment's frames


class ReanalysisError(Exception):
    pass


def _single(folder: Path, pattern: str):
    matches = sorted(folder.glob(pattern))
    return matches[0] if len(matches) == 1 else None


def detect_frame_rate(folder: Path):
    """images/second from image_timestamps_*.csv (median spacing). Returns (ips, notes)."""
    csv_path = _single(folder, "image_timestamps_*.csv")
    if csv_path is None:
        return 1.0, ["No image_timestamps CSV found; assuming 1 image/second."]
    with csv_path.open(newline="", encoding="utf-8") as f:
        stamps = [datetime.fromisoformat(r["timestamp"]).timestamp() for r in csv.DictReader(f) if r.get("timestamp")]
    if len(stamps) < 3:
        return 1.0, ["Too few timestamps to measure the frame rate; assuming 1 image/second."]
    gaps = [b - a for a, b in zip(stamps, stamps[1:])]
    median = statistics.median(gaps)
    ips = 1.0 / median if median > 0 else 1.0
    if abs(ips - 1.0) < 0.02:
        ips = 1.0
    notes = [f"Frame rate from timestamps: {ips:.3f} images/second."]
    big = sum(g > 1.5 * median for g in gaps)
    if big:
        notes.append(f"WARNING: {big} gaps longer than 1.5x the normal spacing (longest {max(gaps):.1f} s). "
                     "CAMS assumes evenly spaced frames, so times after a gap are slightly shifted.")
    return ips, notes


def run_reanalysis(folder, cams_dir, calibration, source, create_video, run_script,
                   ask_retune, log=print, stage=lambda text: None) -> Path:
    """Run the pipeline; returns the reanalysis output folder.

    run_script(name): run a CAMS script, raising on failure.
    ask_retune(n_wells) -> bool: some wells still have threshold 0 after the tuner; reopen it?
    """
    folder, cams_dir = Path(folder), Path(cams_dir)
    frames = folder / "frames"
    n_frames = len(list(frames.glob("*.png"))) if frames.is_dir() else 0
    if n_frames < 2:
        raise ReanalysisError(
            f"{folder} has no usable frames/ folder (found {n_frames} images).\n"
            "Choose an experiment folder created by this program (version 2 or later).")
    ips, notes = detect_frame_rate(folder)
    for n in notes:
        log(n)

    out = folder / f"reanalysis_{datetime.now():%Y%m%d_%H%M%S}"
    out.mkdir()
    name = folder.name
    write_cams_config(cams_dir, folder, ips, frames_subdir="frames", output_dir=out)
    wells_out, thr_out = out / f"plate_wells_{name}.csv", out / "well_threshold.csv"
    clean_frames = len(list_frames(frames))
    windows = load_windows(folder)
    info = [f"Re-analysis of {folder}", f"Created {datetime.now().isoformat(timespec='seconds')}",
            f"Frames analysed: {clean_frames} of {n_frames} (initiation_frames ignored; "
            f"{n_frames - clean_frames} shaking frames excluded)", *notes]
    if windows.sequence_starts and not windows.windows():
        msg = ("WARNING: the shaker log has SEQUENCE_START events but no burst windows were recognized, "
               "so no shaking frames were excluded. See cams/shake_frames.py.")
        log(msg)
        info.append(msg)
    if not (folder / "experiment_settings.json").exists():
        info.append("Note: no experiment_settings.json (older experiment); bursts without a logged end "
                    "or duration cannot be flagged.")

    background = folder / "median_background.png"
    if background.exists():
        shutil.copy2(background, out / "median_background.png")
        log("Using the median background saved with the experiment.")
        info.append("Background: copied from the original experiment.")
    else:
        info.append("Background: computed from random frames of this experiment.")

    # ------------------------------------------------------------ calibration
    if calibration == CALIBRATION_NEW:
        info.append("Calibration: new (tuners run on this experiment's frames).")
        stage("well grid tuner")
        run_script("well_grid_tuner.py")
    else:
        src = folder if calibration == CALIBRATION_SAVED else Path(source or "")
        if wells_csv_in(src) is None:
            raise ReanalysisError(
                f"No saved well grid (plate_wells_*.csv) in {src}.\nChoose 'Calibrate new' instead.")
        copy_grid(src, out, name)
        if (src / "well_threshold.csv").exists():
            same = calibration == CALIBRATION_SAVED
            copy_thresholds(src, out, reset_counts=not same, keep_exclusions=same)
        info.append(f"Calibration: {'saved with this experiment' if calibration == CALIBRATION_SAVED else 'copied from ' + str(src)}.")
        log(f"Calibration copied from {src}.")

    stage("measuring activity")
    run_script("measure_activity.py")

    while not thr_out.exists() or uncalibrated_wells(thr_out):
        stage("motion threshold tuner")
        run_script("motion_threshold_tuner.py")
        left = uncalibrated_wells(thr_out) if thr_out.exists() else ["?"]
        if left and not ask_retune(len(left)):
            raise ReanalysisError(f"{len(left)} wells still have threshold 0 (calibrate or mark them -1).")
    filled = complete_counts(thr_out)
    if filled["filled"]:
        log(f"Filled {filled['filled']} blank fly_count/viable_flies cells (1 per calibrated well, 0 for excluded wells).")
        info.append("fly_count/viable_flies: blanks filled with defaults (1 per calibrated well; 0 for excluded).")

    # ------------------------------------------------------------ analysis + outputs
    stage("classifying sleep")
    run_script("classify_sleep.py")
    stage("first/last comparison")
    run_script("compare_first_last.py")
    stage("plots")
    run_script("generate_plots.py")

    image_csv = _single(folder, "image_timestamps_*.csv")
    shaker_csv = _single(folder, "shaker_timestamps_*.csv")
    if image_csv and shaker_csv:
        build_alignment(image_csv, shaker_csv, out / "image_shaker_alignment.csv", 3.0)
    stage("sleep timer")
    engine = LiveSleepEngine.from_cams_config(cams_dir)
    if shaker_csv:
        settings = load_settings(folder)
        engine.set_shaker_log(shaker_csv, burst_seconds_from_settings(settings), buffer_seconds_from_settings(settings))
    engine.attach_csv(out / "sleep_timer.csv")
    try:
        replay_frames(engine, frames, image_csv)
    finally:
        engine.close()
    if create_video:
        stage("video")
        make_video(frames, out / "experiment.mp4", ips, log)
    (out / "reanalysis_info.txt").write_text("\n".join(info) + "\n", encoding="utf-8")
    stage("complete")
    return out
