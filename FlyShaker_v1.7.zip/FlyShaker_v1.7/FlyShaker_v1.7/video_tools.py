"""Experiment video creation (no GUI imports)."""
from __future__ import annotations

from pathlib import Path

import cv2

# Images are saved at 1/s: <=1800 images real time, >1800 (30 min) 2x, >7200 (2 h) 3x
VIDEO_X2_AFTER_IMAGES = 1800
VIDEO_X3_AFTER_IMAGES = 7200


def video_speed(image_count: int) -> int:
    if image_count > VIDEO_X3_AFTER_IMAGES:
        return 3      # > 2 h: time-lapse one third of real-time length
    if image_count > VIDEO_X2_AFTER_IMAGES:
        return 2      # > 30 min: 2x
    return 1


def make_video(frames_dir, out_path, images_per_second, log=None):
    """Build the mp4 from a frames folder. Returns the speed factor used (or None if no frames)."""
    from img_to_vid import create_video  # compatibility module with create_video()
    from cams.shake_frames import frame_number
    images = sorted(Path(frames_dir).glob("*.png"), key=lambda x: (frame_number(x), x.name))
    if not images:
        return None
    first = cv2.imread(str(images[0]))
    if first is None:
        return None
    h, w = first.shape[:2]
    speed = video_speed(len(images))
    frame_duration = 1.0 / (float(images_per_second) * speed)   # playback fps = ips * speed
    if log:
        log(f"Creating video from {len(images)} images at {speed}x speed...")
    create_video(images, Path(out_path), frame_duration=frame_duration, width=w, height=h)
    return speed
