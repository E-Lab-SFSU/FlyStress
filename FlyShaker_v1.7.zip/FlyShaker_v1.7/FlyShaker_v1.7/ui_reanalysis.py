"""Dialog for at-home analysis of a finished experiment folder."""
from __future__ import annotations

import subprocess
import sys
import threading
from pathlib import Path

from PyQt6.QtCore import QObject, Qt, pyqtSignal
from PyQt6.QtWidgets import (QCheckBox, QComboBox, QDialog, QFileDialog, QHBoxLayout, QLabel, QLineEdit,
                             QMessageBox, QPlainTextEdit, QPushButton, QVBoxLayout)

from calibration_tools import check_source, find_latest_calibration, wells_csv_in
from reanalysis import (CALIBRATION_NEW, CALIBRATION_OTHER, CALIBRATION_SAVED, ReanalysisError,
                        run_reanalysis)


class _Signals(QObject):
    log = pyqtSignal(str)
    stage = pyqtSignal(str)
    done = pyqtSignal(str)
    failed = pyqtSignal(str)
    ask = pyqtSignal(object)      # run a callable on the GUI thread


class ReanalysisDialog(QDialog):
    def __init__(self, experiment_root: Path, cams_dir: Path, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Analyze existing experiment")
        self.setMinimumWidth(640)
        self.root, self.cams_dir = Path(experiment_root), Path(cams_dir)
        self.proc = None
        self.running = False
        self._closing = False
        self.sig = _Signals()
        self.sig.log.connect(self._append)
        self.sig.stage.connect(lambda t: self.status.setText("Stage: " + t))
        self.sig.done.connect(self._done)
        self.sig.failed.connect(self._failed)
        self.sig.ask.connect(lambda fn: fn())

        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("Runs the CAMS pipeline on an experiment folder's frames/ (initiation images are ignored).\n"
                             "Results go to a new reanalysis_<time> folder inside it; the original files are not changed."))
        row = QHBoxLayout()
        self.folder = QLineEdit(); self.folder.setPlaceholderText("Experiment folder (e.g. .../exp00007)")
        b = QPushButton("Browse..."); b.clicked.connect(self._browse_folder)
        row.addWidget(self.folder, 1); row.addWidget(b); lay.addLayout(row)

        self.mode = QComboBox()
        self.mode.addItem("Use the calibration saved in this experiment", CALIBRATION_SAVED)
        self.mode.addItem("Use grid + thresholds from another experiment", CALIBRATION_OTHER)
        self.mode.addItem("Calibrate new (tuners on this experiment's frames)", CALIBRATION_NEW)
        self.mode.currentIndexChanged.connect(self._mode_changed)
        lay.addWidget(self.mode)
        row = QHBoxLayout()
        self.source = QLineEdit(); self.source.setPlaceholderText("Calibration source experiment folder")
        latest = find_latest_calibration(self.root)
        if latest:
            self.source.setText(str(latest))
        self.src_btn = QPushButton("Browse..."); self.src_btn.clicked.connect(self._browse_source)
        row.addWidget(self.source, 1); row.addWidget(self.src_btn); lay.addLayout(row)
        self.video = QCheckBox("Also create the experiment video (slow for long experiments)")
        lay.addWidget(self.video)

        self.log = QPlainTextEdit(); self.log.setReadOnly(True); self.log.setMinimumHeight(180)
        lay.addWidget(self.log)
        self.status = QLabel("Stage: idle"); lay.addWidget(self.status)
        row = QHBoxLayout()
        self.run_btn = QPushButton("Run analysis"); self.run_btn.clicked.connect(self._run)
        self.close_btn = QPushButton("Close"); self.close_btn.clicked.connect(self.close)
        row.addStretch(1); row.addWidget(self.run_btn); row.addWidget(self.close_btn); lay.addLayout(row)
        self._mode_changed()

    # ------------------------------------------------------------------ ui helpers
    def _append(self, text):
        self.log.appendPlainText(str(text))

    def _mode_changed(self):
        other = self.mode.currentData() == CALIBRATION_OTHER
        self.source.setEnabled(other)
        self.src_btn.setEnabled(other)

    def _browse_folder(self):
        d = QFileDialog.getExistingDirectory(self, "Select experiment folder", str(self.root))
        if d:
            self.folder.setText(d)
            saved = wells_csv_in(d) is not None
            self.mode.setCurrentIndex(0 if saved else 2)

    def _browse_source(self):
        d = QFileDialog.getExistingDirectory(self, "Select calibration source experiment", str(self.root))
        if d:
            self.source.setText(d)

    def _on_gui(self, fn):
        """Run fn on the GUI thread from the worker thread and return its result."""
        box, done = {}, threading.Event()
        def call():
            box["v"] = fn()
            done.set()
        self.sig.ask.emit(call)
        done.wait()
        return box["v"]

    # ------------------------------------------------------------------ run
    def _run(self):
        folder = Path(self.folder.text().strip())
        if not folder.is_dir():
            QMessageBox.warning(self, "Analyze experiment", "Choose an experiment folder first.")
            return
        mode = self.mode.currentData()
        source = None
        if mode == CALIBRATION_OTHER:
            source = Path(self.source.text().strip())
            ok, msg = check_source(source, need_thresholds=False)
            if not ok:
                QMessageBox.warning(self, "Calibration source", msg)
                return
        elif mode == CALIBRATION_SAVED and wells_csv_in(folder) is None:
            QMessageBox.warning(self, "Analyze experiment",
                                "This experiment has no saved well grid. Choose another calibration option.")
            return
        self.running = True
        self.run_btn.setEnabled(False)
        self.log.clear()
        make_video_flag = self.video.isChecked()
        threading.Thread(target=self._worker, args=(folder, mode, source, make_video_flag), daemon=True).start()

    def _run_script(self, name):
        self.sig.log.emit(f"Running {name}...")
        self.proc = subprocess.Popen([sys.executable, str(self.cams_dir / name)], cwd=str(self.cams_dir))
        code = self.proc.wait()
        if code != 0:
            raise ReanalysisError(f"{name} exited with code {code}. If you closed a tuner window without saving, run again.")

    def _ask_retune(self, n):
        return self._on_gui(lambda: QMessageBox.question(
            self, "Uncalibrated wells",
            f"{n} wells still have threshold 0. Reopen the threshold tuner?") == QMessageBox.StandardButton.Yes)

    def _worker(self, folder, mode, source, make_video_flag):
        try:
            out = run_reanalysis(folder, self.cams_dir, mode, source, make_video_flag, self._run_script,
                                 self._ask_retune, log=self.sig.log.emit, stage=self.sig.stage.emit)
            self.sig.done.emit(str(out))
        except Exception as exc:
            self.sig.failed.emit(str(exc))

    def _done(self, out):
        self.running = False
        self.run_btn.setEnabled(True)
        self._append(f"Done. Results: {out}")
        QMessageBox.information(self, "Analysis complete", f"Results saved in:\n{out}")

    def _failed(self, text):
        self.running = False
        if self._closing:
            return
        self.run_btn.setEnabled(True)
        self._append("FAILED: " + text)
        QMessageBox.critical(self, "Analysis failed", text)

    def closeEvent(self, event):
        if self.running:
            if QMessageBox.question(self, "Analysis running", "Stop the analysis and close?") != QMessageBox.StandardButton.Yes:
                event.ignore()
                return
            self._closing = True
            if self.proc is not None and self.proc.poll() is None:
                self.proc.terminate()
        event.accept()
