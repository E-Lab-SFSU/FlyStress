# FlyShaker-local changes to the bundled CAMS

This `cams/` folder is upstream CAMS (synced from CAMS-main-2) with local modifications
(v1.7 added shaking-frame handling; see the table). When updating CAMS again, copy upstream files over this folder
**except** the FlyShaker-modified ones above; merge those by hand.

| File | Status |
|---|---|
| `activity_config.py` | Upstream CAMS-main-2 (rewritten per experiment by `../config_writer.py`) |
| `generate_plots.py` | **FlyShaker-modified** - see below |
| `shake_frames.py`, `sleep_timing.py` | **FlyShaker-only files** (v1.7): SK_ flagging helpers and the sleep timer policy |
| `measure_activity.py` | **FlyShaker-modified (v1.7)**: lists frames through `shake_frames.list_frames` (numeric order, shaking frames skipped), keeps original frame numbers, writes blank activity for the first frame after a gap |
| `classify_sleep.py` | **FlyShaker-modified (v1.7)**: uses `ConservativeSleepTimer`; unmeasured rows hold the current state |
| `motion_threshold_tuner.py`, `compare_first_last.py`, `well_grid_tuner.py` | **FlyShaker-modified (v1.7)**: frame listing only (numeric order, shaking frames skipped; tuner looks images up by frame number) |
| `docs/OUTPUT_FILES.md` | FlyShaker-modified (documents `stimulus_times.csv`, SK_ frames) |
| everything else | Identical to upstream |

## generate_plots.py
Adds `stimulus_records_from_shaker()` and `write_stimulus_records()`. If
`STIMULUS_TIMES_SECONDS` is empty and the experiment folder holds
`image_timestamps_*.csv` + `shaker_timestamps_*.csv`, stimulus times come from the
shaker's `SEQUENCE_START` events (snapped to the nearest frame) and are saved as
`plots/stimulus_times.csv`. Priority: config list > shaker events > inferred from activity.
Upstream's `generate_plots.py` lacks this, so overwriting it silently drops the feature.

## Not yet included
Upstream's README documents `camera_tuner.py` / `camera_settings.json` (UVC camera
setup, needs Pillow), but those files were not in the CAMS-main-2 archive. Add them
(and `Pillow` to `requirements.txt`) when available.
