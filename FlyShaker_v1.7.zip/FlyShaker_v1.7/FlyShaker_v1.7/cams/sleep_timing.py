"""Shared conservative sleep timing policy for live and CAMS classification.

Only consecutive valid observations of immobility add confirmed seconds.
Shaker/unknown intervals preserve accumulated inactivity but earn no time.
"""

class ConservativeSleepTimer:
    def __init__(self, wells, criterion_seconds):
        self.inactive = {well: 0.0 for well in wells}
        self.criterion_seconds = float(criterion_seconds)
        self.last_state = {well: 1 for well in wells}

    def update(self, well, movement, elapsed_seconds, contiguous=True):
        if movement is None or not contiguous:
            # The observation cannot establish what happened across the gap.
            # Preserve previously confirmed inactivity, but do not award time.
            return self.inactive[well], self.last_state[well]
        if movement == 1:
            self.inactive[well] = 0.0
            self.last_state[well] = 1
        elif movement == 0:
            self.inactive[well] += max(0.0, float(elapsed_seconds))
            if self.inactive[well] >= self.criterion_seconds:
                self.last_state[well] = 0
        else:
            raise ValueError('Movement must be 0, 1, or None')
        return self.inactive[well], self.last_state[well]
