#!/usr/bin/env python3
"""Shaking-frame ("SK_") handling shared by the FlyShaker app and the CAMS scripts.

Standard library only, so both the GUI process and the CAMS subprocesses can import it.

What it does
------------
* Reads the shaker log (shaker_timestamps_<id>.csv) and works out when each shaking BURST
  happened, using the ESP's own burst messages.  When a burst has a start but no recorded end,
  the configured Burst duration (experiment_settings.json) is used instead.
* Pads every burst by SHAKE_BUFFER_SECONDS before and after (default 1 s).
* Any image captured inside such a window is a "shaking frame".  Shaking frames are renamed
  frame_000123.png -> SK_frame_000123.png when the experiment is finalized (never deleted), and
  every analysis step skips them.  Before the rename the same windows are applied from the
  timestamp logs, so analysis during the run behaves identically.

Run this file directly on a shaker log to see what the ESP printed and which bursts were found:

    python cams/shake_frames.py ~/FS_IMG/exp00001/shaker_timestamps_00001.csv
"""
from __future__ import annotations

import bisect
import csv
import json
import re
import sys
from collections import Counter
from datetime import datetime, timedelta
from pathlib import Path

PREFIX = "SK_"
SETTINGS_FILE = "experiment_settings.json"
DEFAULT_BUFFER_SECONDS = 1.0
IMAGE_EXTENSIONS = (".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff")
FRAME_RE = re.compile(r"^(?:SK_)?frame_(\d+)\.(?:png|jpg|jpeg|bmp|tif|tiff)$", re.I)

# --------------------------------------------------------------------------------------
# ESP message patterns.  Matched against the UPPER-CASED text of "ESP > ..." log lines.
# These are the only place that depends on what the firmware prints.  If your ESP words
# these differently, run this file on a real shaker log (see above) and edit the patterns.
# --------------------------------------------------------------------------------------
BURST_START_RE = re.compile(r"\bBURST\b(?!\s*SILENCE).*\bSTART")
BURST_SILENCE_START_RE = re.compile(r"\bBURST\s*SILENCE\b.*\bSTART")
BURST_DURATION_RE = re.compile(r"\bBURST\s*DURATION\b\D*([0-9]+(?:\.[0-9]+)?)")


def frame_number(path) -> int:
    """Numeric frame index from frame_000123.png or SK_frame_000123.png; -1 if not a frame name."""
    m = FRAME_RE.match(Path(path).name)
    return int(m.group(1)) if m else -1


def base_name(name: str) -> str:
    return name[len(PREFIX):] if name.startswith(PREFIX) else name


def _parse_ts(text):
    try:
        return datetime.fromisoformat(text)
    except (TypeError, ValueError):
        return None


# --------------------------------------------------------------------------------------
# Settings sidecar
# --------------------------------------------------------------------------------------
def load_settings(experiment_dir) -> dict:
    path = Path(experiment_dir) / SETTINGS_FILE
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def burst_seconds_from_settings(settings: dict):
    """Longest configured burst (conservative: flags more rather than less), or None."""
    burst = settings.get("burst")
    try:
        return float(max(burst))
    except (TypeError, ValueError):
        return None


def buffer_seconds_from_settings(settings: dict) -> float:
    try:
        return max(0.0, float(settings.get("shake_buffer_seconds", DEFAULT_BUFFER_SECONDS)))
    except (TypeError, ValueError):
        return DEFAULT_BUFFER_SECONDS


# --------------------------------------------------------------------------------------
# Burst windows
# --------------------------------------------------------------------------------------
class ShakerWindows:
    """Burst windows built from a shaker log.

    refresh() only reads bytes appended since the last call, so the live engine can call it
    once per image on a log that grows for days without re-reading the whole file.
    """

    def __init__(self, shaker_csv, burst_seconds=None, buffer_seconds=DEFAULT_BUFFER_SECONDS):
        self.path = Path(shaker_csv)
        self.burst_seconds = burst_seconds
        self.buffer = timedelta(seconds=float(buffer_seconds))
        self._pos = 0
        self._header_done = False
        self._events = []            # (timestamp, kind, value) kind in start/end/duration
        self.sequence_starts = 0
        self.esp_lines = 0
        self._dirty = True
        self._starts = []
        self._ends = []
        self.unresolved = 0          # bursts with a start but no way to know the end

    # ---- reading ----------------------------------------------------------------
    def refresh(self):
        try:
            with self.path.open("rb") as f:
                f.seek(self._pos)
                data = f.read()
        except OSError:
            return self
        end = data.rfind(b"\n")
        if end < 0:
            return self
        self._pos += end + 1
        text = data[:end + 1].decode("utf-8", "replace")
        for row in csv.reader(text.splitlines()):
            if not self._header_done:
                self._header_done = True
                if row and row[0].strip().lower() == "timestamp":
                    continue
            self._consume(row)
        return self

    def _consume(self, row):
        if len(row) < 7:
            return
        ts = _parse_ts(row[0])
        if ts is None:
            return
        event, message = row[1], row[6].strip()
        if event == "SEQUENCE_START":
            self.sequence_starts += 1
        if not message.upper().startswith("ESP >"):
            return                                   # PC commands such as "PC > BURST(3,3)"
        self.esp_lines += 1
        upper = message.upper()
        if BURST_SILENCE_START_RE.search(upper):
            self._events.append((ts, "end", None)); self._dirty = True
        elif BURST_START_RE.search(upper):
            self._events.append((ts, "start", None)); self._dirty = True
            m = BURST_DURATION_RE.search(upper)          # duration given on the start line itself
            if m:
                self._events.append((ts, "duration", float(m.group(1))))
        else:
            m = BURST_DURATION_RE.search(upper)
            if m:
                self._events.append((ts, "duration", float(m.group(1)))); self._dirty = True

    # ---- windows ----------------------------------------------------------------
    def _rebuild(self):
        raw, unresolved = [], 0
        start = duration = None

        def close(end_time):
            nonlocal start, duration
            raw.append((start - self.buffer, end_time + self.buffer))
            start = duration = None

        def fallback_end():
            if duration is not None:
                return start + timedelta(seconds=duration)
            if self.burst_seconds is not None:
                return start + timedelta(seconds=self.burst_seconds)
            return None

        for ts, kind, value in self._events:
            if kind == "start":
                if start is not None:
                    end = fallback_end()
                    if end is not None:
                        close(min(end, ts))
                    else:
                        unresolved += 1; start = duration = None
                start, duration = ts, None
            elif kind == "duration" and start is not None:
                duration = value
            elif kind == "end" and start is not None:
                close(ts)
        if start is not None:
            end = fallback_end()
            if end is not None:
                close(end)
            else:
                unresolved += 1
        raw.sort()
        merged = []
        for a, b in raw:
            if merged and a <= merged[-1][1]:
                merged[-1] = (merged[-1][0], max(merged[-1][1], b))
            else:
                merged.append((a, b))
        self._starts = [a for a, _ in merged]
        self._ends = [b for _, b in merged]
        self.unresolved = unresolved
        self._dirty = False

    def windows(self):
        if self._dirty:
            self._rebuild()
        return list(zip(self._starts, self._ends))

    def contains(self, timestamp) -> bool:
        ts = _parse_ts(timestamp) if isinstance(timestamp, str) else timestamp
        if ts is None:
            return False
        if self._dirty:
            self._rebuild()
        i = bisect.bisect_right(self._starts, ts) - 1
        return i >= 0 and ts <= self._ends[i]


def load_windows(experiment_dir, shaker_csv=None) -> ShakerWindows:
    """Windows for a finished or running experiment, using its saved settings."""
    experiment_dir = Path(experiment_dir)
    if shaker_csv is None:
        logs = sorted(experiment_dir.glob("shaker_timestamps_*.csv"))
        shaker_csv = logs[-1] if logs else experiment_dir / "shaker_timestamps_missing.csv"
    settings = load_settings(experiment_dir)
    return ShakerWindows(shaker_csv, burst_seconds_from_settings(settings),
                         buffer_seconds_from_settings(settings)).refresh()


# --------------------------------------------------------------------------------------
# Frame listing for CAMS scripts
# --------------------------------------------------------------------------------------
def _read_image_log(image_csv):
    rows, fields = [], ["image_name", "timestamp"]
    with open(image_csv, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        fields = list(reader.fieldnames or fields)
        rows = list(reader)
    return fields, rows


def flagged_names(image_csv, windows: ShakerWindows) -> set:
    """Base names (no SK_) of images whose capture time falls inside a burst window."""
    result = set()
    if not Path(image_csv).exists() or not windows.windows():
        return result
    _, rows = _read_image_log(image_csv)
    for row in rows:
        if windows.contains(row.get("timestamp", "")):
            result.add(base_name(row.get("image_name", "")))
    return result


def list_frames(directory, exclude_shaking=True):
    """Image files of a frames folder in NUMERIC frame order.

    With exclude_shaking, drops SK_-prefixed files and any image whose logged capture time is
    inside a burst window (so this also works on experiments that were never renamed).
    The timestamp rule only applies to experiment frames: initiation_frames are captured before
    the shaker starts, and their names would otherwise collide with experiment frame names.
    """
    directory = Path(directory)
    if not directory.exists():
        raise FileNotFoundError(f"Frame directory not found: {directory}")
    files = [p for p in directory.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTENSIONS]
    files.sort(key=lambda p: (frame_number(p) if frame_number(p) >= 0 else 10 ** 12, base_name(p.name)))
    if not exclude_shaking:
        return files
    flagged = set()
    experiment = directory.parent
    if directory.name != "initiation_frames":
        image_logs = sorted(experiment.glob("image_timestamps_*.csv"))
        if image_logs:
            flagged = flagged_names(image_logs[-1], load_windows(experiment))
    return [p for p in files if not p.name.startswith(PREFIX) and base_name(p.name) not in flagged]


def frame_lookup(files):
    """{frame number: path}.  Falls back to positions 1..n if the names carry no numbers."""
    numbers = [frame_number(p) for p in files]
    if any(n < 0 for n in numbers):
        numbers = list(range(1, len(files) + 1))
    return dict(zip(numbers, files))


# --------------------------------------------------------------------------------------
# Renaming at finalization
# --------------------------------------------------------------------------------------
def flag_frames(frames_dir, image_csv, windows: ShakerWindows) -> dict:
    """Rename shaking frames to SK_<name> (and restore any that no longer qualify).

    Never deletes an image.  Updates image_timestamps_*.csv so the names stay in step.
    Call only after the camera has stopped writing that CSV.
    Returns a report dict; per-file problems are recorded, not raised.
    """
    frames_dir, image_csv = Path(frames_dir), Path(image_csv)
    report = {"images": 0, "flagged": 0, "renamed": 0, "restored": 0, "windows": 0,
              "errors": [], "warnings": []}
    windows.refresh()
    wins = windows.windows()
    report["windows"] = len(wins)
    if not image_csv.exists():
        report["warnings"].append(f"{image_csv.name} not found; nothing was flagged.")
        return report
    fields, rows = _read_image_log(image_csv)
    for row in rows:
        name = row.get("image_name", "")
        if not FRAME_RE.match(name):
            continue
        report["images"] += 1
        base = base_name(name)
        want_flag = windows.contains(row.get("timestamp", ""))
        target_name = (PREFIX + base) if want_flag else base
        report["flagged"] += int(want_flag)
        have = [n for n in (base, PREFIX + base) if (frames_dir / n).exists()]
        if len(have) == 1 and have[0] != target_name:
            try:
                (frames_dir / have[0]).rename(frames_dir / target_name)
                report["renamed" if want_flag else "restored"] += 1
            except OSError as exc:
                report["errors"].append(f"{have[0]}: {exc}")
                target_name = have[0]
        elif len(have) == 2:
            report["errors"].append(f"{base}: both {base} and {PREFIX}{base} exist; left untouched.")
            target_name = name
        elif not have:
            target_name = name                      # file missing; keep the log line as it was
        row["image_name"] = target_name
    tmp = image_csv.with_suffix(image_csv.suffix + ".tmp")
    with tmp.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    tmp.replace(image_csv)

    if windows.sequence_starts and not wins:
        report["warnings"].append(
            f"The shaker log has {windows.sequence_starts} SEQUENCE_START events but no burst "
            "windows were recognized, so NO frames were flagged. Run "
            "'python cams/shake_frames.py <shaker log>' to see what the ESP prints and adjust "
            "the patterns at the top of cams/shake_frames.py.")
    if windows.unresolved:
        report["warnings"].append(
            f"{windows.unresolved} burst(s) had a start but no end or duration and no Burst "
            "setting was available; they were not flagged.")
    return report


def write_report(experiment_dir, report: dict, windows: ShakerWindows):
    lines = ["Shaking-frame flag report", "",
             f"Images in log:            {report['images']}",
             f"Shaking frames (SK_):     {report['flagged']}",
             f"Renamed this run:         {report['renamed']}",
             f"Restored this run:        {report['restored']}",
             f"Burst windows found:      {report['windows']}",
             f"SEQUENCE_START events:    {windows.sequence_starts}",
             f"Buffer before/after:      {windows.buffer.total_seconds():g} s",
             f"Fallback burst length:    {windows.burst_seconds if windows.burst_seconds is not None else 'none'}"]
    for item in report["warnings"]:
        lines.append(f"WARNING: {item}")
    for item in report["errors"]:
        lines.append(f"ERROR: {item}")
    (Path(experiment_dir) / "shake_flag_report.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return lines


# --------------------------------------------------------------------------------------
# Inspector: python cams/shake_frames.py <shaker_timestamps_xxxxx.csv> [burst_seconds]
# --------------------------------------------------------------------------------------
def _inspect(path, burst_seconds=None):
    w = ShakerWindows(path, burst_seconds).refresh()
    shapes = Counter()
    with open(path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            msg = (row.get("message") or "").strip()
            if msg.upper().startswith("ESP >"):
                shapes[re.sub(r"[0-9]+(?:\.[0-9]+)?", "#", msg)] += 1
    print(f"Distinct ESP message shapes in {path} (numbers shown as #):")
    for shape, count in shapes.most_common():
        print(f"  {count:6d}  {shape}")
    print()
    print(f"SEQUENCE_START events: {w.sequence_starts}")
    wins = w.windows()
    print(f"Burst windows recognized (with {w.buffer.total_seconds():g} s buffers): {len(wins)}")
    for a, b in wins[:10]:
        print(f"  {a.isoformat(timespec='milliseconds')}  ->  {b.isoformat(timespec='milliseconds')}"
              f"  ({(b - a).total_seconds():.1f} s)")
    if len(wins) > 10:
        print(f"  ... {len(wins) - 10} more")
    if w.sequence_starts and not wins:
        print("\nNo bursts recognized. Compare the shapes above with the patterns at the top of this file.")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    _inspect(sys.argv[1], float(sys.argv[2]) if len(sys.argv) > 2 else None)
