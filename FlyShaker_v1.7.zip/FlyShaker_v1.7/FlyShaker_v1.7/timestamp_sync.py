from __future__ import annotations
import bisect
import csv
from datetime import datetime
from pathlib import Path


def _dt(text):
    return datetime.fromisoformat(text)


def _float_or_none(text):
    try:
        return float(text)
    except (TypeError, ValueError):
        return None


def build_alignment(image_csv: Path, shaker_csv: Path, output_csv: Path, threshold_seconds=3.0):
    """Write one row per image.

    Columns 3-8 keep the original rule: nearest SEQUENCE_START within +/- threshold_seconds.
    The last two columns place every image relative to the sequence that is running:

      active_sequence               sequence_number running when the image was taken (blank if none)
      seconds_since_sequence_start  image time minus that sequence's start (blank if none)

    A sequence is active from its SEQUENCE_START until start + duration_s. If the ESP did not
    report a duration (SEQ given as a range), it is treated as active until the next
    SEQUENCE_START. Images before the first sequence are blank.
    """
    image_csv, shaker_csv, output_csv = map(Path, (image_csv, shaker_csv, output_csv))
    if not image_csv.exists() or not shaker_csv.exists():
        return 0
    with image_csv.open(newline="", encoding="utf-8") as f:
        images = list(csv.DictReader(f))
    with shaker_csv.open(newline="", encoding="utf-8") as f:
        shaker = [r for r in csv.DictReader(f) if r.get("event") == "SEQUENCE_START"]
    events = []
    for row in shaker:
        try:
            events.append((_dt(row["timestamp"]), row))
        except Exception:
            pass
    events.sort(key=lambda e: e[0])
    starts = [e[0] for e in events]

    with output_csv.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["image_name", "image_timestamp", "matched_shaker_timestamp", "delta_seconds",
                    "sequence_number", "frequency_hz", "amplitude", "duration_s",
                    "active_sequence", "seconds_since_sequence_start"])
        for img in images:
            try:
                it = _dt(img["timestamp"])
            except Exception:
                continue
            # --- active sequence (most recent start at or before the image) ---
            active, since = "", ""
            i = bisect.bisect_right(starts, it) - 1
            if i >= 0:
                start_time, srow = events[i]
                elapsed = (it - start_time).total_seconds()
                duration = _float_or_none(srow.get("duration_s"))
                if duration is None or elapsed < duration:
                    active = srow.get("sequence_number", "")
                    since = f"{elapsed:.3f}"
            tail = [active, since]
            # --- original +/- threshold match ---
            nearest = min(events, key=lambda e: abs((it - e[0]).total_seconds()), default=None)
            if nearest is None:
                w.writerow([img.get("image_name", ""), img.get("timestamp", ""), "", "", "", "", "", ""] + tail)
                continue
            delta = (it - nearest[0]).total_seconds()
            row = nearest[1]
            if abs(delta) <= float(threshold_seconds):
                w.writerow([img.get("image_name", ""), img.get("timestamp", ""), row["timestamp"],
                            f"{delta:.3f}", row.get("sequence_number", ""), row.get("frequency_hz", ""),
                            row.get("amplitude", ""), row.get("duration_s", "")] + tail)
            else:
                w.writerow([img.get("image_name", ""), img.get("timestamp", ""), "", "", "", "", "", ""] + tail)
    return len(images)
