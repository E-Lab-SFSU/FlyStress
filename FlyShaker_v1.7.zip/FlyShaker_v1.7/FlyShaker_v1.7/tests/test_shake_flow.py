"""Headless tests for shaking-frame (SK_) handling. No camera, ESP or GUI needed.

    python -m unittest discover -s tests -v        (from the FlyShaker folder)

Builds a tiny synthetic experiment (2 wells, 120 frames at 1 image/s, one burst) and checks the
CAMS pipeline, the live engine and the renaming against known answers.
"""
import csv
import shutil
import subprocess
import sys
import tempfile
import unittest
from datetime import datetime, timedelta
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "cams"))

from cams import shake_frames as sf                      # noqa: E402
from config_writer import write_cams_config               # noqa: E402

T0 = datetime(2026, 11, 3, 12, 0, 0)
N = 120
SLEEP_S = 30
BURST_START, BURST_END = 50.5, 53.5       # seconds after T0; frames 51..55 end up flagged (1 s buffers)


def ts(n):                                  # capture time of frame n (1 image/s)
    return (T0 + timedelta(seconds=n - 1)).isoformat(timespec="milliseconds")


def make_frame(n, rng):
    img = np.full((100, 200), 60, np.uint8)
    # well A1 (x=30): fly still except for a jump at frames 100-101
    x1 = 30 + (8 if 100 <= n <= 101 else 0)
    cv2.circle(img, (x1, 50), 6, 255, -1)
    # well A2 (x=130): fly walks until frame 30, then still
    x2 = 130 + (n % 2) * 8 if n <= 30 else 130
    cv2.circle(img, (x2, 50), 6, 255, -1)
    if 51 <= n <= 55:                       # shaking: whole plate jitters
        img = np.roll(img, (int(rng.integers(-9, 9)), int(rng.integers(-9, 9))), axis=(0, 1))
    return img


def shaker_rows(extra=()):
    rows = [["timestamp", "event", "sequence_number", "frequency_hz", "amplitude", "duration_s", "message"],
            [ts(1), "TERMINAL", "", "", "", "", "PC > BURST(3,3)"]]
    rows += [list(r) for r in extra]
    return rows


def burst_rows():
    start = (T0 + timedelta(seconds=BURST_START)).isoformat(timespec="milliseconds")
    end = (T0 + timedelta(seconds=BURST_END)).isoformat(timespec="milliseconds")
    return [[start, "TERMINAL", "", "", "", "", "ESP > BURST START"],
            [end, "TERMINAL", "", "", "", "", "ESP > BURST SILENCE START"]]


def build_experiment(root, with_burst=True, settings=None):
    exp = Path(root) / "exp00001"
    (exp / "frames").mkdir(parents=True)
    rng = np.random.default_rng(1)
    with (exp / "image_timestamps_00001.csv").open("w", newline="") as f:
        w = csv.writer(f); w.writerow(["image_name", "timestamp"])
        for n in range(1, N + 1):
            name = f"frame_{n:06d}.png"
            cv2.imwrite(str(exp / "frames" / name), make_frame(n, rng))
            w.writerow([name, ts(n)])
    with (exp / "shaker_timestamps_00001.csv").open("w", newline="") as f:
        csv.writer(f).writerows(shaker_rows(burst_rows() if with_burst else []))
    with (exp / "plate_wells_exp00001.csv").open("w", newline="") as f:
        w = csv.writer(f); w.writerow(["well", "number", "xc", "yc", "radius"])
        w.writerow(["A1", 1, 30, 50, 20]); w.writerow(["A2", 2, 130, 50, 20])
    with (exp / "well_threshold.csv").open("w", newline="") as f:
        w = csv.writer(f); w.writerow(["well", "motion_threshold_AU", "fly_count", "viable_flies"])
        w.writerow(["A1", 5, 1, 1]); w.writerow(["A2", 5, 1, 1])
    if settings is not None:
        import json
        (exp / sf.SETTINGS_FILE).write_text(json.dumps(settings))
    return exp


def private_cams(tmp, exp):
    cams = Path(tmp) / "cams"
    shutil.copytree(ROOT / "cams", cams, ignore=shutil.ignore_patterns("__pycache__"))
    write_cams_config(cams, exp, 1.0, frames_subdir="frames")
    cfg = cams / "activity_config.py"
    cfg.write_text(cfg.read_text().replace("SLEEP_INACTIVITY_SECONDS=300", f"SLEEP_INACTIVITY_SECONDS={SLEEP_S}"))
    return cams


def run(cams, script):
    r = subprocess.run([sys.executable, str(cams / script)], cwd=str(cams), capture_output=True, text=True)
    if r.returncode:
        raise AssertionError(f"{script} failed:\n{r.stdout}\n{r.stderr}")
    return r.stdout


def read(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


class WindowParsing(unittest.TestCase):
    def write(self, tmp, rows):
        p = Path(tmp) / "shaker_timestamps_00001.csv"
        with p.open("w", newline="") as f:
            csv.writer(f).writerows(shaker_rows(rows))
        return p

    def at(self, s):
        return (T0 + timedelta(seconds=s)).isoformat(timespec="milliseconds")

    def test_start_and_silence(self):
        with tempfile.TemporaryDirectory() as tmp:
            w = sf.ShakerWindows(self.write(tmp, burst_rows())).refresh()
            self.assertEqual(len(w.windows()), 1)
            self.assertTrue(w.contains(T0 + timedelta(seconds=49.6)))      # 1 s before
            self.assertFalse(w.contains(T0 + timedelta(seconds=49.4)))
            self.assertTrue(w.contains(T0 + timedelta(seconds=54.4)))      # 1 s after
            self.assertFalse(w.contains(T0 + timedelta(seconds=54.6)))

    def test_pc_lines_are_ignored(self):
        with tempfile.TemporaryDirectory() as tmp:
            rows = [[self.at(10), "TERMINAL", "", "", "", "", "PC > BURST START"]]
            self.assertEqual(sf.ShakerWindows(self.write(tmp, rows)).refresh().windows(), [])

    def test_start_without_end_uses_duration_message_then_setting(self):
        with tempfile.TemporaryDirectory() as tmp:
            rows = [[self.at(10), "TERMINAL", "", "", "", "", "ESP > BURST START"],
                    [self.at(10.1), "TERMINAL", "", "", "", "", "ESP > BURST DURATION 4"]]
            w = sf.ShakerWindows(self.write(tmp, rows)).refresh()
            (a, b), = w.windows()
            self.assertAlmostEqual((b - a).total_seconds(), 4 + 2)         # duration + two 1 s buffers
            rows = [[self.at(10), "TERMINAL", "", "", "", "", "ESP > BURST START"]]
            w = sf.ShakerWindows(self.write(tmp, rows), burst_seconds=3).refresh()
            (a, b), = w.windows()
            self.assertAlmostEqual((b - a).total_seconds(), 3 + 2)
            w = sf.ShakerWindows(self.write(tmp, rows)).refresh()           # nothing to go on
            self.assertEqual(w.windows(), [])
            self.assertEqual(w.unresolved, 1)

    def test_incremental_refresh_matches_full_read(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = self.write(tmp, [])
            w = sf.ShakerWindows(p).refresh()
            self.assertEqual(w.windows(), [])
            with p.open("a", newline="") as f:
                csv.writer(f).writerows(burst_rows())
            self.assertEqual(len(w.refresh().windows()), 1)

    def test_nearby_bursts_merge(self):
        with tempfile.TemporaryDirectory() as tmp:
            rows = []
            for t in (10, 12):
                rows += [[self.at(t), "TERMINAL", "", "", "", "", "ESP > BURST START"],
                         [self.at(t + 1), "TERMINAL", "", "", "", "", "ESP > BURST SILENCE START"]]
            self.assertEqual(len(sf.ShakerWindows(self.write(tmp, rows)).refresh().windows()), 1)


class Pipeline(unittest.TestCase):
    def test_flagging_listing_and_idempotence(self):
        with tempfile.TemporaryDirectory() as tmp:
            exp = build_experiment(tmp)
            self.assertEqual(len(sf.list_frames(exp / "frames")), N - 5)    # excluded via logs, no rename yet
            w = sf.load_windows(exp)
            rep = sf.flag_frames(exp / "frames", exp / "image_timestamps_00001.csv", w)
            self.assertEqual((rep["flagged"], rep["renamed"], rep["errors"]), (5, 5, []))
            names = sorted(p.name for p in (exp / "frames").glob("SK_*"))
            self.assertEqual(names, [f"SK_frame_{n:06d}.png" for n in range(51, 56)])
            self.assertEqual(len(list((exp / "frames").glob("*.png"))), N)  # nothing deleted
            clean = sf.list_frames(exp / "frames")
            self.assertEqual([sf.frame_number(p) for p in clean], [n for n in range(1, N + 1) if not 51 <= n <= 55])
            rep2 = sf.flag_frames(exp / "frames", exp / "image_timestamps_00001.csv", w)
            self.assertEqual((rep2["renamed"], rep2["restored"]), (0, 0))   # second run changes nothing
            self.assertEqual(sum(r["image_name"].startswith("SK_") for r in read(exp / "image_timestamps_00001.csv")), 5)

    def test_initiation_frames_are_not_filtered_by_experiment_log(self):
        with tempfile.TemporaryDirectory() as tmp:
            exp = build_experiment(tmp)
            (exp / "initiation_frames").mkdir()
            for n in range(1, 61):                  # same names as experiment frames 51..55 exist here too
                cv2.imwrite(str(exp / "initiation_frames" / f"frame_{n:06d}.png"), np.zeros((10, 10), np.uint8))
            self.assertEqual(len(sf.list_frames(exp / "initiation_frames")), 60)

    def test_no_burst_messages_warns_instead_of_failing_silently(self):
        with tempfile.TemporaryDirectory() as tmp:
            exp = build_experiment(tmp, with_burst=False)
            with (exp / "shaker_timestamps_00001.csv").open("a", newline="") as f:
                csv.writer(f).writerow([ts(5), "SEQUENCE_START", 1, 60, 8, 120, "ESP > SEQUENCE START"])
            rep = sf.flag_frames(exp / "frames", exp / "image_timestamps_00001.csv", sf.load_windows(exp))
            self.assertEqual(rep["flagged"], 0)
            self.assertTrue(any("no burst" in w.lower() for w in rep["warnings"]))

    def test_cams_results_same_before_and_after_rename_and_timing(self):
        with tempfile.TemporaryDirectory() as tmp:
            exp = build_experiment(tmp)
            cams = private_cams(tmp, exp)
            run(cams, "measure_activity.py"); run(cams, "classify_sleep.py")
            before = read(exp / "exp00001.csv")
            frames = sorted({int(r["frame"]) for r in before})
            self.assertEqual(frames, [n for n in range(1, N + 1) if not 51 <= n <= 55])
            a1 = {int(r["frame"]): r for r in before if r["well"] == "A1"}
            self.assertEqual(a1[56]["activity_AU"], "")            # first frame after the gap: not compared
            self.assertNotEqual(a1[57]["activity_AU"], "")
            self.assertEqual(a1[56]["motion_detected"], "")
            for r in before:                                        # no holes in the awake column
                self.assertIn(r["awake"], ("0", "1"))
            # A1 sits still: asleep once SLEEP_S s of measured stillness exist (frames 2..31)
            first_asleep = lambda well: min(int(r["frame"]) for r in before if r["well"] == well and r["awake"] == "0")
            self.assertEqual(first_asleep("A1"), 31)
            # A2 stops walking after frame 30: stillness from 31, 20 s by frame 50; the gap earns nothing,
            # frame 56 is unmeasured, so the last 10 s are 57..66
            self.assertEqual(first_asleep("A2"), 66)
            # A1 stays asleep through the gap and wakes at its real movement (frame 100)
            self.assertTrue(all(a1[n]["awake"] == "0" for n in range(31, 100) if n in a1))
            self.assertEqual(a1[100]["awake"], "1")
            plate = read(exp / "exp00001_plate.csv")
            for r in plate:
                self.assertNotEqual(r["valid_wells"], "0")
                self.assertNotEqual(r["percent_awake"], "")
            # renaming must not change a single number
            rep = sf.flag_frames(exp / "frames", exp / "image_timestamps_00001.csv", sf.load_windows(exp))
            self.assertEqual(rep["renamed"], 5)
            run(cams, "measure_activity.py"); run(cams, "classify_sleep.py")
            self.assertEqual(before, read(exp / "exp00001.csv"))
            out = run(cams, "compare_first_last.py")
            self.assertIn("First frame: frame_000001.png", out)
            self.assertIn(f"Last frame:  frame_{N:06d}.png", out)

    def test_live_engine_matches_cams(self):
        from live_engine import LiveSleepEngine
        with tempfile.TemporaryDirectory() as tmp:
            exp = build_experiment(tmp, settings={"burst": [3, 3], "shake_buffer_seconds": 1.0})
            cams = private_cams(tmp, exp)
            run(cams, "measure_activity.py"); run(cams, "classify_sleep.py")
            cams_rows = read(exp / "exp00001.csv")
            engine = LiveSleepEngine.from_cams_config(cams, provisional_s=SLEEP_S, provisional_until_s=0)
            engine.set_shaker_log(exp / "shaker_timestamps_00001.csv", 3, 1.0)
            stamps = {r["image_name"]: r["timestamp"] for r in read(exp / "image_timestamps_00001.csv")}
            asleep_counts = {}
            for n in range(1, N + 1):
                name = f"frame_{n:06d}.png"
                img = cv2.imread(str(exp / "frames" / name), cv2.IMREAD_GRAYSCALE)
                asleep_counts[n] = engine.process(img, name, stamps[name])["asleep"]
            for n in (30, 40, 60, 66, 80, 99, 100, 110):
                official = sum(1 for r in cams_rows if int(r["frame"]) == n and r["awake"] == "0")
                if n in asleep_counts and not 51 <= n <= 55:
                    self.assertEqual(asleep_counts[n], official, f"frame {n}")


if __name__ == "__main__":
    unittest.main()
