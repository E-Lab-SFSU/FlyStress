from __future__ import annotations
import shutil
from pathlib import Path


def _path_literal(path: Path) -> str:
    return repr(str(Path(path).resolve()))


def write_cams_config(cams_dir: Path, experiment_dir: Path, images_per_second: float,
                      frames_subdir: str = "frames", output_dir: Path | None = None) -> Path:
    """Write only CAMS' path/timing config for this experiment.

    The CAMS analysis scripts themselves are not modified.
    """
    cams_dir = Path(cams_dir).resolve()
    experiment_dir = Path(experiment_dir).resolve()
    frames = experiment_dir / frames_subdir   # initiation_frames during calibration, frames for the experiment
    rate = float(images_per_second)
    if rate <= 0:
        raise ValueError("Images per second must be greater than zero.")

    # Preserve CAMS' own non-GUI defaults from the uploaded activity_config.py.
    original = (cams_dir / "activity_config.py").read_text(encoding="utf-8")
    values = {
        "DIR": f"Path({_path_literal(experiment_dir.parent)})",
        "EXPERIMENT": repr(experiment_dir.name),
        "EXPERIMENT_DIRECTORY": f"Path({_path_literal(experiment_dir)})",
        "FRAME_DIRECTORY": f"Path({_path_literal(frames)})",
        "FRAME_RATE_FPS": repr(rate),
        "FRAME_INTERVAL_SECONDS": repr(1.0 / rate),
    }

    if output_dir is not None:
        # Re-analysis: read frames/timestamps from the experiment, write every CAMS output elsewhere.
        output_dir = Path(output_dir).resolve()
        name = experiment_dir.name
        values.update({
            "OUTPUT_DIRECTORY": f"Path({_path_literal(output_dir)})",
            "WELLS_CSV": f"Path({_path_literal(output_dir / f'plate_wells_{name}.csv')})",
            "THRESHOLD_CSV": f"Path({_path_literal(output_dir / 'well_threshold.csv')})",
            "ACTIVITY_CSV": f"Path({_path_literal(output_dir / f'{name}.csv')})",
            "PLOTS_DIRECTORY": f"Path({_path_literal(output_dir / 'plots')})",
        })

    lines = original.splitlines()
    out = []
    replaced = set()
    for line in lines:
        stripped = line.strip()
        did_replace = False
        for key, value in values.items():
            if stripped.startswith(key + "=") or stripped.startswith(key + " ="):
                out.append(f"{key}={value}")
                replaced.add(key)
                did_replace = True
                break
        if not did_replace:
            out.append(line)

    missing = [k for k in values if k not in replaced]
    if missing:
        raise RuntimeError("Could not update CAMS config fields: " + ", ".join(missing))

    config_path = cams_dir / "activity_config.py"
    config_path.write_text("\n".join(out) + "\n", encoding="utf-8")
    # Keep a snapshot with the data: cams/activity_config.py is overwritten by every new
    # experiment, so this is the only record of the settings this experiment was analysed with.
    shutil.copy2(config_path, (output_dir if output_dir is not None else experiment_dir) / "activity_config_used.py")
    return config_path
