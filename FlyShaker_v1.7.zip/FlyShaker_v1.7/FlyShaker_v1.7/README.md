# Fly Shaker + CAMS integrated controller

Primary target: Raspberry Pi 5. A Windows demonstration mode is included so the GUI/workflow can be shown without the USB camera or ESP32.

## Workflow implemented

1. Settings window: images/second, frequency, amplitude, DUTY, **BSilence**, sequence, SSilence, session, initiation, and **Calibration** (calibrate new / reuse well grid / reuse grid + thresholds, with a "reuse from" experiment folder). BURST stays at 3,3. The **Analyze existing experiment...** button opens at-home analysis (below).
2. **Free-space check** when you press *Create Experiment*. If there is not enough room, an error window explains why and you stay on the Settings window; nothing has been created or started.
3. Creates `<root>/expXXXXX/` with `initiation_frames/` and `frames/`.
4. The camera opens once and **stays open for the whole session** (live preview, stable auto-exposure). Initiation images are saved to `initiation_frames/`.
5. CAMS calibration runs on `initiation_frames/`: `well_grid_tuner.py`, `measure_activity.py` (creates `median_background.png`), `motion_threshold_tuner.py`. With a reused grid, the saved grid is drawn on the latest initiation frame for you to confirm (or redraw). With reused thresholds, the tuner only opens for wells that still need one. Blank `fly_count`/`viable_flies` are then filled automatically (1 per calibrated well, 0 for excluded wells; anything you typed is kept). A threshold left at 0 is caught here, not five minutes into the experiment.
6. Saving switches to `frames/` and the shaker starts.
7. **Live sleep timer** (see below) updates Sleep/Awake on the preview after every image and writes `sleep_timer.csv`.
8. Every 300 experiment images, CAMS `measure_activity.py` + `classify_sleep.py` run: this is the official record (`sleep_data.csv`, shown as "Official CAMS check").
9. On experiment end: final analysis, `compare_first_last.py`, `generate_plots.py`, video, `image_shaker_alignment.csv`.

Because `frames/` contains only experiment images, CAMS time 0 is the start of the experiment. The sleep (inactivity) clock starts at experiment start.

## Preview window

- **Last:** frequency / amplitude of the most recent sequence (parsed from ESP output). **Next:** the configured frequency and amplitude range ("range" means the ESP picks the values; the PC cannot know them in advance).
- **Time since last shake:** time since the last `SEQUENCE_START` (PC receive time). **Next shake in:** estimated as SEQ + SSilence after the last start, shown only when both are fixed (min = max); otherwise "unknown". BSilence is sent to the ESP but not used in this estimate.
- **Sleep / Awake:** live, per image (see below). **Official CAMS check:** `classify_sleep` result, refreshed every 300 images.

## Live sleep timer

For each image the app compares it with the previous image per well using the same math as `measure_activity.py` and the well's saved threshold: motion = 1 / 0. Motion resets the well's inactivity timer. A well counts as asleep when its timer reaches the criterion:

- first 5 minutes of the experiment: **30 s** (provisional; the count will drop at minute 5 because the official rule is stricter);
- afterwards: **300 s** (`SLEEP_INACTIVITY_SECONDS`), which is identical to what `classify_sleep.py` reports.

`sleep_timer.csv`: one row per image with `image_name, timestamp, frame, time_s, criterion_s, sleeping_wells, awake_wells` and one column per well (1 = movement vs previous image, 0 = none, -1 = excluded well). The 30 s provisional criterion never feeds `classify_sleep`, the plots or `sleep_data.csv`.

## Reusing calibration

- *Reuse well grid*: the grid is copied (renamed to `plate_wells_<exp>.csv`) and you re-tune thresholds.
- *Reuse well grid and thresholds*: thresholds are copied too. `fly_count`/`viable_flies` are reset (new flies), and wells excluded (-1) last time are offered again because a well that was empty may hold a fly now.
- Initiation images are still captured, because the median background must come from the current lighting. The CAMS grid tuner cannot load an existing grid, so "reuse" means copy, not edit. A bumped plate or camera invalidates a reused grid, which is why the overlay confirmation exists.

## At-home analysis

*Analyze existing experiment...* (Settings window) runs the CAMS pipeline on a finished experiment folder. It uses only `frames/` and ignores `initiation_frames/`. Results go to a new `reanalysis_<time>/` folder inside the experiment, so the original files are never touched. Calibration can come from the experiment itself, from another experiment, or be done fresh with the tuners on that experiment's frames. The frame rate is measured from `image_timestamps_*.csv`. If the experiment folder contains `median_background.png` it is reused (consistent with the live numbers); otherwise a background is computed from random frames. Outputs: activity/plate CSVs, plots, first/last comparison, `image_shaker_alignment.csv`, `sleep_timer.csv`, `reanalysis_info.txt` and (optional) the video. Only experiment folders created by version 2 or later are supported.

## Save location and free-space check

Default root: `~/FS_IMG`. To save to an external drive, set `FLYSHAKER_ROOT` before launching, e.g. `export FLYSHAKER_ROOT=/media/pi/MyDrive/FS_IMG` (or `set FLYSHAKER_ROOT=D:\FS_IMG` on Windows).

Required space = (session + initiation) x images/s x **2 MB** x 1.10 + 1 GB reserve. The 2 MB/image figure is a conservative estimate for 1280x800 PNGs; adjust `EST_BYTES_PER_IMAGE` in `disk_check.py` after checking real file sizes. If the root is a link to a drive that is not mounted, the check reports the problem instead of measuring the wrong disk.

## Video

Built from `frames/` only. At 1 image/s: up to 1800 images = real time; more than 1800 (30 min) = 2x; more than 7200 (2 h) = 3x (one third of the real-time length). Thresholds are `VIDEO_X2_AFTER_IMAGES` / `VIDEO_X3_AFTER_IMAGES` in `main.py`.

## Shaker alignment and plots

`image_shaker_alignment.csv` keeps the +/-3 s match columns and adds:

- `active_sequence`: sequence number running when the image was taken (blank if none).
- `seconds_since_sequence_start`: image time minus that sequence's start.

A sequence is active from `SEQUENCE_START` to start + `duration_s`. If the ESP does not report a duration (SEQ given as a range), the sequence is treated as active until the next `SEQUENCE_START`.

`generate_plots.py` now takes stimulus times in this priority order: `STIMULUS_TIMES_SECONDS` in the config > shaker `SEQUENCE_START` events correlated with image timestamps > inferred from plate activity. Correlated times are snapped to the nearest frame, and `plots/stimulus_times.csv` plus `plot_summary.txt` record sequence number, frequency, amplitude and duration for every stimulus.

## Raspberry Pi 5 setup

The CAMS tuners use OpenCV GUI windows, so the Pi should use an OpenCV build with HighGUI support. A reliable Raspberry Pi OS approach is:

```bash
sudo apt update
sudo apt install -y python3-venv python3-opencv libxcb-cursor0
python3 -m venv --system-site-packages .venv
source .venv/bin/activate
pip install -r requirements-pi.txt
./run_raspberry_pi.sh
```

Expected hardware paths remain `/dev/video0` for the USB camera and `/dev/ttyUSB0` for the ESP32, matching the uploaded reference scripts.

If serial permission is denied:

```bash
sudo usermod -aG dialout $USER
```

Then log out/reboot once.

## Windows demonstration

From PowerShell / Command Prompt in this folder:

```bat
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements-windows.txt
run_windows_demo.bat
```

Windows demo mode uses a synthetic 4x8 well-plate camera image and simulated shaker sequence reports (SSilence is honoured). It still creates `expXXXXX`, `initiation_frames`, `frames`, timestamp CSVs, and exercises the same GUI/controller flow. The CAMS tuner windows can be demonstrated with the synthetic frames.

## Important implementation notes

- The analysis scripts in `cams/` are unchanged except `generate_plots.py` (shaker-event stimulus times, see above).
- `config_writer.py` changes only the CAMS experiment paths and image timing needed for each new experiment; all other CAMS settings remain from the supplied `activity_config.py`. It edits `cams/activity_config.py` in place, so a snapshot is saved as `activity_config_used.py` in each experiment folder.
- `BURST(3,3)` and `BSILENCE(120,120)` remain the uploaded shakerTerminal defaults because they were intentionally omitted from the requested settings screen.
- `img_to_vid.py` does not contain a runnable `main`; it defines `create_video(...)`. The controller calls that supplied function at finalization.
- Periodic 300-image CAMS updates recompute activity across the frames currently present because the existing `measure_activity.py` is a full-dataset processor. This preserves CAMS code unchanged at the cost of extra computation on long experiments.

## Review changes (pre-development pass)

- ESP commands now send integers when the value is whole (`FREQ(50,100)`, `SESSION(300)`), matching shakerTerminal v6. Previously the GUI sent `FREQ(50.0,100.0)` / `SESSION(300.0)`.
- Frames are written to a temp file and renamed, so CAMS never reads a half-written PNG during the periodic updates. Image timestamps are taken at capture, not after the disk write.
- Periodic analysis and final analysis can no longer run at the same time (shared lock).
- Cancelling a tuner / camera or serial failure before the shaker starts now aborts cleanly instead of running the full finalize chain and showing cascading errors. Closing the window stops tuner subprocesses and sends STOP to the ESP.
- Camera failure mid-experiment (5 s of failed reads) raises an error instead of silently saving nothing.
- Settings validation: amplitude 0-30, DUTY 0-100, frequency > 0, session >= longest sequence, initiation must yield >= 2 images.
- Live Freq/Amp polling reads only newly appended CSV bytes; preview is downscaled with OpenCV before display.
- Resume numbering uses the highest existing frame number, not the file count.

## Version 3 additions

BSilence setting; last/next frequency, time since last shake and next-shake estimate on the preview; live per-image sleep timer with `sleep_timer.csv`; automatic `fly_count`/`viable_flies` completion plus an uncalibrated-wells check before the shaker starts; reuse well grid / thresholds with grid confirmation; at-home analysis of finished experiments.


## Version 1.7 additions

- **Shaking frames.** Frames captured during a shaker burst +/- 1 s are renamed `SK_frame_XXXXXX.png` when
  the experiment ends (never deleted; still in the video). All CAMS steps, the live sleep timer and
  at-home analysis skip them, including experiments recorded before v1.7 (the same windows are
  computed from the timestamp logs). Burst times come from the ESP's burst messages in
  `shaker_timestamps_*.csv`; if a burst has no logged end, the **Burst** setting is used.
  **Check the ESP wording once on real hardware:** `python cams/shake_frames.py <shaker log>` prints the
  distinct ESP messages and the bursts it found. The patterns live at the top of `cams/shake_frames.py`.
- **Sleep timing across shaking gaps (Option B).** Only consecutive measured frames add inactive time;
  a gap keeps what was already confirmed and earns nothing. See `cams/sleep_timing.py`.
- **Threshold calibration without an experiment.** *Motion threshold calibration only...* asks
  "Use a pre-existing experiment?". Yes: pick a folder. No: capture initiation images, run the grid / activity /
  threshold steps the Calibration choice calls for, then stop (the shaker never starts).
- **Death Timer** (hours/minutes/seconds, 0 = off) is saved in `experiment_settings.json`. It does not classify
  anything yet.
- `experiment_settings.json` is written to every experiment folder (all settings, burst length, SK_ buffer).
- Tests: `python -m unittest discover -s tests -v`.
