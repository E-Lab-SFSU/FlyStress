"""Helpers for CAMS calibration files (well grid + per-well thresholds). No GUI imports."""
from __future__ import annotations

import csv
import shutil
from pathlib import Path

import cv2

DEFAULT_FLIES_PER_WELL = 1
THRESHOLD_FIELDS = ["well", "motion_threshold_AU", "fly_count", "viable_flies"]


def wells_csv_in(exp_dir) -> Path | None:
    matches = sorted(Path(exp_dir).glob("plate_wells_*.csv"))
    return matches[0] if matches else None


def _read_rows(path):
    with Path(path).open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def _write_rows(path, rows):
    with Path(path).open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=THRESHOLD_FIELDS)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in THRESHOLD_FIELDS})


def _threshold(row) -> float:
    text = (row.get("motion_threshold_AU") or "").strip()
    return float(text) if text else 0.0


def uncalibrated_wells(path) -> list[str]:
    """Wells whose threshold is still 0 (neither calibrated nor excluded with -1)."""
    return [r["well"].strip() for r in _read_rows(path) if _threshold(r) == 0]


def complete_counts(path, default=DEFAULT_FLIES_PER_WELL) -> dict:
    """Fill blank fly_count / viable_flies so classify_sleep.py can run.

    Calibrated wells get `default` (1 fly, viable); excluded (-1) wells get 0. Values already
    present are never overwritten. Returns {'filled': n_cells_filled, 'excluded': n_wells_at_-1}.
    """
    rows = _read_rows(path)
    filled = excluded = 0
    for r in rows:
        value = "0" if _threshold(r) == -1 else str(int(default))
        excluded += _threshold(r) == -1
        for field in ("fly_count", "viable_flies"):
            if not (r.get(field) or "").strip():
                r[field] = value
                filled += 1
    _write_rows(path, rows)
    return {"filled": filled, "excluded": excluded}


def load_threshold_metadata(path) -> dict:
    """Same rules as classify_sleep.load_well_metadata (kept here so no CAMS config is imported)."""
    meta = {}
    for r in _read_rows(path):
        well = r["well"].strip()
        thr = _threshold(r)
        if thr == 0:
            raise ValueError(f"Threshold calibration incomplete: well {well} still has threshold 0.")
        if thr < 0 and thr != -1:
            raise ValueError(f"Invalid motion threshold for well {well}: {thr:g}")
        counts = []
        for field in ("fly_count", "viable_flies"):
            text = (r.get(field) or "").strip()
            if not text:
                raise ValueError(f"{field} is blank for well {well}.")
            v = float(text)
            if not v.is_integer() or v < 0:
                raise ValueError(f"{field} must be a nonnegative integer for well {well}: {text}")
            counts.append(int(v))
        fly_count, viable = counts
        if viable > fly_count:
            raise ValueError(f"viable_flies cannot exceed fly_count for well {well}.")
        meta[well] = {"threshold": thr, "fly_count": fly_count, "viable_flies": viable,
                      "excluded": thr == -1 or fly_count == 0 or viable == 0}
    if not meta:
        raise ValueError("Threshold CSV contains no wells.")
    return meta


# ---------------------------------------------------------------- reuse of earlier calibrations
def find_latest_calibration(root, exclude=None) -> Path | None:
    """Most recently calibrated experiment folder under root (one that has a well-grid CSV)."""
    root = Path(root)
    if not root.is_dir():
        return None
    best, best_time = None, -1.0
    for d in root.iterdir():
        if not d.is_dir() or (exclude and d.resolve() == Path(exclude).resolve()):
            continue
        g = wells_csv_in(d)
        if g and g.stat().st_mtime > best_time:
            best, best_time = d, g.stat().st_mtime
    return best


def check_source(src, need_thresholds: bool):
    """(ok, message) - can this folder serve as a calibration source?"""
    src = Path(src)
    if not src.is_dir():
        return False, f"Calibration source not found:\n{src}"
    if wells_csv_in(src) is None:
        return False, f"No plate_wells_*.csv (well grid) in:\n{src}"
    if need_thresholds:
        t = src / "well_threshold.csv"
        if not t.exists():
            return False, f"No well_threshold.csv in:\n{src}"
        if not any(_threshold(r) > 0 for r in _read_rows(t)):
            return False, f"well_threshold.csv in {src} has no calibrated wells."
    return True, ""


def copy_grid(src_dir, dst_dir, dst_name) -> Path:
    src = wells_csv_in(src_dir)
    if src is None:
        raise FileNotFoundError(f"No plate_wells_*.csv in {src_dir}")
    dst = Path(dst_dir) / f"plate_wells_{dst_name}.csv"
    shutil.copy2(src, dst)
    return dst


def copy_thresholds(src_dir, dst_dir, reset_counts=True, keep_exclusions=False) -> Path:
    """Copy well_threshold.csv.

    reset_counts: blank fly_count/viable_flies (they belong to the old plate of flies).
    keep_exclusions: if False, wells excluded (-1) before are reset to 0 so the tuner offers
    them again - an empty/dead well in the last experiment may hold a fly now.
    """
    rows = _read_rows(Path(src_dir) / "well_threshold.csv")
    for r in rows:
        if not keep_exclusions and _threshold(r) == -1:
            r["motion_threshold_AU"] = "0"
        if reset_counts:
            r["fly_count"] = r["viable_flies"] = ""
    dst = Path(dst_dir) / "well_threshold.csv"
    _write_rows(dst, rows)
    return dst


def grid_overlay(frame_path, wells_csv):
    """Image with the saved well grid drawn on a frame, for the 'is it still aligned?' check."""
    img = cv2.imread(str(frame_path), cv2.IMREAD_COLOR)
    if img is None:
        raise FileNotFoundError(f"Could not read {frame_path}")
    for r in _read_rows(wells_csv):
        c = (int(round(float(r["xc"]))), int(round(float(r["yc"]))))
        cv2.circle(img, c, int(round(float(r["radius"]))), (0, 255, 0), 2)
        cv2.putText(img, r["well"], (c[0] - 12, c[1] + 5), cv2.FONT_HERSHEY_SIMPLEX, 0.45,
                    (0, 0, 255), 1, cv2.LINE_AA)
    return img
