"""Live per-image motion / sleep tracking that mirrors measure_activity.py + classify_sleep.py.

For every saved image it compares the current frame to the previous one, per well:

    activity = sum(|current - previous| inside well mask) / background_sum_of_well * ACTIVITY_SCALE
    motion   = 1 if activity (rounded as CAMS writes it) > the well's threshold else 0

and keeps each well's inactivity timer (reset by motion). A well counts as asleep when its
timer reaches the criterion:

    first 5 minutes (time_s < provisional_until_s): provisional_s (30 s)
    afterwards:                                      official_s  (SLEEP_INACTIVITY_SECONDS, 300 s)

From minute 5 on the live state is identical to what classify_sleep.py computes. The 30 s
criterion is only a provisional display aid; it never feeds the official analysis.
No GUI imports.
"""
from __future__ import annotations

import csv
import importlib.util
import queue
import time
from collections import deque
from cams.shake_frames import ShakerWindows, base_name, frame_number
from cams.sleep_timing import ConservativeSleepTimer
import threading
from pathlib import Path

import cv2
import numpy as np

from calibration_tools import load_threshold_metadata


def load_cams_config(cams_dir):
    """Import cams/activity_config.py as a private module (never touches sys.modules)."""
    path = Path(cams_dir) / "activity_config.py"
    spec = importlib.util.spec_from_file_location("_live_cams_config", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _load_wells(path):
    wells = []
    with open(path, newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            wells.append((r["well"].strip(), int(r["number"]), float(r["xc"]), float(r["yc"]), float(r["radius"])))
    if not wells:
        raise ValueError(f"No wells found in {path}")
    return wells


class LiveSleepEngine:
    def __init__(self, wells, metadata, background, dt, activity_scale=1000.0, mask_scale=0.90,
                 decimals=2, provisional_s=30.0, provisional_until_s=300.0, official_s=300.0):
        self.dt = float(dt)
        self.scale = float(activity_scale)
        self.decimals = int(decimals)
        self.provisional_s = float(provisional_s)
        self.provisional_until_s = float(provisional_until_s)
        self.official_s = float(official_s)
        self.shape = background.shape
        h, w = self.shape
        self.regions = []   # (name, y0, y1, x0, x1, mask, background_sum, threshold, excluded)
        for name, number, xc, yc, radius in wells:
            if name not in metadata:
                raise ValueError(f"Missing threshold/viability metadata for well {name}.")
            rad = radius * float(mask_scale)
            x0, x1 = max(0, int(np.floor(xc - rad))), min(w, int(np.ceil(xc + rad)) + 1)
            y0, y1 = max(0, int(np.floor(yc - rad))), min(h, int(np.ceil(yc + rad)) + 1)
            yy, xx = np.ogrid[y0:y1, x0:x1]
            mask = (xx - xc) ** 2 + (yy - yc) ** 2 <= rad ** 2
            bsum = float(background[y0:y1, x0:x1][mask].astype(np.float64).sum())
            if bsum <= 0:
                raise ValueError("One or more wells have zero background brightness.")
            m = metadata[name]
            self.regions.append((name, y0, y1, x0, x1, mask, bsum, m["threshold"], m["excluded"]))
        self.names = [r[0] for r in self.regions]
        self.inactive = {r[0]: 0.0 for r in self.regions if not r[8]}
        self.timer = ConservativeSleepTimer(self.inactive, self.official_s)
        self.shake_windows = None      # set_shaker_log(); None = no shaking-frame exclusion
        self.prev = None
        self.frame_index = 0
        self._csv_file = None
        self._csv_writer = None

    @classmethod
    def from_cams_config(cls, cams_dir, provisional_s=30.0, provisional_until_s=300.0):
        c = load_cams_config(cams_dir)
        background = cv2.imread(str(Path(getattr(c, "BACKGROUND_FILE",
                                                 Path(c.OUTPUT_DIRECTORY) / "median_background.png"))),
                                cv2.IMREAD_GRAYSCALE)
        if background is None:
            raise FileNotFoundError("median_background.png not found - run measure_activity.py first.")
        return cls(_load_wells(c.WELLS_CSV), load_threshold_metadata(c.THRESHOLD_CSV), background,
                   dt=c.FRAME_INTERVAL_SECONDS, activity_scale=c.ACTIVITY_SCALE, mask_scale=c.MASK_SCALE,
                   decimals=getattr(c, "OUTPUT_DECIMALS", 2), provisional_s=provisional_s,
                   provisional_until_s=provisional_until_s, official_s=c.SLEEP_INACTIVITY_SECONDS)

    def set_shaker_log(self, shaker_csv, burst_seconds=None, buffer_seconds=1.0):
        """Exclude images captured inside shaker burst windows (same rule as the CAMS scripts)."""
        self.shake_windows = ShakerWindows(shaker_csv, burst_seconds, buffer_seconds)

    # ------------------------------------------------------------------ csv
    def attach_csv(self, path):
        self._csv_file = Path(path).open("w", newline="", encoding="utf-8", buffering=1)
        self._csv_writer = csv.writer(self._csv_file)
        self._csv_writer.writerow(["image_name", "timestamp", "frame", "time_s", "criterion_s",
                                   "sleeping_wells", "awake_wells"] + self.names)

    def close(self):
        if self._csv_file is not None:
            try:
                self._csv_file.flush()
                self._csv_file.close()
            except Exception:
                pass
        self._csv_file = self._csv_writer = None

    # ------------------------------------------------------------------ processing
    def process(self, frame, image_name="", timestamp="", force_shaking=False):
        """Process one image. force_shaking marks it as a shaking frame regardless of the log
        (used when replaying SK_-named files)."""
        self.frame_index += 1
        time_s = (self.frame_index - 1) * self.dt
        shaking = bool(force_shaking or image_name.startswith("SK_") or
                       (self.shake_windows is not None and self.shake_windows.refresh().contains(timestamp)))
        if shaking:
            # No motion evidence during shaker disturbance. Do not compare across the gap;
            # the next clean image only becomes the new reference.
            self.prev = None
            motion = {name: (-1 if excluded else '') for name, *_, excluded in self.regions}
            criterion = self.provisional_s if time_s < self.provisional_until_s else self.official_s
            asleep = sum(1 for v in self.inactive.values() if v >= criterion)
            snap = {'frame': self.frame_index, 'time_s': time_s, 'criterion_s': criterion,
                    'asleep': asleep, 'awake': len(self.inactive)-asleep, 'motion': motion,
                    'image_name': image_name, 'timestamp': timestamp, 'provisional': criterion != self.official_s,
                    'shaking': True}
            if self._csv_writer is not None:
                self._csv_writer.writerow([image_name, timestamp, self.frame_index, f'{time_s:.3f}',
                                           f'{criterion:g}', asleep, snap['awake']] + [motion[n] for n in self.names])
                self._csv_file.flush()
            return snap
        gray = frame if frame.ndim == 2 else cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        if gray.shape != self.shape:
            raise ValueError(f"Image size {gray.shape} does not match background {self.shape}.")
        motion = {}
        if self.prev is not None:
            diff = cv2.absdiff(gray, self.prev)
            for name, y0, y1, x0, x1, mask, bsum, thr, excluded in self.regions:
                if excluded:
                    motion[name] = -1
                    continue
                activity = float(diff[y0:y1, x0:x1][mask].sum()) / bsum * self.scale
                activity = float(f"{activity:.{self.decimals}f}")      # CAMS compares the rounded CSV value
                if activity > thr:
                    motion[name] = 1
                    self.timer.update(name, 1, self.dt)
                    self.inactive[name] = self.timer.inactive[name]
                else:
                    motion[name] = 0
                    self.timer.update(name, 0, self.dt)
                    self.inactive[name] = self.timer.inactive[name]
        else:
            for r in self.regions:
                motion[r[0]] = -1 if r[8] else ""
        self.prev = gray
        criterion = self.provisional_s if time_s < self.provisional_until_s else self.official_s
        asleep = sum(1 for v in self.inactive.values() if v >= criterion)
        awake = len(self.inactive) - asleep
        snap = {"frame": self.frame_index, "time_s": time_s, "criterion_s": criterion,
                "asleep": asleep, "awake": awake, "motion": motion,
                "image_name": image_name, "timestamp": timestamp,
                "provisional": criterion != self.official_s}
        if self._csv_writer is not None:
            self._csv_writer.writerow([image_name, timestamp, self.frame_index, f"{time_s:.3f}",
                                       f"{criterion:g}", asleep, awake] + [motion[n] for n in self.names])
            self._csv_file.flush()
        return snap


class LiveSleepWorker:
    """Runs a LiveSleepEngine on its own thread so the camera thread never waits on analysis."""

    def __init__(self, engine, on_update=None, on_error=None):
        self.engine = engine
        self.on_update = on_update or (lambda snap: None)
        self.on_error = on_error or (lambda text: None)
        self._queue = queue.Queue()
        self.shake_settle_seconds = 2.0
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._failed = False
        self._thread.start()

    def submit(self, frame, image_name="", timestamp=""):
        if not self._failed:
            self._queue.put((frame.copy(), image_name, timestamp))

    def backlog(self):
        return self._queue.qsize()

    def _run(self):
        pending = deque()
        stopping = False
        while True:
            try:
                item = self._queue.get(timeout=0.1)
                if item is None:
                    stopping = True
                else:
                    pending.append((time.monotonic(), item))
            except queue.Empty:
                pass
            while pending and (stopping or time.monotonic() - pending[0][0] >= self.shake_settle_seconds):
                _, item = pending.popleft()
                try:
                    self.on_update(self.engine.process(*item))
                except Exception as exc:
                    if not self._failed:
                        self._failed = True
                        self.on_error(f'Live sleep tracking stopped: {exc}')
            if stopping and not pending:
                break

    def stop(self, wait=True, timeout=30.0):
        """Finish everything already queued, then close the CSV."""
        self._queue.put(None)
        if wait:
            self._thread.join(timeout=timeout)
        self.engine.close()


def replay_frames(engine, frames_dir, timestamps_csv=None):
    """Feed saved frames through the engine in numeric order (used by at-home re-analysis).

    Shaking frames (SK_ names) are fed too, so the engine sees the same gaps as the live run;
    it skips them using its shaker windows or, when no shaker log is set, by their SK_ name.
    """
    stamps = {}
    if timestamps_csv and Path(timestamps_csv).exists():
        with open(timestamps_csv, newline="", encoding="utf-8") as f:
            stamps = {base_name(r["image_name"]): r["timestamp"] for r in csv.DictReader(f)}
    files = [p for p in Path(frames_dir).glob("*.png")]
    files.sort(key=lambda p: (frame_number(p) if frame_number(p) >= 0 else 10 ** 12, base_name(p.name)))
    last = None
    for path in files:
        stamp = stamps.get(base_name(path.name), "")
        shaking = path.name.startswith("SK_")
        img = None if shaking else cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
        if img is None and not shaking:
            raise FileNotFoundError(f"Could not read {path}")
        last = engine.process(img, path.name, stamp, force_shaking=shaking)
    return last
