from __future__ import annotations

import csv
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path

import cv2
import numpy as np
from PyQt6.QtCore import QObject, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QImage, QPixmap
from PyQt6.QtWidgets import (
    QApplication, QComboBox, QDialog, QFileDialog, QFormLayout, QGridLayout, QHBoxLayout, QLabel,
    QLineEdit, QMainWindow, QMessageBox, QPushButton, QVBoxLayout, QWidget, QTabWidget, QScrollArea, QCheckBox
)

from calibration_tools import (check_source, complete_counts, copy_grid, copy_thresholds, find_latest_calibration,
                               grid_overlay, uncalibrated_wells)
from camera_service import CameraService
from config_writer import write_cams_config
from disk_check import check_free_space, fmt_bytes
from live_engine import LiveSleepEngine, LiveSleepWorker
from shaker_service import ShakerService
from timestamp_sync import build_alignment
from ui_reanalysis import ReanalysisDialog
from video_tools import make_video
from cams.shake_frames import SETTINGS_FILE, buffer_seconds_from_settings, burst_seconds_from_settings, flag_frames, load_windows, write_report

APP_DIR = Path(__file__).resolve().parent
CAMS_DIR = APP_DIR / "cams"
DEMO_MODE = os.environ.get("FLYSHAKER_DEMO", "0") == "1"
# Save destination. Point FLYSHAKER_ROOT at the external drive, e.g. /media/pi/MyDrive/FS_IMG
EXPERIMENT_ROOT = Path(os.environ.get("FLYSHAKER_ROOT", Path.home() / "FS_IMG"))
CAMERA_DEVICE = "/dev/video0"
CAMERA_WIDTH = 1280
CAMERA_HEIGHT = 800
CAMERA_FPS = 30
SERIAL_PORT = "/dev/ttyUSB0"
BAUD = 115200
ANALYSIS_BATCH_IMAGES = 300
SYNC_THRESHOLD_SECONDS = 3.0
PROVISIONAL_SLEEP_SECONDS = 30      # live sleep criterion during the first 5 minutes of the experiment
PROVISIONAL_UNTIL_SECONDS = 300
CALIB_NEW, CALIB_GRID, CALIB_BOTH, CALIB_SELECT = "new", "grid", "grid_thresholds", "selective"
SHAKE_BUFFER_SECONDS = 1.0   # frames this close before/after a burst are also flagged SK_
AMP_MAX = 30  # ESP amplitude range is 0-30 (see shakerTerminal v6)


class Bridge(QObject):
    log = pyqtSignal(str)
    stage = pyqtSignal(str)
    analysis_done = pyqtSignal(int, int)
    fatal = pyqtSignal(str)
    calibration_ready = pyqtSignal()
    experiment_finished = pyqtSignal()
    start_actual = pyqtSignal()
    calibration_only_done = pyqtSignal()
    live_update = pyqtSignal(object)
    call_main = pyqtSignal(object)     # run a callable on the GUI thread (used by worker threads)


def parse_pair(text: str, name: str):
    cleaned = text.strip().replace("(", "").replace(")", "")
    parts = [p.strip() for p in cleaned.split(",")]
    if len(parts) != 2:
        raise ValueError(f"{name} must be entered as min,max (example: 50,100).")
    a, b = float(parts[0]), float(parts[1])
    if a > b:
        raise ValueError(f"{name}: minimum cannot exceed maximum.")
    return (a, b)


class HandbookDialog(QDialog):
    """Reference handbook; all sections are collapsible."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("FlyShaker v1.7 Handbook")
        self.resize(850, 640)
        root = QVBoxLayout(self)
        tabs = QTabWidget(); root.addWidget(tabs)
        sections = {
            "Shaker": [
                ("Frequency", "Requested oscillation frequency in Hz. Enter min,max; the ESP firmware determines how ranges are selected."),
                ("Amplitude", "Requested shaking intensity (0–30 firmware units), not necessarily millimeters."),
                ("DUTY", "Requested control-signal duty cycle as a percentage (0–100). The ESP firmware determines its electrical meaning."),
                ("Burst", "Requested duration of an individual shaking burst in seconds. Enter min,max. Actual behavior depends on ESP firmware."),
                ("BSilence", "Requested silence between bursts in seconds. Enter min,max."),
                ("Sequence", "Requested total duration of a shaking sequence in seconds. Enter min,max."),
                ("SSilence", "Requested silence between sequences in seconds. Enter min,max."),
                ("Session", "Total experiment duration, entered as hours, minutes and seconds. Converted to seconds for the ESP and experiment timer."),
                ("Death Timer", "How long a fly must be classified asleep before it would be considered dead. Hours/minutes/seconds; all zero = off. In this version the value is only saved with the experiment (experiment_settings.json); no death classification is performed yet."),
                ("Shaking frames (SK_)", "Images captured during a shaker burst, plus 1 second before and after, are renamed SK_frame_XXXXXX.png when the experiment ends. They are never deleted, stay in the video, and are skipped by every CAMS analysis step. shake_flag_report.txt in the experiment folder says how many were flagged."),
                ("Initiation", "Duration of image acquisition before calibration and the actual experiment. Images are used to establish the well grid, background, and motion thresholds."),
            ],
            "CAMS": [
                ("Well Grid", "Mark well centers and radii in the well-grid tuner, or reuse a previously saved grid. Verify alignment when reusing."),
                ("Measure Activity", "Compare successive images within each well to calculate normalized image-change Activity Units (AU). Create a median background and per-well activity CSV."),
                ("Motion Threshold", "Inspect frame sequences and select a movement AU threshold for each well. Motion is detected only when AU exceeds its threshold. Right-click excludes a well (-1)."),
                ("Begin Experiment", "Capture initiation frames, calibrate or reuse CAMS metadata, then begin the timed shaker session and live imaging."),
                ("Classify Sleep", "During the first five minutes, display active/inactive based on 30 seconds of inactivity; do not call this sleep. After five minutes, sleep requires 300 seconds of inactivity. Official CAMS classification always uses 300 seconds."),
                ("Generate Data", "Save image and timestamp records, activity CSVs, sleep classifications, plots, and experiment video to the experiment folder."),
            ]
        }
        for tab_name, entries in sections.items():
            page = QWidget(); layout = QVBoxLayout(page)
            for heading, description in entries:
                button = QPushButton(heading + "  ▾"); button.setCheckable(True)
                description_label = QLabel(description); description_label.setWordWrap(True)
                description_label.setStyleSheet("background: #cbd4dd; color: #111; padding: 12px;")
                description_label.setVisible(False)
                button.toggled.connect(description_label.setVisible)
                layout.addWidget(button); layout.addWidget(description_label)
            layout.addStretch()
            scroll = QScrollArea(); scroll.setWidgetResizable(True); scroll.setWidget(page)
            tabs.addTab(scroll, tab_name)


class SettingsDialog(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Fly Shaker Settings")
        self.setMinimumWidth(580)
        self.values = None
        outer = QVBoxLayout(self)
        title = QLabel("SETTINGS")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet("font-size: 22px; font-weight: bold;")
        outer.addWidget(title)
        form = QFormLayout()
        self.ips = QLineEdit("1")
        self.freq = QLineEdit("50,100")
        self.amp = QLineEdit("6,10")
        self.duty = QLineEdit("50,50")
        self.burst = QLineEdit("3,3")
        self.death_hr = QLineEdit("0")
        self.death_min = QLineEdit("0")
        self.death_sec = QLineEdit("0")
        self.bsilence = QLineEdit("120,120")
        self.sequence = QLineEdit("120,120")
        self.ssilence = QLineEdit("0,0")
        self.session_hr = QLineEdit("0")
        self.session_min = QLineEdit("5")
        self.session_sec = QLineEdit("0")
        self.initiation = QLineEdit("120")
        form.addRow("Images per second", self.ips)
        form.addRow("Frequency (min,max)", self.freq)
        form.addRow("Amplitude (min,max)", self.amp)
        form.addRow("DUTY (min,max)", self.duty)
        form.addRow("Burst (min,max seconds)", self.burst)
        death_row = QHBoxLayout()
        for label, field in (("hr", self.death_hr), ("min", self.death_min), ("s", self.death_sec)):
            death_row.addWidget(QLabel(label)); death_row.addWidget(field)
        form.addRow("Death Timer (time asleep = dead; 0 = off)", death_row)
        form.addRow("BSilence (min,max)", self.bsilence)
        form.addRow("Sequence (min,max)", self.sequence)
        form.addRow("SSilence (min,max)", self.ssilence)
        session_row = QHBoxLayout()
        for label, field in (("hr", self.session_hr), ("min", self.session_min), ("s", self.session_sec)):
            session_row.addWidget(QLabel(label)); session_row.addWidget(field)
        form.addRow("Session", session_row)
        form.addRow("Initiation (seconds)", self.initiation)
        self.calib = QComboBox()
        self.calib.addItem("Calibrate new grid and thresholds", CALIB_NEW)
        self.calib.addItem("Reuse well grid (re-tune thresholds)", CALIB_GRID)
        self.calib.addItem("Reuse well grid and thresholds", CALIB_BOTH)
        self.calib.addItem("Reuse thresholds; recalibrate selected wells", CALIB_SELECT)
        self.calib.currentIndexChanged.connect(self._calib_changed)
        form.addRow("Calibration", self.calib)
        src_row = QHBoxLayout()
        self.calib_source = QLineEdit()
        self.calib_source.setPlaceholderText("Experiment folder to reuse from")
        latest = find_latest_calibration(EXPERIMENT_ROOT)
        if latest:
            self.calib_source.setText(str(latest))
        self.calib_browse = QPushButton("Browse...")
        self.calib_browse.clicked.connect(self._browse_calib)
        src_row.addWidget(self.calib_source, 1)
        src_row.addWidget(self.calib_browse)
        form.addRow("Reuse from", src_row)
        self._calib_changed()
        outer.addLayout(form)
        handbook = QPushButton("Handbook...")
        handbook.clicked.connect(lambda: HandbookDialog(self).exec())
        outer.addWidget(handbook)
        calibrate = QPushButton("Motion threshold calibration only...")
        calibrate.clicked.connect(self._standalone_calibration)
        outer.addWidget(calibrate)
        note = QLabel("For other settings, open CAMS/config.")
        note.setWordWrap(True)
        outer.addWidget(note)
        analyze = QPushButton("Analyze existing experiment...")
        analyze.clicked.connect(lambda: ReanalysisDialog(EXPERIMENT_ROOT, CAMS_DIR, self).exec())
        outer.addWidget(analyze)
        buttons = QHBoxLayout()
        cancel = QPushButton("Cancel")
        start = QPushButton("Create Experiment")
        cancel.clicked.connect(self.reject)
        start.clicked.connect(lambda: self._accept())
        buttons.addWidget(cancel)
        buttons.addWidget(start)
        outer.addLayout(buttons)

    def _calib_changed(self):
        reuse = self.calib.currentData() != CALIB_NEW
        self.calib_source.setEnabled(reuse)
        self.calib_browse.setEnabled(reuse)

    def _browse_calib(self):
        d = QFileDialog.getExistingDirectory(self, "Select experiment to reuse calibration from", str(EXPERIMENT_ROOT))
        if d:
            self.calib_source.setText(d)

    def _accept(self, calibration_only=False):
        try:
            ips = float(self.ips.text())
            parts = [int(x.text().strip()) for x in (self.session_hr, self.session_min, self.session_sec)]
            if any(x < 0 for x in parts) or parts[1] >= 60 or parts[2] >= 60:
                raise ValueError("Session requires nonnegative hours, and minutes/seconds between 0 and 59.")
            session = parts[0]*3600 + parts[1]*60 + parts[2]
            initiation = float(self.initiation.text())
            if ips <= 0 or session <= 0 or initiation < 0:
                raise ValueError("Images/second and session must be > 0; initiation must be >= 0.")
            freq = parse_pair(self.freq.text(), "Frequency")
            amp = parse_pair(self.amp.text(), "Amplitude")
            duty = parse_pair(self.duty.text(), "DUTY")
            seq = parse_pair(self.sequence.text(), "Sequence")
            ssil = parse_pair(self.ssilence.text(), "SSilence")
            bsil = parse_pair(self.bsilence.text(), "BSilence")
            burst = parse_pair(self.burst.text(), "Burst")
            death_parts = [int(x.text().strip()) for x in (self.death_hr, self.death_min, self.death_sec)]
            if any(x < 0 for x in death_parts) or death_parts[1] >= 60 or death_parts[2] >= 60:
                raise ValueError("Death Timer requires nonnegative hours, and minutes/seconds between 0 and 59.")
            death_timer = death_parts[0]*3600 + death_parts[1]*60 + death_parts[2]
            if burst[0] <= 0: raise ValueError("Burst must be greater than zero.")
            if freq[0] <= 0:
                raise ValueError("Frequency must be greater than 0 Hz.")
            if amp[0] < 0 or amp[1] > AMP_MAX:
                raise ValueError(f"Amplitude must be between 0 and {AMP_MAX}.")
            if duty[0] < 0 or duty[1] > 100:
                raise ValueError("DUTY must be between 0 and 100 (%).")
            if seq[0] <= 0 or ssil[0] < 0 or bsil[0] < 0:
                raise ValueError("Sequence must be > 0; SSilence and BSilence must be >= 0.")
            mode = self.calib.currentData()
            source = None
            if mode != CALIB_NEW:
                source = self.calib_source.text().strip()
                ok, msg = check_source(source, need_thresholds=(mode in (CALIB_BOTH, CALIB_SELECT)))
                if not ok:
                    raise ValueError(msg)
            if session < seq[1] and not calibration_only:
                raise ValueError("Session must be at least as long as the longest sequence.")
            if initiation * ips < 2:
                raise ValueError("Initiation must capture at least 2 images (CAMS needs 2 frames to measure activity).")
            values = {
                "images_per_second": ips,
                "freq": freq, "amp": amp, "duty": duty,
                "sequence": seq, "ssilence": ssil, "bsilence": bsil, "burst": burst,
                "calibration_mode": mode, "calibration_source": source,
                "session": session,
                "initiation": initiation, "death_timer": death_timer,
                "force_calibration_only": bool(calibration_only),
            }
        except Exception as exc:
            QMessageBox.warning(self, "Invalid setting", str(exc))
            return
        # A calibration-only run never records the experiment, so only initiation needs disk space.
        space_values = dict(values, session=0) if calibration_only else values
        if not self._space_ok(space_values):
            return                      # stay on this window; nothing has been created or started
        self.values = values
        self.accept()

    def _standalone_calibration(self):
        box = QMessageBox(self)
        box.setWindowTitle("Motion threshold calibration")
        box.setIcon(QMessageBox.Icon.Question)
        box.setText("Use a pre-existing experiment?")
        yes = box.addButton("Yes", QMessageBox.ButtonRole.YesRole)
        no = box.addButton("No", QMessageBox.ButtonRole.NoRole)
        box.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)
        box.exec()
        clicked = box.clickedButton()
        if clicked is no:
            self._accept(calibration_only=True)     # validates, closes this window, main window runs initiation
            return
        if clicked is not yes:
            return
        folder = QFileDialog.getExistingDirectory(self, "Select existing experiment", str(EXPERIMENT_ROOT))
        if not folder: return
        try:
            from standalone_calibration import run_standalone
            run_standalone(Path(folder), CAMS_DIR, self)
        except Exception as exc:
            QMessageBox.critical(self, "Calibration failed", str(exc))

    def _space_ok(self, v):
        try:
            ok, required, free, where, images = check_free_space(
                EXPERIMENT_ROOT, v["images_per_second"], v["session"], v["initiation"])
        except OSError as exc:
            QMessageBox.critical(
                self, "Save location unavailable",
                f"Cannot check the save location:\n{EXPERIMENT_ROOT}\n\n{exc}\n\n"
                "No experiment was created. Fix the location and press Create Experiment again.")
            return False
        if ok:
            return True
        QMessageBox.critical(
            self, "Not enough free space",
            f"This experiment needs about {fmt_bytes(required)} "
            f"({images:,} images + overhead and a safety reserve),\n"
            f"but only {fmt_bytes(free)} is free on the drive holding:\n{where}\n\n"
            "No experiment was created and nothing was started.\n"
            "Free up space, connect the external drive (FLYSHAKER_ROOT), or shorten the "
            "session/initiation, then press Create Experiment again.")
        return False


def next_experiment(root: Path):
    root.mkdir(parents=True, exist_ok=True)
    n = 1
    while (root / f"exp{n:05d}").exists():
        n += 1
    return root / f"exp{n:05d}", f"{n:05d}"


def fmt_mmss(seconds):
    seconds = int(max(0, seconds))
    return f"{seconds // 60}:{seconds % 60:02d}"


def fmt_range(pair, unit=""):
    lo, hi = pair
    text = f"{lo:g}" if lo == hi else f"{lo:g}-{hi:g}"
    return f"{text} {unit}".strip()


def frame_to_pixmap(frame):
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    rgb = np.ascontiguousarray(rgb)
    h, w, ch = rgb.shape
    img = QImage(rgb.data, w, h, ch * w, QImage.Format.Format_RGB888).copy()
    return QPixmap.fromImage(img)


class MainWindow(QMainWindow):
    def __init__(self, settings):
        super().__init__()
        self.settings = settings
        self.setWindowTitle("Fly Shaker / CAMS Experiment")
        self.resize(1050, 760)
        self.bridge = Bridge()
        self.bridge.log.connect(self._log)
        self.bridge.stage.connect(self._set_stage)
        self.bridge.analysis_done.connect(self._analysis_update)
        self.bridge.fatal.connect(self._fatal)
        self.bridge.calibration_ready.connect(self._calibration_prompt)
        self.bridge.experiment_finished.connect(self._finished_message)
        self.bridge.start_actual.connect(self.start_actual_experiment)
        self.bridge.calibration_only_done.connect(self._finish_calibration_only)
        self.bridge.live_update.connect(self._live_update)
        self.bridge.call_main.connect(lambda fn: fn())
        self.experiment_dir, self.experiment_id = next_experiment(EXPERIMENT_ROOT)
        self.frames_dir = self.experiment_dir / "frames"
        self.initiation_dir = self.experiment_dir / "initiation_frames"
        self.frames_dir.mkdir(parents=True, exist_ok=False)
        self.initiation_dir.mkdir(parents=True, exist_ok=False)
        self._write_experiment_settings()
        # Calibration tools (grid, background, thresholds) read the initiation images.
        write_cams_config(CAMS_DIR, self.experiment_dir, settings["images_per_second"],
                          frames_subdir="initiation_frames")
        self.camera = None
        self.shaker = ShakerService(self.bridge.log.emit)
        self.latest_sleep = None
        self.latest_awake = None
        self.actual_phase_saved = 0
        self.analysis_running = False
        self.next_analysis_at = ANALYSIS_BATCH_IMAGES
        self.stop_requested = False
        self.experiment_started_at = None
        self.phase = "setup"          # setup -> initiation -> calibration -> running -> stopped
        self.analysis_lock = threading.Lock()   # CAMS scripts rewrite the same CSVs; never run two at once
        self.current_proc = None
        self.aborted = False
        self.calibration_only = bool(settings.get("force_calibration_only", False))
        self._csv_pos = 0
        self.live_worker = None
        self._last_freq = self._last_amp = "-"
        self._backlog_warned = False

        central = QWidget(); self.setCentralWidget(central)
        root = QVBoxLayout(central)
        stats = QGridLayout()
        self.last_label = QLabel("Last shake: -")
        self.elapsed_label = QLabel("Time elapsed: 00:00")
        self.since_label = QLabel("Time since last shake: -")
        
        self.sleep_label = QLabel("Sleep: -")
        self.awake_label = QLabel("Awake: -")
        for w in (self.last_label, self.elapsed_label, self.since_label,
                  self.sleep_label, self.awake_label):
            w.setStyleSheet("font-size: 20px;")
        self.criterion_label = QLabel("Sleep criterion: -")
        self.official_label = QLabel("Official CAMS check (every 5 min): -")
        for w in (self.criterion_label, self.official_label):
            w.setStyleSheet("font-size: 13px; color: #555;")
        stats.addWidget(self.last_label, 0, 0); stats.addWidget(self.elapsed_label, 0, 1)
        stats.addWidget(self.since_label, 1, 0)
        stats.addWidget(self.sleep_label, 2, 0); stats.addWidget(self.awake_label, 2, 1)
        stats.addWidget(self.criterion_label, 3, 0); stats.addWidget(self.official_label, 3, 1)
        root.addLayout(stats)
        self.preview = QLabel("Preparing camera...")
        self.preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview.setMinimumSize(720, 480)
        self.preview.setStyleSheet("background: #222; color: white;")
        root.addWidget(self.preview, 1)
        bottom = QHBoxLayout()
        self.stage_label = QLabel("Stage: setup")
        self.exp_label = QLabel(f"{self.experiment_dir}")
        self.stop_btn = QPushButton("Stop Experiment")
        self.stop_btn.setEnabled(False)
        self.stop_btn.clicked.connect(self.stop_experiment)
        bottom.addWidget(self.stage_label); bottom.addStretch(1); bottom.addWidget(self.exp_label); bottom.addWidget(self.stop_btn)
        root.addLayout(bottom)
        self.log_label = QLabel("")
        self.log_label.setWordWrap(True)
        root.addWidget(self.log_label)

        self.preview_timer = QTimer(self)
        self.preview_timer.timeout.connect(self._refresh_preview)
        self.preview_timer.start(70)
        self.csv_timer = QTimer(self)
        self.csv_timer.timeout.connect(self._poll_shaker_csv)
        self.csv_timer.start(250)
        self.clock_timer = QTimer(self)
        self.clock_timer.timeout.connect(self._tick_labels)
        self.clock_timer.start(1000)
        QTimer.singleShot(100, self.start_initiation)

    def _write_experiment_settings(self):
        """Persist the settings that later analysis needs (burst length, buffers, death timer)."""
        data = {k: (list(v) if isinstance(v, tuple) else v) for k, v in self.settings.items()}
        data["shake_buffer_seconds"] = SHAKE_BUFFER_SECONDS
        data["experiment_id"] = self.experiment_id
        (self.experiment_dir / SETTINGS_FILE).write_text(json.dumps(data, indent=2, default=str), encoding="utf-8")

    def _log(self, text):
        self.log_label.setText(str(text))
        print(text, flush=True)

    def _set_stage(self, text):
        self.stage_label.setText("Stage: " + text)

    def _fatal(self, text):
        if self.stop_requested:
            return
        QMessageBox.critical(self, "Experiment error", text)
        if self.phase == "running":
            self.stop_experiment()
        else:
            self._abort_before_experiment()

    def _abort_before_experiment(self):
        """Error/cancel during initiation or calibration: nothing to finalize, just release hardware."""
        self.stop_requested = True
        self.aborted = True
        self.phase = "stopped"
        self._terminate_proc()
        self.shaker.close()
        if self.camera:
            self.camera.stop()
        self._stop_live_worker()
        self.stop_btn.setEnabled(False)
        self.bridge.stage.emit("aborted before experiment start")
        self._log(f"Experiment aborted before the shaker started. Partial data kept in {self.experiment_dir}")

    def on_main(self, fn):
        """Run fn on the GUI thread from a worker thread and return its result."""
        box, done = {}, threading.Event()

        def call():
            try:
                box["v"] = fn()
            finally:
                done.set()
        self.bridge.call_main.emit(call)
        while not done.wait(0.2):
            if self.stop_requested:
                raise RuntimeError("Cancelled.")
        return box.get("v")

    def _stop_live_worker(self, timeout=10.0):
        worker, self.live_worker = self.live_worker, None
        if worker is not None:
            worker.stop(wait=True, timeout=timeout)

    def _terminate_proc(self):
        proc = self.current_proc
        if proc is not None and proc.poll() is None:
            proc.terminate()

    def start_initiation(self):
        self.phase = "initiation"
        self.bridge.stage.emit("initiation capture")
        try:
            self._open_camera()
            self.camera.start_saving(
                self.initiation_dir, self.experiment_dir / f"initiation_timestamps_{self.experiment_id}.csv", 1)
        except Exception as exc:
            self.bridge.fatal.emit(str(exc))
            return
        duration = self.settings["initiation"]
        self._log(f"Initiation capture started for {duration:g} seconds. Images are saving in {self.initiation_dir}.")
        QTimer.singleShot(max(1, int(duration * 1000)), self._finish_initiation)

    def _open_camera(self):
        """Open the camera once; it stays open (live preview, stable auto-exposure) until the end."""
        if self.camera is not None:
            return
        self.camera = CameraService(
            camera_device=CAMERA_DEVICE, width=CAMERA_WIDTH, height=CAMERA_HEIGHT, fps=CAMERA_FPS,
            images_per_second=self.settings["images_per_second"], demo_mode=DEMO_MODE,
            status_callback=self.bridge.log.emit, image_saved_callback=self._image_saved,
            fatal_callback=self.bridge.fatal.emit
        )
        self.camera.open()

    def _finish_initiation(self):
        if self.stop_requested:
            return
        if self.camera:
            self.camera.stop_saving()   # camera itself stays open
        self.bridge.stage.emit("initiation complete")
        self.bridge.calibration_ready.emit()

    def _calibration_prompt(self):
        self.phase = "calibration"
        mode, src = self.settings["calibration_mode"], self.settings["calibration_source"]
        if mode == CALIB_NEW:
            steps = "1. well_grid_tuner.py\n2. measure_activity.py\n3. motion_threshold_tuner.py"
        elif mode == CALIB_GRID:
            steps = (f"1. Saved well grid from {src} is shown for you to confirm\n"
                     "2. measure_activity.py\n3. motion_threshold_tuner.py")
        else:
            steps = (f"1. Saved well grid and thresholds from {src} are shown for you to confirm\n"
                     "2. measure_activity.py\n3. motion_threshold_tuner.py only for wells that still need a threshold "
                     "(wells that were excluded before are offered again)")
        if self.calibration_only:
            threading.Thread(target=self._run_calibration, daemon=True).start()
            return
        dialog = QMessageBox(self)
        dialog.setWindowTitle("Initiation complete")
        dialog.setIcon(QMessageBox.Icon.Information)
        dialog.setText("Initiation images are complete. Choose how to continue.")
        dialog.setInformativeText(
            f"CAMS calibration steps:\n\n{steps}\n\n"
            "Both options complete calibration. Threshold only saves the results "
            "and exits without starting the shaker experiment.")
        full_btn = dialog.addButton("Calibrate and begin experiment", QMessageBox.ButtonRole.AcceptRole)
        only_btn = dialog.addButton("Separate thresholding (save and exit)", QMessageBox.ButtonRole.ActionRole)
        cancel_btn = dialog.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)
        dialog.exec()
        clicked = dialog.clickedButton()
        if clicked == cancel_btn or clicked is None:
            self._abort_before_experiment()
            return
        self.calibration_only = clicked == only_btn
        threading.Thread(target=self._run_calibration, daemon=True).start()

    def _confirm_grid_overlay(self):
        """GUI thread: show the reused grid on the latest initiation frame; True = aligned."""
        frames = sorted(self.initiation_dir.glob("*.png"))
        wells_csv = self.experiment_dir / f"plate_wells_{self.experiment_dir.name}.csv"
        if not frames:
            return True
        pix = frame_to_pixmap(grid_overlay(frames[-1], wells_csv))
        if pix.width() > 1000:
            pix = pix.scaledToWidth(1000, Qt.TransformationMode.SmoothTransformation)
        dlg = QDialog(self)
        dlg.setWindowTitle("Confirm reused well grid")
        lay = QVBoxLayout(dlg)
        lay.addWidget(QLabel("Do the circles sit on the wells? If the plate or camera moved since the grid was saved, redraw it."))
        img = QLabel()
        img.setPixmap(pix)
        lay.addWidget(img)
        row = QHBoxLayout()
        redo = QPushButton("Grid is off - redraw it")
        ok = QPushButton("Grid is aligned - continue")
        redo.clicked.connect(dlg.reject)
        ok.clicked.connect(dlg.accept)
        row.addWidget(redo)
        row.addWidget(ok)
        lay.addLayout(row)
        return dlg.exec() == QDialog.DialogCode.Accepted

    def _ask_retune(self, n):
        return QMessageBox.question(
            self, "Uncalibrated wells",
            f"{n} wells still have threshold 0 (not calibrated and not excluded).\n\nReopen the threshold tuner?"
        ) == QMessageBox.StandardButton.Yes

    def _run_script(self, name):
        path = CAMS_DIR / name
        self.bridge.log.emit(f"Running {name}...")
        self.current_proc = subprocess.Popen([sys.executable, str(path)], cwd=str(CAMS_DIR))
        returncode = self.current_proc.wait()
        if returncode != 0:
            if self.aborted:
                raise RuntimeError(f"{name} was cancelled.")
            raise RuntimeError(f"{name} exited with code {returncode}. "
                               "If you closed a tuner window without saving, restart the experiment.")

    def _select_recalibration(self, csv_path):
        import csv as _csv
        from PyQt6.QtWidgets import QDialogButtonBox
        with open(csv_path, newline="", encoding="utf-8") as f:
            rows = list(_csv.DictReader(f))
        dialog = QDialog(self)
        dialog.setWindowTitle("Select wells to recalibrate")
        layout = QVBoxLayout(dialog)
        layout.addWidget(QLabel("Check wells to reset to 0 AU and recalibrate. Unchecked thresholds are retained."))
        scroll = QScrollArea(); scroll.setWidgetResizable(True)
        inner = QWidget(); il = QVBoxLayout(inner)
        checks = []
        for row in rows:
            c = QCheckBox(f"{row['well']}  (existing: {row['motion_threshold_AU']} AU)")
            il.addWidget(c); checks.append(c)
        scroll.setWidget(inner); layout.addWidget(scroll)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(dialog.accept); buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        if dialog.exec() != QDialog.DialogCode.Accepted: return False
        for row, check in zip(rows, checks):
            if check.isChecked(): row['motion_threshold_AU'] = '0'
        with open(csv_path, 'w', newline='', encoding='utf-8') as f:
            writer = _csv.DictWriter(f, fieldnames=['well','motion_threshold_AU','fly_count','viable_flies'])
            writer.writeheader(); writer.writerows(rows)
        return True

    def _run_calibration(self):
        try:
            mode, src = self.settings["calibration_mode"], self.settings["calibration_source"]
            name = self.experiment_dir.name
            wells_csv = self.experiment_dir / f"plate_wells_{name}.csv"
            thr_csv = self.experiment_dir / "well_threshold.csv"
            if mode != CALIB_NEW:
                copy_grid(src, self.experiment_dir, name)
                if not self.on_main(self._confirm_grid_overlay):
                    wells_csv.unlink(missing_ok=True)
                    mode = CALIB_NEW
                    self.bridge.log.emit("Reused grid rejected - opening the grid tuner.")
                elif mode in (CALIB_BOTH, CALIB_SELECT):
                    # counts belong to the old plate of flies; old exclusions are offered again
                    copy_thresholds(src, self.experiment_dir, reset_counts=True, keep_exclusions=False)
                    if mode == CALIB_SELECT:
                        if not self.on_main(lambda: self._select_recalibration(thr_csv)):
                            raise RuntimeError("Selective threshold recalibration cancelled.")
            if mode == CALIB_NEW:
                self.bridge.stage.emit("well grid tuner")
                self._run_script("well_grid_tuner.py")
            self.bridge.stage.emit("initial activity measurement")
            self._run_script("measure_activity.py")
            # The threshold tuner only offers wells whose threshold is still 0, so it is skipped when
            # every well already has a threshold (or -1). Closing it early re-offers the rest.
            while not thr_csv.exists() or uncalibrated_wells(thr_csv):
                self.bridge.stage.emit("motion threshold tuner")
                self._run_script("motion_threshold_tuner.py")
                left = uncalibrated_wells(thr_csv) if thr_csv.exists() else ["?"]
                if left and not self.on_main(lambda n=len(left): self._ask_retune(n)):
                    raise RuntimeError(f"{len(left)} wells are still uncalibrated. Calibrate or exclude "
                                       "(right-click) every well, then restart the experiment.")
            # classify_sleep.py refuses blank fly_count / viable_flies: default 1 fly per well, 0 if excluded
            filled = complete_counts(thr_csv)
            if filled["filled"]:
                self.bridge.log.emit(f"Filled {filled['filled']} blank fly_count/viable_flies cells "
                                     f"(1 per calibrated well, 0 for {filled['excluded']} excluded wells).")
            if self.calibration_only:
                self.bridge.calibration_only_done.emit()
            else:
                self.bridge.stage.emit("starting actual experiment")
                self.bridge.start_actual.emit()
        except Exception as exc:
            self.bridge.fatal.emit(str(exc))

    def _finish_calibration_only(self):
        """Leave calibrated initiation data in place; never start shaker or experiment capture."""
        if self.stop_requested:
            return
        self.stop_requested = True
        self.phase = "stopped"
        self.shaker.close()
        if self.camera:
            self.camera.stop()
        self._stop_live_worker()
        self.stop_btn.setEnabled(False)
        self.bridge.stage.emit("threshold calibration saved (no experiment started)")
        self._log(f"Calibration-only complete. Files saved in {self.experiment_dir}")
        QMessageBox.information(
            self, "Threshold calibration saved",
            "Motion threshold calibration is complete. The experiment pipeline has exited "
            "without starting the shaker.\n\n"
            f"Initiation images, well grid, activity measurements, and thresholds remain saved in:\n"
            f"{self.experiment_dir}")

    def _switch_to_experiment_frames(self):
        """Archive the initiation-phase activity CSVs and point CAMS at frames/."""
        name = self.experiment_dir.name
        for src, dst in ((f"{name}.csv", "initiation_activity.csv"), (f"{name}_plate.csv", "initiation_plate.csv")):
            path = self.experiment_dir / src
            if path.exists():
                shutil.move(str(path), str(self.initiation_dir / dst))
        write_cams_config(CAMS_DIR, self.experiment_dir, self.settings["images_per_second"], frames_subdir="frames")

    def start_actual_experiment(self):
        if self.stop_requested:
            return
        numbers = [int(m.group(1)) for p in self.frames_dir.glob("*frame_*.png")
                   if (m := re.fullmatch(r"(?:SK_)?frame_(\d+)\.png", p.name))]
        next_number = max(numbers, default=0) + 1
        self._csv_pos = 0
        self.actual_phase_saved = 0
        self.next_analysis_at = ANALYSIS_BATCH_IMAGES
        try:
            self._switch_to_experiment_frames()
            engine = LiveSleepEngine.from_cams_config(
                CAMS_DIR, provisional_s=PROVISIONAL_SLEEP_SECONDS, provisional_until_s=PROVISIONAL_UNTIL_SECONDS)
            engine.set_shaker_log(self.experiment_dir / f"shaker_timestamps_{self.experiment_id}.csv",
                                  burst_seconds_from_settings(self.settings), SHAKE_BUFFER_SECONDS)
            engine.attach_csv(self.experiment_dir / "sleep_timer.csv")
            self.live_worker = LiveSleepWorker(engine, on_update=self.bridge.live_update.emit,
                                               on_error=self.bridge.log.emit)
            self._open_camera()          # no-op: the camera has been open since initiation
            self.camera.start_saving(
                self.frames_dir, self.experiment_dir / f"image_timestamps_{self.experiment_id}.csv", next_number)
            self.shaker.start(
                self.experiment_dir, self.experiment_id, SERIAL_PORT, BAUD,
                self.settings, demo_mode=DEMO_MODE
            )
            self.shaker.start_experiment()
        except Exception as exc:
            self._stop_live_worker(timeout=2.0)
            self.bridge.fatal.emit(str(exc))   # phase is still "calibration" -> clean abort
            return
        self.phase = "running"
        self.experiment_started_at = time.monotonic()
        self.stop_btn.setEnabled(True)
        self.bridge.stage.emit("experiment running")
        self._log(f"Actual experiment started for {self.settings['session']:g} seconds.")
        QTimer.singleShot(int(self.settings["session"] * 1000), self.stop_experiment)

    def _image_saved(self, count, path, ts, frame):
        # Every experiment frame goes to the live engine (also the first few before the shaker
        # has started), in order. Initiation frames arrive while live_worker is None and are skipped.
        worker = self.live_worker
        if worker is not None:
            worker.submit(frame, Path(path).name, ts)
            if worker.backlog() > 30 and not self._backlog_warned:
                self._backlog_warned = True
                self.bridge.log.emit("WARNING: live sleep tracking is falling behind the camera.")
        # CameraService count resets when actual acquisition starts, so it naturally
        # excludes initiation images from the 300-new-image trigger.
        if self.experiment_started_at is None:
            return
        self.actual_phase_saved = count
        if self.stop_requested:
            return
        if count >= self.next_analysis_at and not self.analysis_running:
            self.next_analysis_at += ANALYSIS_BATCH_IMAGES
            self.analysis_running = True
            threading.Thread(target=self._periodic_analysis, daemon=True).start()

    def _periodic_analysis(self):
        try:
            with self.analysis_lock:
                self.bridge.stage.emit("CAMS 300-image update")
                self._run_script("measure_activity.py")
                self._run_script("classify_sleep.py")
                asleep, awake = self._latest_plate_counts()
                self._append_sleep_data(asleep, awake)
            self.bridge.analysis_done.emit(asleep, awake)
        except Exception as exc:
            self.bridge.log.emit(f"Periodic CAMS analysis warning: {exc}")
        finally:
            self.analysis_running = False
            if not self.stop_requested:
                self.bridge.stage.emit("experiment running")

    def _latest_plate_counts(self):
        plate = self.experiment_dir / f"{self.experiment_dir.name}_plate.csv"
        with plate.open(newline="", encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
        if not rows:
            return 0, 0
        row = rows[-1]
        return int(float(row.get("sleeping_wells") or 0)), int(float(row.get("awake_wells") or 0))

    def _append_sleep_data(self, asleep, awake):
        path = self.experiment_dir / "sleep_data.csv"
        new = not path.exists()
        with path.open("a", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            if new:
                w.writerow(["timestamp", "captured_experiment_images", "sleeping_wells", "awake_wells", "criterion_s"])
            w.writerow([time.strftime("%Y-%m-%dT%H:%M:%S"), self.actual_phase_saved, asleep, awake, 300])

    def _analysis_update(self, asleep, awake):
        """Official CAMS (classify_sleep) result: every 300 images and at the end."""
        self.latest_sleep, self.latest_awake = asleep, awake
        self.official_label.setText(f"Official CAMS check ({time.strftime('%H:%M:%S')}): sleep {asleep} / awake {awake}")

    def _live_update(self, snap):
        """Per-image live counts from the sleep-timer engine."""
        if snap["provisional"]:
            self.sleep_label.setText(f"Inactive (30s): {snap['asleep']}")
            self.awake_label.setText(f"Active: {snap['awake']}")
        else:
            self.sleep_label.setText(f"Sleep: {snap['asleep']}")
            self.awake_label.setText(f"Awake: {snap['awake']}")
        if snap["provisional"]:
            left = max(0, PROVISIONAL_UNTIL_SECONDS - snap["time_s"])
            self.criterion_label.setText(
                f"Activity status: inactive after {snap['criterion_s']:g} s (not sleep; "
                f"{fmt_mmss(left)} until sleep classification begins)")
        else:
            self.criterion_label.setText(f"Sleep criterion: {snap['criterion_s']:g} s inactivity (official, live)")

    def _tick_labels(self):
        if self.phase != "running" or self.stop_requested:
            return
        since = self.shaker.seconds_since_last_start()
        self.since_label.setText("Time since last shake: " + ("-" if since is None else fmt_mmss(since)))
        if self.experiment_started_at is not None:
            self.elapsed_label.setText("Time elapsed: " + fmt_mmss(time.monotonic() - self.experiment_started_at))

    def _poll_shaker_csv(self):
        """Read only the bytes appended since the last poll (the log can grow large with REPORT(FULL))."""
        path = self.shaker.csv_path
        if not path or not Path(path).exists():
            return
        try:
            with Path(path).open("rb") as f:
                f.seek(self._csv_pos)
                data = f.read()
            end = data.rfind(b"\n")
            if end < 0:
                return
            self._csv_pos += end + 1
            for row in csv.reader(data[:end + 1].decode("utf-8", "replace").splitlines()):
                if len(row) >= 5 and row[1] == "SEQUENCE_START":
                    self._last_freq, self._last_amp = row[3] or "-", row[4] or "-"
                    self.last_label.setText(f"Last: {self._last_freq} Hz, amp {self._last_amp}")
        except Exception:
            pass

    def _refresh_preview(self):
        if not self.camera:
            return
        frame = self.camera.get_frame()
        if frame is None:
            return
        # Downscale with OpenCV before building the QImage: far cheaper on a Pi than scaling a full pixmap.
        size = self.preview.size()
        h, w = frame.shape[:2]
        scale = min(size.width() / w, size.height() / h)
        if scale < 1:
            frame = cv2.resize(frame, (max(1, int(w * scale)), max(1, int(h * scale))), interpolation=cv2.INTER_AREA)
        self.preview.setPixmap(frame_to_pixmap(frame))

    def stop_experiment(self):
        if self.stop_requested:
            return
        self.stop_requested = True
        self.phase = "stopped"
        self.stop_btn.setEnabled(False)
        self.bridge.stage.emit("stopping")
        try:
            self.shaker.stop_experiment()
        except Exception:
            pass
        self.shaker.close()
        if self.camera:
            self.camera.stop()
        self._stop_live_worker()         # drain queued frames so sleep_timer.csv is complete
        threading.Thread(target=self._finalize, daemon=True).start()

    def _apply_shake_flags(self):
        """Rename shaking frames to SK_<name> after the camera has stopped. Never raises:
        analysis skips shaking frames from the timestamp logs even if a rename fails."""
        try:
            windows = load_windows(self.experiment_dir)
            image_csv = self.experiment_dir / f"image_timestamps_{self.experiment_id}.csv"
            report = flag_frames(self.frames_dir, image_csv, windows)
            lines = write_report(self.experiment_dir, report, windows)
            self.bridge.log.emit(f"Shaking frames flagged: {report['flagged']} of {report['images']} "
                                 f"({report['windows']} bursts).")
            for line in lines:
                if line.startswith(("WARNING", "ERROR")):
                    self.bridge.log.emit(line)
        except Exception as exc:
            self.bridge.log.emit(f"WARNING: could not flag shaking frames: {exc}")

    def _finalize(self):
        try:
            self.bridge.stage.emit("final CAMS analysis")
            # Wait for any periodic update still running, then include the final partial batch.
            with self.analysis_lock:
                self._apply_shake_flags()
                self._run_script("measure_activity.py")
                self._run_script("classify_sleep.py")
                asleep, awake = self._latest_plate_counts()
                self._append_sleep_data(asleep, awake)
            self.bridge.analysis_done.emit(asleep, awake)

            self.bridge.stage.emit("final outputs")
            self._run_script("compare_first_last.py")
            self._run_script("generate_plots.py")
            self._create_video()
            image_csv = self.experiment_dir / f"image_timestamps_{self.experiment_id}.csv"
            shaker_csv = self.experiment_dir / f"shaker_timestamps_{self.experiment_id}.csv"
            build_alignment(image_csv, shaker_csv, self.experiment_dir / "image_shaker_alignment.csv", SYNC_THRESHOLD_SECONDS)
            self.bridge.stage.emit("complete")
            self.bridge.experiment_finished.emit()
        except Exception as exc:
            self.bridge.fatal.emit(str(exc))

    def _create_video(self):
        make_video(self.frames_dir, self.experiment_dir / "experiment.mp4",
                   self.settings["images_per_second"], self.bridge.log.emit)

    def _finished_message(self):
        QMessageBox.information(
            self, "Experiment complete",
            f"Experiment complete.\n\nOutputs: {self.experiment_dir}\n\n"
            "Final CAMS plots/comparisons, experiment.mp4, sleep_data.csv, sleep_timer.csv, and the timestamp alignment CSV have been created."
        )

    def closeEvent(self, event):
        if self.phase == "running" and not self.stop_requested:
            answer = QMessageBox.question(
                self, "Experiment running",
                "An experiment is running. Stop the shaker and close?\n"
                "(Final analysis, plots and video will NOT be generated.)")
            if answer != QMessageBox.StandardButton.Yes:
                event.ignore()
                return
        self.stop_requested = True
        try:
            self._terminate_proc()
            self.shaker.stop_experiment()   # otherwise the ESP keeps shaking until SESSION expires
            self.shaker.close()
            if self.camera:
                self.camera.stop()
            self._stop_live_worker(timeout=5.0)
        finally:
            event.accept()


def main():
    app = QApplication(sys.argv)
    settings = SettingsDialog()
    if settings.exec() != QDialog.DialogCode.Accepted:
        return 0
    win = MainWindow(settings.values)
    win.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
