from __future__ import annotations

import csv
import math
import os
import platform
import threading
import time
from datetime import datetime
from pathlib import Path

import cv2
import numpy as np


class CameraService:
    """Keeps the camera open for the whole session and lets the caller choose where
    (and whether) frames are saved.

    The camera is opened once so auto-exposure/white balance settle during initiation and
    are not disturbed again before the experiment. Saving is switched between
    initiation_frames/ and frames/ with start_saving()/stop_saving().
    """

    MAX_CONSECUTIVE_FAILURES = 100  # ~5 s of failed reads

    def __init__(self, camera_device="/dev/video0", width=1280, height=800, fps=30,
                 images_per_second=1.0, demo_mode=False, status_callback=None,
                 image_saved_callback=None, fatal_callback=None):
        self.camera_device = camera_device
        self.width = int(width)
        self.height = int(height)
        self.fps = float(fps)
        self.images_per_second = float(images_per_second)
        self.demo_mode = bool(demo_mode)
        self.status_callback = status_callback or (lambda text: None)
        self.image_saved_callback = image_saved_callback or (lambda count, path, ts, frame: None)
        self.fatal_callback = fatal_callback or (lambda text: None)
        self.running = threading.Event()
        self.thread = None
        self.cap = None
        self.frame_lock = threading.Lock()
        self.latest_frame = None
        self._save_lock = threading.RLock()
        self.saving_enabled = False
        self.frames_dir = None
        self.csv_file = None
        self.csv_writer = None
        self.csv_path = None
        self._tmp_path = None
        self._next_capture = 0.0
        self.image_number = 1
        self.saved_count = 0

    def _emit(self, text):
        try:
            self.status_callback(text)
        except Exception:
            pass

    # ------------------------------------------------------------------ lifecycle
    def open(self):
        """Open the camera and start the preview/capture thread (nothing is saved yet)."""
        if self.images_per_second <= 0:
            raise ValueError("Images per second must be greater than zero.")
        if self.thread is not None and self.thread.is_alive():
            return
        if not self.demo_mode:
            if platform.system() == "Linux":
                self.cap = cv2.VideoCapture(self.camera_device, cv2.CAP_V4L2)
            else:
                index = int(self.camera_device) if str(self.camera_device).isdigit() else 0
                self.cap = cv2.VideoCapture(index)
            if not self.cap.isOpened():
                raise RuntimeError(f"Could not open camera device {self.camera_device}.")
            self.cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.width)
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.height)
            self.cap.set(cv2.CAP_PROP_FPS, self.fps)
            self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)  # avoid saving stale buffered frames
        self.running.set()
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()

    def start_saving(self, frames_dir: Path, csv_path: Path, start_number=1):
        """Begin saving one image every 1/images_per_second s into frames_dir, logging to csv_path."""
        frames_dir, csv_path = Path(frames_dir), Path(csv_path)
        frames_dir.mkdir(parents=True, exist_ok=True)
        new_file = not csv_path.exists()
        csv_file = csv_path.open("a", newline="", encoding="utf-8", buffering=1)
        writer = csv.writer(csv_file)
        if new_file:
            writer.writerow(["image_name", "timestamp"])
            csv_file.flush()
        with self._save_lock:
            self.stop_saving()
            self.frames_dir = frames_dir
            # temp file lives beside (not inside) frames_dir so CAMS never lists it
            self._tmp_path = frames_dir.parent / ".frame_tmp.png"
            self.csv_file, self.csv_writer, self.csv_path = csv_file, writer, csv_path
            self.image_number = int(start_number)
            self.saved_count = 0
            self._next_capture = time.monotonic()
            self.saving_enabled = True

    def stop_saving(self):
        with self._save_lock:
            self.saving_enabled = False
            if self.csv_file is not None:
                try:
                    self.csv_file.flush()
                    self.csv_file.close()
                except Exception:
                    pass
            self.csv_file = self.csv_writer = None

    def stop(self):
        self.stop_saving()
        self.running.clear()
        if self.thread and self.thread.is_alive() and self.thread is not threading.current_thread():
            self.thread.join(timeout=2.0)
        self.thread = None
        if self.cap is not None:
            self.cap.release()
        self.cap = None

    # ------------------------------------------------------------------ capture loop
    def _demo_frame(self):
        h, w = self.height, self.width
        frame = np.full((h, w, 3), 215, dtype=np.uint8)
        rows, cols = 4, 8
        now = time.monotonic()
        for r in range(rows):
            for c in range(cols):
                x = int((c + 0.5) * w / cols)
                y = int((r + 0.5) * h / rows)
                rad = max(10, int(min(w / cols, h / rows) * 0.32))
                cv2.circle(frame, (x, y), rad, (100, 100, 100), 2)
                dx = int(math.sin(now * 1.7 + r + c) * rad * 0.35)
                dy = int(math.cos(now * 1.3 + r * 0.4 + c) * rad * 0.35)
                cv2.circle(frame, (x + dx, y + dy), max(3, rad // 10), (20, 20, 20), -1)
        cv2.putText(frame, "WINDOWS DEMO - synthetic camera", (20, h - 25),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.75, (20, 20, 20), 2, cv2.LINE_AA)
        return frame

    def _loop(self):
        interval = 1.0 / self.images_per_second
        failures = 0
        while self.running.is_set():
            if self.demo_mode:
                frame = self._demo_frame()
                time.sleep(1.0 / max(self.fps, 10.0))
            else:
                ok, frame = self.cap.read()
                if not ok:
                    failures += 1
                    if failures == 1:
                        self._emit("Camera failed to retrieve a frame.")
                    if failures >= self.MAX_CONSECUTIVE_FAILURES:
                        self.running.clear()
                        self.fatal_callback("Camera stopped delivering frames (unplugged or crashed?). "
                                            "Images captured so far have been kept.")
                        return
                    time.sleep(0.05)
                    continue
                failures = 0
            with self.frame_lock:
                self.latest_frame = frame.copy()

            if not self.saving_enabled:
                continue
            with self._save_lock:
                now = time.monotonic()
                if not self.saving_enabled or now < self._next_capture:
                    continue
                ts = datetime.now().isoformat(timespec="milliseconds")  # time of capture, not of disk write
                name = f"frame_{self.image_number:06d}.png"
                path = self.frames_dir / name
                # Write to a temp file and rename, so CAMS (which lists the folder while the
                # experiment runs) never sees a half-written PNG.
                try:
                    saved = cv2.imwrite(str(self._tmp_path), frame, [cv2.IMWRITE_PNG_COMPRESSION, 3])
                    if saved:
                        os.replace(self._tmp_path, path)
                except OSError as exc:
                    saved = False
                    self._emit(f"Could not save {name}: {exc}")
                if saved:
                    self.csv_writer.writerow([name, ts])
                    self.csv_file.flush()
                    self.image_number += 1
                    self.saved_count += 1
                    try:
                        self.image_saved_callback(self.saved_count, path, ts, frame)
                    except Exception:
                        pass
                else:
                    self._emit(f"WARNING: image {name} was not saved (disk full?).")
                self._next_capture += interval
                if self._next_capture < now - interval:
                    self._next_capture = now + interval

    def get_frame(self):
        with self.frame_lock:
            return None if self.latest_frame is None else self.latest_frame.copy()
