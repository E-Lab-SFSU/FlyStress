#!/usr/bin/env bash
set -Eeuo pipefail
APP_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$APP_DIR"
echo '=== FlyShaker Raspberry Pi launcher ==='
if [[ ! -d .venv ]]; then
  echo 'Creating Python environment with system OpenCV access...'
  python3 -m venv --system-site-packages .venv
fi
source .venv/bin/activate
python -m pip install -r requirements-pi.txt
unset FLYSHAKER_DEMO
echo 'Starting FlyShaker...'
python main.py
