"""Run CAMS motion-threshold calibration on previously recorded images without starting shaker."""
from pathlib import Path
import subprocess
import sys
import shutil
from PyQt6.QtWidgets import QMessageBox
from calibration_tools import wells_csv_in, uncalibrated_wells
from config_writer import write_cams_config


def run_standalone(folder, cams_dir, parent=None):
    folder = Path(folder).resolve()
    if not folder.is_dir():
        raise ValueError('Experiment folder does not exist.')
    frames_subdir = next((name for name in ('initiation_frames', 'frames') if len(list((folder/name).glob('*.png'))) >= 2), None)
    if frames_subdir is None:
        raise ValueError('Need at least two PNG images in initiation_frames/ or frames/.')
    if wells_csv_in(folder) is None:
        raise ValueError('Well grid not found. Calibrate a well grid through a normal experiment first.')
    config_path = Path(cams_dir) / 'activity_config.py'
    original = config_path.read_bytes()
    try:
        # Use the existing recording's frame interval if available.
        import re
        match = re.search(rb'^FRAME_INTERVAL_SECONDS\s*=\s*([0-9.]+)', original, re.M)
        ips = 1.0 / float(match.group(1)) if match else 1.0
        write_cams_config(cams_dir, folder, ips, frames_subdir=frames_subdir)
        for script in ('measure_activity.py', 'motion_threshold_tuner.py'):
            if script == 'motion_threshold_tuner.py' and (folder/'well_threshold.csv').exists() and not uncalibrated_wells(folder/'well_threshold.csv'):
                answer = QMessageBox.question(parent, 'Existing thresholds', 'All wells already have thresholds. Reset thresholds to recalibrate all wells? Existing thresholds will be backed up.')
                if answer != QMessageBox.StandardButton.Yes:
                    continue
                path = folder/'well_threshold.csv'
                shutil.copy2(path, folder/'well_threshold_before_standalone.csv')
                import csv
                with path.open(newline='', encoding='utf-8') as f: rows = list(csv.DictReader(f))
                for row in rows: row['motion_threshold_AU'] = '0'
                with path.open('w', newline='', encoding='utf-8') as f:
                    writer = csv.DictWriter(f, fieldnames=['well','motion_threshold_AU','fly_count','viable_flies'])
                    writer.writeheader(); writer.writerows(rows)
            result = subprocess.run([sys.executable, str(Path(cams_dir)/script)], cwd=str(cams_dir))
            if result.returncode: raise RuntimeError(f'{script} exited with code {result.returncode}')
        QMessageBox.information(parent, 'Calibration finished', f'Calibration results saved in:\n{folder}')
    finally:
        config_path.write_bytes(original)
