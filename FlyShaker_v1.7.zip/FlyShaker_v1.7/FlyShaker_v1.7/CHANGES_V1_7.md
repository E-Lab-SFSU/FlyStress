# FlyShaker v1.7 (revised from the v1.7 optionB test build)

Based on v1.6. Not yet run on the Raspberry Pi / ESP32 hardware; the headless tests pass
(`python -m unittest discover -s tests -v`) but the GUI (PyQt6) paths were only compiled, not run.

## Fixed relative to the optionB test build
1. **compare_first_last** picked an `SK_` frame as the "first" image (uppercase `S` sorts before `f`).
   All CAMS scripts now list frames in numeric order with shaking frames removed.
2. **motion_threshold_tuner** looked images up by list position, which breaks as soon as frames are
   removed or renamed. It now looks them up by frame number and skips candidates whose frames are missing.
3. **measure_activity** wrote its first row with 8 columns (header has 9).
4. **Initiation-frame collision:** the flag list from `image_timestamps` (experiment frames) was applied to
   `initiation_frames` too, which share names (`frame_000150.png`). Timestamp flagging now applies only to
   experiment frames.
5. **Silent failure:** if the ESP's burst wording does not match, v1.7 flagged nothing and said nothing. Now
   `shake_flag_report.txt` and the log carry a warning, and `cams/shake_frames.py <log>` shows what the ESP prints.
6. **Burst setting was never used.** A burst with a start but no logged end was dropped. Fallback is now the
   logged duration, then the configured Burst (longest value).
7. **Performance:** the live engine re-read and re-parsed the whole shaker log for every image. Windows are
   now built incrementally and looked up by bisection (CAMS did a linear scan per row).
8. **At-home analysis** replayed frames in name order (SK_ first) and ignored shaking in `sleep_timer.csv`.
9. **classify_sleep** left `awake` blank after each gap and then reported 0 asleep / 0 awake for those frames,
   which would show as dips in the plots. Unmeasured rows now hold the current state.
10. Resume numbering ignored `SK_` files; a failed rename aborted the whole finalize; the image-timestamp CSV was
    rewritten non-atomically and dropped extra columns.
11. **Death Timer** was never saved anywhere. It is now hr/min/s and written to `experiment_settings.json`.
12. **Threshold "No" path:** it forced "calibrate new", asked the same calibration question twice, and sized the
    disk check for a full session. It now honours the Calibration choice, goes straight to calibration, and checks
    space for initiation only.

## Moved
`shake_frames.py` and `sleep_timing.py` live in `cams/` (CAMS scripts no longer reach into the parent folder).

## Known limits
- The burst wording (`BURST START`, `BURST DURATION n`, `BURST SILENCE START`) is an assumption; nothing in the
  v1.6 files documents it. Demo mode simulates those lines.
- Plots C and D (stimulus-triggered average, summary) look up exact frames (stimulus time -1 s, +30 s, +60 s).
  Those frames can now be SK_ frames and come out blank. Graph rework is out of scope, but it will need this.
- The live sleep display and the 300-image CAMS checks use the logs; the rename happens at the end.
  If the program is closed mid-run, files are not renamed (analysis still skips them via the logs).
