"""Compatibility module used by shaker_image_timestamp_video.py."""
from pathlib import Path
import cv2


def create_video(images, output, frame_duration=1.0, width=1920, height=1080):
    images = [Path(p) for p in images]
    if not images:
        raise ValueError("No images supplied")
    fps = 1.0 / max(float(frame_duration), 0.001)
    writer = cv2.VideoWriter(str(output), cv2.VideoWriter_fourcc(*"mp4v"), fps, (int(width), int(height)))
    if not writer.isOpened():
        raise RuntimeError("Could not open MP4 writer")
    try:
        for p in images:
            frame = cv2.imread(str(p))
            if frame is None:
                continue
            if frame.shape[1] != int(width) or frame.shape[0] != int(height):
                frame = cv2.resize(frame, (int(width), int(height)), interpolation=cv2.INTER_AREA)
            writer.write(frame)
    finally:
        writer.release()
