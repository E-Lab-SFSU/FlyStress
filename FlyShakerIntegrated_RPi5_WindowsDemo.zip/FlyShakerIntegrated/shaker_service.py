from __future__ import annotations

import csv
import os
import re
import threading
import time
from datetime import datetime
from pathlib import Path

try:
    import serial
    from serial import SerialException
except Exception:  # allows Windows demo to run without pyserial hardware access
    serial = None
    SerialException = Exception


class ShakerService:
    """GUI-friendly adaptation of the uploaded shakerTerminal v6 serial logic."""

    def __init__(self, status_callback=None):
        self.status_callback = status_callback or (lambda text: None)
        self.serial_port = None
        self.reader_thread = None
        self.running = threading.Event()
        self.csv_file = None
        self.csv_writer = None
        self.csv_path: Path | None = None
        self.sequence_number = 0
        self.pending_frequency = None
        self.pending_amplitude = None
        self.pending_duration = None
        self.current_frequency = None
        self.current_amplitude = None
        self.demo_mode = False
        self.demo_thread = None
        self.params = {}

    @staticmethod
    def _extract_number(text, labels):
        for label in labels:
            patterns = (
                rf"\b{label}\b\s*[:=]\s*(-?\d+(?:\.\d+)?)",
                rf"\b{label}\b\s+(-?\d+(?:\.\d+)?)",
                rf"\b{label}\s*\(\s*(-?\d+(?:\.\d+)?)\s*\)",
            )
            for pattern in patterns:
                m = re.search(pattern, text, flags=re.I)
                if m:
                    return float(m.group(1))
        return None

    def _emit(self, text):
        try:
            self.status_callback(str(text))
        except Exception:
            pass

    def _log(self, event="TERMINAL", sequence="", freq="", amp="", duration="", message=""):
        ts = datetime.now().isoformat(timespec="milliseconds")
        if self.csv_writer is not None and self.csv_file is not None:
            self.csv_writer.writerow([ts, event, sequence, freq, amp, duration, message])
            self.csv_file.flush()
            try:
                os.fsync(self.csv_file.fileno())
            except OSError:
                pass
        if message:
            self._emit(message)

    def start(self, experiment_dir: Path, experiment_id: str, port: str, baud: int,
              params: dict, demo_mode: bool = False):
        self.close()
        self.params = dict(params)
        self.demo_mode = bool(demo_mode)
        self.sequence_number = 0
        self.csv_path = Path(experiment_dir) / f"shaker_timestamps_{experiment_id}.csv"
        self.csv_file = self.csv_path.open("w", newline="", encoding="utf-8", buffering=1)
        self.csv_writer = csv.writer(self.csv_file)
        self.csv_writer.writerow([
            "timestamp", "event", "sequence_number", "frequency_hz",
            "amplitude", "duration_s", "message"
        ])
        self.csv_file.flush()
        self.running.set()

        if self.demo_mode:
            self._log("TEST_MODE", message="Windows demonstration mode: shaker hardware simulated.")
            return

        if serial is None:
            raise RuntimeError("pyserial is not installed.")
        try:
            self.serial_port = serial.Serial(
                port=port, baudrate=int(baud), timeout=0.10, write_timeout=1.0
            )
            time.sleep(2.0)
            self.serial_port.reset_input_buffer()
            self.reader_thread = threading.Thread(target=self._reader_loop, daemon=True)
            self.reader_thread.start()
            self.send_configuration(params)
        except Exception:
            self.close()
            raise

    def send_configuration(self, p):
        # BURST and BSILENCE stay at the uploaded script defaults because they are
        # intentionally not exposed on the requested settings screen.
        commands = [
            f"FREQ({p['freq'][0]},{p['freq'][1]})",
            f"AMP({p['amp'][0]},{p['amp'][1]})",
            f"DUTY({p['duty'][0]},{p['duty'][1]})",
            "BURST(3,3)",
            "BSILENCE(120,120)",
            f"SEQ({p['sequence'][0]},{p['sequence'][1]})",
            f"SSILENCE({p['ssilence'][0]},{p['ssilence'][1]})",
            f"SESSION({p['session']})",
            "REPORT(FULL)",
        ]
        for command in commands:
            self.send(command)
            time.sleep(0.15)

    def send(self, command: str):
        command = str(command).strip()
        self._log(message=f"PC > {command}")
        if self.demo_mode:
            return
        if not self.serial_port or not self.serial_port.is_open:
            raise RuntimeError("Shaker serial port is not open.")
        self.serial_port.write((command + "\n").encode("utf-8"))
        self.serial_port.flush()

    def _reader_loop(self):
        while self.running.is_set() and self.serial_port and self.serial_port.is_open:
            try:
                raw = self.serial_port.readline()
            except SerialException as exc:
                self._log("ERROR", message=f"Serial error: {exc}")
                break
            if not raw:
                continue
            text = raw.decode("utf-8", errors="replace").strip()
            if text:
                self.process_esp_output(text)

    def process_esp_output(self, text: str):
        freq = self._extract_number(text, ("freq", "frequency", "hz"))
        amp = self._extract_number(text, ("amp", "amplitude"))
        duration = self._extract_number(text, ("duration", "seq_duration", "sequence_duration"))
        if freq is not None:
            self.pending_frequency = freq
        if amp is not None:
            self.pending_amplitude = amp
        if duration is not None:
            self.pending_duration = duration

        lower = text.lower()
        mentions = any(w in lower for w in ("sequence", "seq", "shake"))
        begins = mentions and any(w in lower for w in ("start", "begin", "running", "execute", "stim"))
        compact = mentions and freq is not None and amp is not None
        if begins or compact:
            self.sequence_number += 1
            self.current_frequency = self.pending_frequency
            self.current_amplitude = self.pending_amplitude
            if duration is None and self.params.get("sequence", (None, None))[0] == self.params.get("sequence", (None, None))[1]:
                duration = self.params["sequence"][0]
            self._log(
                "SEQUENCE_START", self.sequence_number,
                self.current_frequency if self.current_frequency is not None else "",
                self.current_amplitude if self.current_amplitude is not None else "",
                duration if duration is not None else "", f"ESP > {text}"
            )
            self.pending_frequency = self.pending_amplitude = self.pending_duration = None
        else:
            self._log(message=f"ESP > {text}")

    def start_experiment(self):
        if self.demo_mode:
            self._start_demo_sequences()
        self.send("START")

    def _start_demo_sequences(self):
        def worker():
            lo_f, hi_f = self.params["freq"]
            lo_a, hi_a = self.params["amp"]
            seq = max(1.0, float(self.params["sequence"][0]))
            toggle = False
            while self.running.is_set():
                f = float(hi_f if toggle else lo_f)
                a = float(hi_a if toggle else lo_a)
                toggle = not toggle
                self.sequence_number += 1
                self.current_frequency, self.current_amplitude = f, a
                self._log("SEQUENCE_START", self.sequence_number, f, a, seq,
                          f"ESP > SEQUENCE START FREQ {f:g} AMP {a:g} DURATION {seq:g}")
                end = time.monotonic() + min(seq, 8.0)  # demo stays visually active
                while self.running.is_set() and time.monotonic() < end:
                    time.sleep(0.1)
        self.demo_thread = threading.Thread(target=worker, daemon=True)
        self.demo_thread.start()

    def stop_experiment(self):
        if self.running.is_set():
            try:
                self.send("STOP")
            except Exception:
                pass

    def close(self):
        self.running.clear()
        if self.reader_thread and self.reader_thread.is_alive():
            self.reader_thread.join(timeout=1.0)
        self.reader_thread = None
        if self.demo_thread and self.demo_thread.is_alive():
            self.demo_thread.join(timeout=0.5)
        self.demo_thread = None
        if self.serial_port is not None:
            try:
                if self.serial_port.is_open:
                    self.serial_port.close()
            except Exception:
                pass
        self.serial_port = None
        if self.csv_file is not None:
            try:
                self.csv_file.flush()
                self.csv_file.close()
            except Exception:
                pass
        self.csv_file = self.csv_writer = None
