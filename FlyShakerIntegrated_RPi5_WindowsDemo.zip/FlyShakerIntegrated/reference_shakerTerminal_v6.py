"""
Fly Shaker Serial Terminal
Version 6 with numbered per-experiment CSV logging

Requirements:
    pip install pyserial

Run:
    python shakerTerminal_v6_numbered_csv.py
"""

from __future__ import annotations

import sys
import time
import threading

import select
import termios
import tty

import os
import csv
import re

from datetime import datetime
from pathlib import Path
from typing import TextIO
from typing import Iterable

import serial
from serial import SerialException

###############################################################################
# EDIT THIS SECTION BEFORE RUNNING
###############################################################################

PORT = "/dev/ttyUSB0"             # Serial port used by the ESP32 (change as needed)
BAUD = 115200             # Must match the ESP32 firmware

# Maximum time (seconds) to wait for serial data before continuing.
SERIAL_TIMEOUT = 0.10

# Most ESP32 boards automatically reset when the serial port opens.
# Wait for the firmware to finish booting before sending commands.
ESP_BOOT_DELAY = 2.0

# Delay (seconds) between transmitted protocol commands.
# Prevents overflowing the ESP32 serial input buffer.
SEND_DELAY = 0.15

# ---------- Fly Shaker Protocol Parameters ----------

FREQ = (50,100)            # Stimulus frequency (Hz)
AMP = (6,10)              # Stimulus amplitude (0-30 maximum)
DUTY = (50,50)            # Duty cycle (% of each cycle that is HIGH)

BURST = (3,3)             # Burst duration (s); ignored in Part 2
BSILENCE = (120,120)          # Silence after each burst (s); ignored in Part 2

SEQ = (120,120)           # Sequence duration (s); ignored in Part 2
SSILENCE = (0,0)          # Silence between sequences (s); ignored in Part 2

SESSION = 300             # Total experiment duration (s); ignored in Part 2

REPORT = "FULL"

# REPORT = "NONE"   Print only ERROR and STATUS messages.
# REPORT = "BRIEF"  Also print successful command acknowledgments.
# REPORT = "FULL"   Currently identical to BRIEF. Future versions will
#                   also display detailed experiment progress and results.

# ---------- Single-Key Controls ----------

KEY_START  = "s"          # Start the experiment
KEY_PAUSE  = "p"          # Pause the experiment
KEY_STOP   = "x"          # Stop the experiment
KEY_STATUS = "?"          # Request current status
KEY_QUIT   = "q"          # Quit the terminal program; Ctrl-C also quits

# ---------- Logging ----------

# Directory where log files are stored. Relative paths are created beside this
# Python program, not in an unpredictable Windows working directory.
LOG_DIRECTORY = "logs"

# Write each completed line through to physical storage immediately. This is
# safest for long experiments because a crash or power loss should lose no more
# than the line currently being written.
SYNC_LOG_EACH_LINE = True


###############################################################################
# END OF EDITABLE SECTION
###############################################################################


class FlyShakerTerminal:
    """Simple serial terminal for configuring and controlling the Fly Shaker."""

    def __init__(self) -> None:
        self.serial_port: serial.Serial | None = None
        self.running = threading.Event()
        self.print_lock = threading.Lock()
        self.reader_thread: threading.Thread | None = None
        self.log_file: TextIO | None = None
        self.log_path: Path | None = None
        self.csv_file: TextIO | None = None
        self.csv_writer = None
        self.csv_path: Path | None = None
        self.sequence_number = 0
        self.experiment_number: int | None = None
        self.experiment_id: str | None = None
        self.pending_frequency: float | None = None
        self.pending_amplitude: float | None = None
        self.pending_duration: float | None = None

    def open_log(self) -> None:
        """Create a new timestamped log file for this terminal run."""
        log_directory = Path(LOG_DIRECTORY)
        if not log_directory.is_absolute():
            log_directory = Path(__file__).resolve().parent / log_directory
        log_directory.mkdir(parents=True, exist_ok=True)

        # Give every shaker run its own experiment number. The first unused
        # shaker_timestamps_00001.csv, shaker_timestamps_00002.csv, ... is used.
        experiment_number = 1
        while (log_directory / f"shaker_timestamps_{experiment_number:05d}.csv").exists():
            experiment_number += 1

        self.experiment_number = experiment_number
        self.experiment_id = f"{experiment_number:05d}"

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.log_path = log_directory / f"FlyShaker_{self.experiment_id}_{timestamp}.log"
        self.log_file = self.log_path.open(
            mode="a",
            encoding="utf-8",
            buffering=1,       # line buffered
        )

        # One CSV per experiment. This number is intended to match the Raspberry
        # Pi experiment number when both acquisition programs are run once per
        # experiment in the same order.
        self.csv_path = log_directory / f"shaker_timestamps_{self.experiment_id}.csv"
        self.csv_file = self.csv_path.open(
            mode="w",
            encoding="utf-8",
            newline="",
            buffering=1,
        )
        self.csv_writer = csv.writer(self.csv_file)
        self.csv_writer.writerow([
            "timestamp",
            "event",
            "sequence_number",
            "frequency_hz",
            "amplitude",
            "duration_s",
            "message",
        ])
        self.csv_file.flush()
        if SYNC_LOG_EACH_LINE:
            os.fsync(self.csv_file.fileno())

    def print_line(self, text: str = "", *, event: str = "TERMINAL",
                   sequence_number: int | str = "",
                   frequency_hz: int | float | str = "",
                   amplitude: int | float | str = "",
                   duration_s: int | float | str = "") -> None:
        """Print a line and immediately append it to the persistent log and CSV."""
        with self.print_lock:
            print(text, flush=True)
            timestamp = datetime.now().isoformat(timespec="milliseconds")

            if self.log_file is not None:
                self.log_file.write(f"{timestamp}  {text}\n")
                self.log_file.flush()
                if SYNC_LOG_EACH_LINE:
                    os.fsync(self.log_file.fileno())

            if self.csv_writer is not None and self.csv_file is not None:
                self.csv_writer.writerow([
                    timestamp, event, sequence_number, frequency_hz,
                    amplitude, duration_s, text,
                ])
                self.csv_file.flush()
                if SYNC_LOG_EACH_LINE:
                    os.fsync(self.csv_file.fileno())

    @staticmethod
    def _extract_number(text: str, labels: tuple[str, ...]) -> float | None:
        """Extract a number printed next to one of the supplied labels."""
        for label in labels:
            patterns = (
                rf"\b{label}\b\s*[:=]\s*(-?\d+(?:\.\d+)?)",
                rf"\b{label}\b\s+(-?\d+(?:\.\d+)?)",
                rf"\b{label}\s*\(\s*(-?\d+(?:\.\d+)?)\s*\)",
            )
            for pattern in patterns:
                match = re.search(pattern, text, flags=re.IGNORECASE)
                if match:
                    return float(match.group(1))
        return None

    def process_esp_output(self, text: str) -> None:
        """Log ESP output and identify each individual shake sequence.

        The ESP chooses the real frequency/amplitude, so values are parsed from
        the ESP's own report instead of from the configured FREQ/AMP ranges.
        Values can be printed on the sequence-start line or on immediately
        preceding lines; the latest reported values are cached until a sequence
        start is seen.
        """
        frequency = self._extract_number(text, ("freq", "frequency", "hz"))
        amplitude = self._extract_number(text, ("amp", "amplitude"))
        duration = self._extract_number(
            text, ("duration", "seq_duration", "sequence_duration")
        )

        if frequency is not None:
            self.pending_frequency = frequency
        if amplitude is not None:
            self.pending_amplitude = amplitude
        if duration is not None:
            self.pending_duration = duration

        lower = text.lower()
        mentions_sequence = any(word in lower for word in ("sequence", "seq", "shake"))
        begins_sequence = mentions_sequence and any(
            word in lower for word in ("start", "begin", "running", "execute", "stim")
        )

        # Some firmware reports a sequence as one compact line containing the
        # chosen FREQ and AMP without literally saying "start". Treat that as a
        # sequence event too, but only for ESP output (never PC configuration).
        compact_sequence_report = (
            mentions_sequence and frequency is not None and amplitude is not None
        )

        if begins_sequence or compact_sequence_report:
            self.sequence_number += 1

            # If SEQ is fixed, it is safe to use it when the ESP does not print
            # duration on the report line. If SEQ is a range, leave duration blank
            # unless the ESP explicitly reports the chosen duration.
            actual_duration = self.pending_duration
            if actual_duration is None and SEQ[0] == SEQ[1]:
                actual_duration = SEQ[0]

            self.print_line(
                f"ESP > {text}",
                event="SEQUENCE_START",
                sequence_number=self.sequence_number,
                frequency_hz=(self.pending_frequency if self.pending_frequency is not None else ""),
                amplitude=(self.pending_amplitude if self.pending_amplitude is not None else ""),
                duration_s=(actual_duration if actual_duration is not None else ""),
            )

            # Clear cached randomized values so a later sequence cannot silently
            # inherit values from this one if the ESP fails to report them.
            self.pending_frequency = None
            self.pending_amplitude = None
            self.pending_duration = None
        else:
            self.print_line(f"ESP > {text}")

    def open_serial(self) -> None:
        """Open the configured serial port."""
        try:
            self.serial_port = serial.Serial(
                port=PORT,
                baudrate=BAUD,
                timeout=SERIAL_TIMEOUT,
                write_timeout=1.0,
            )
        except SerialException as exc:
            raise RuntimeError(
                f"Could not open {PORT} at {BAUD} baud.\n"
                f"Check the COM port, close Arduino Serial Monitor, and reconnect the ESP.\n"
                f"Serial error: {exc}"
            ) from exc

        # Clear old data that may have arrived during connection/reset.
        self.serial_port.reset_input_buffer()
        self.serial_port.reset_output_buffer()

    def start_reader(self) -> None:
        """Start a background thread that prints every complete ESP line."""
        if self.serial_port is None:
            raise RuntimeError("Serial port is not open.")

        self.running.set()
        self.reader_thread = threading.Thread(
            target=self._reader_loop,
            name="ESP serial reader",
            daemon=True,
        )
        self.reader_thread.start()

    def _reader_loop(self) -> None:
        """Continuously read and display ESP output."""
        assert self.serial_port is not None

        while self.running.is_set():
            try:
                raw = self.serial_port.readline()
            except SerialException as exc:
                self.print_line(f"\nSERIAL ERROR: {exc}")
                self.running.clear()
                break

            if not raw:
                continue

            text = raw.decode("utf-8", errors="replace").rstrip("\r\n")
            if text:
                self.process_esp_output(text)

    def send(self, command: str) -> None:
        """Send one command followed by a newline."""
        if self.serial_port is None or not self.serial_port.is_open:
            raise RuntimeError("Serial port is not open.")

        command = command.strip()
        if not command:
            return

        # START begins the experiment/session. It is deliberately NOT labeled as
        # a shake sequence; individual sequences are detected from ESP output.
        self.print_line(f"PC  > {command}")

        try:
            self.serial_port.write((command + "\n").encode("utf-8"))
            self.serial_port.flush()
        except SerialException as exc:
            raise RuntimeError(f"Failed to send '{command}': {exc}") from exc

    @staticmethod
    def pair_command(name: str, values: tuple[int | float, int | float]) -> str:
        """Create NAME(min,max) using the values exactly as written in Python."""
        minimum, maximum = values
        return f"{name}({minimum},{maximum})"

    def configuration_commands(self) -> Iterable[str]:
        """Return the complete startup configuration in protocol order."""
        yield self.pair_command("FREQ", FREQ)
        yield self.pair_command("AMP", AMP)
        yield self.pair_command("DUTY", DUTY)
        yield self.pair_command("BURST", BURST)
        yield self.pair_command("BSILENCE", BSILENCE)
        yield self.pair_command("SEQ", SEQ)
        yield self.pair_command("SSILENCE", SSILENCE)
        yield f"SESSION({SESSION})"
        yield f"REPORT({REPORT.upper()})"

    def send_configuration(self) -> None:
        """Transmit all configuration parameters to the ESP."""
        self.print_line()
        self.print_line("Sending Fly Shaker configuration...")
        self.print_line("-" * 60)

        for command in self.configuration_commands():
            self.send(command)
            time.sleep(SEND_DELAY)

        self.print_line("-" * 60)
        self.print_line("Configuration sent.")
        self.print_line()

    def show_controls(self) -> None:
        """Display the available single-key controls."""
        self.print_line("Keyboard controls")
        self.print_line(f"  {KEY_START}  START")
        self.print_line(f"  {KEY_PAUSE}  PAUSE")
        self.print_line(f"  {KEY_STOP}  STOP")
        self.print_line(f"  {KEY_STATUS}  STATUS")
        self.print_line(f"  {KEY_QUIT}  Quit")
        self.print_line("  Ctrl-C  Quit")
        self.print_line()

    def keyboard_loop(self) -> None:
        """Read Windows single-key commands without requiring Enter."""
        key_commands = {
            KEY_START.lower(): "START",
            KEY_PAUSE.lower(): "PAUSE",
            KEY_STOP.lower(): "STOP",
            KEY_STATUS.lower(): "STATUS",
        }

        self.print_line("Ready. Press a command key.")

        fd = sys.stdin.fileno()             # file descriptor
        old_settings = termios.tcgetattr(fd)
        
        try:
            tty.setcbreak(fd)
            
            while self.running.is_set():
                readable, _, _ = select.select([sys.stdin], [], [], 0.03)   #freq keyboard input is checked
                
                if not readable:
                    continue
                    
                key = sys.stdin.read(1)
                key_lower = key.lower()
                
                if key_lower == KEY_QUIT.lower():
                    self.print_line("Quit requested.")
                    break
                    
                command = key_commands.get(key_lower)
                if command:
                    self.send(command)
                    
                elif key not in ("\r", "\n"):
                    self.print_line(
                    f"Unknown Key '{key}'."
                    f"Use {KEY_START}, {KEY_PAUSE}, {KEY_STOP}, {KEY_STATUS}, or {KEY_QUIT}.")
                    
        finally: termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)

    def close(self) -> None:
        """Stop the reader and close the serial port."""
        self.running.clear()

        if self.reader_thread and self.reader_thread.is_alive():
            self.reader_thread.join(timeout=0.5)

        if self.serial_port and self.serial_port.is_open:
            self.serial_port.close()

        # Record the final terminal message before closing the log files.
        if self.log_file is not None or self.csv_file is not None:
            self.print_line("Serial terminal closed.")

        if self.log_file is not None:
            with self.print_lock:
                self.log_file.flush()
                if SYNC_LOG_EACH_LINE:
                    os.fsync(self.log_file.fileno())
                self.log_file.close()
                self.log_file = None

        if self.csv_file is not None:
            with self.print_lock:
                self.csv_file.flush()
                if SYNC_LOG_EACH_LINE:
                    os.fsync(self.csv_file.fileno())
                self.csv_file.close()
                self.csv_file = None
                self.csv_writer = None

    def run(self) -> None:
        """Open the ESP, send configuration, and enter interactive mode."""
        self.open_log()
        self.print_line("=" * 60)
        self.print_line("Fly Shaker Serial Terminal")
        self.print_line(f"Experiment ID: {self.experiment_id}")
        self.print_line(f"Port: {PORT}    Baud: {BAUD}")
        self.print_line(f"Log file: {self.log_path}")
        self.print_line(f"CSV file: {self.csv_path}")
        self.print_line("=" * 60)

        self.open_serial()
        self.print_line(f"Connected to {PORT}. Waiting for ESP boot...")
        time.sleep(ESP_BOOT_DELAY)

        assert self.serial_port is not None
        self.serial_port.reset_input_buffer()

        self.start_reader()
        self.send_configuration()
        self.show_controls()
        self.keyboard_loop()


def main() -> int:
    terminal = FlyShakerTerminal()

    try:
        terminal.run()
        return 0
    except KeyboardInterrupt:
        if terminal.log_file is not None or terminal.csv_file is not None:
            terminal.print_line("\nCtrl-C received. Closing terminal.")
        else:
            print("\nCtrl-C received. Closing terminal.", flush=True)
        return 0
    except (RuntimeError, ValueError) as exc:
        if terminal.log_file is not None or terminal.csv_file is not None:
            terminal.print_line(f"\nERROR: {exc}", event="ERROR")
        else:
            print(f"\nERROR: {exc}", file=sys.stderr, flush=True)
        return 1
    finally:
        terminal.close()


if __name__ == "__main__":
    raise SystemExit(main())

