@echo off
set FLYSHAKER_DEMO=1
python main.py
pause
