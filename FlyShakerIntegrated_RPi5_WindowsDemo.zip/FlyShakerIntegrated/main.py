from __future__ import annotations

import csv
import os
import platform
import subprocess
import sys
import threading
import time
from pathlib import Path

import cv2
import numpy as np
from PyQt6.QtCore import QObject, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QImage, QPixmap
from PyQt6.QtWidgets import (
    QApplication, QDialog, QFormLayout, QGridLayout, QHBoxLayout, QLabel,
    QLineEdit, QMainWindow, QMessageBox, QPushButton, QVBoxLayout, QWidget
)

from camera_service import CameraService
from config_writer import write_cams_config
from shaker_service import ShakerService
from timestamp_sync import build_alignment

APP_DIR = Path(__file__).resolve().parent
CAMS_DIR = APP_DIR / "cams"
DEMO_MODE = os.environ.get("FLYSHAKER_DEMO", "0") == "1"
EXPERIMENT_ROOT = Path.home() / "FS_IMG"
CAMERA_DEVICE = "/dev/video0"
CAMERA_WIDTH = 1280
CAMERA_HEIGHT = 800
CAMERA_FPS = 30
SERIAL_PORT = "/dev/ttyUSB0"
BAUD = 115200
ANALYSIS_BATCH_IMAGES = 300
SYNC_THRESHOLD_SECONDS = 3.0


class Bridge(QObject):
    log = pyqtSignal(str)
    stage = pyqtSignal(str)
    analysis_done = pyqtSignal(int, int)
    fatal = pyqtSignal(str)
    calibration_ready = pyqtSignal()
    experiment_finished = pyqtSignal()
    start_actual = pyqtSignal()


def parse_pair(text: str, name: str):
    cleaned = text.strip().replace("(", "").replace(")", "")
    parts = [p.strip() for p in cleaned.split(",")]
    if len(parts) != 2:
        raise ValueError(f"{name} must be entered as min,max (example: 50,100).")
    a, b = float(parts[0]), float(parts[1])
    if a > b:
        raise ValueError(f"{name}: minimum cannot exceed maximum.")
    return (a, b)


class SettingsDialog(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Fly Shaker Settings")
        self.setMinimumWidth(580)
        self.values = None
        outer = QVBoxLayout(self)
        title = QLabel("SETTINGS")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet("font-size: 22px; font-weight: bold;")
        outer.addWidget(title)
        form = QFormLayout()
        self.ips = QLineEdit("1")
        self.freq = QLineEdit("50,100")
        self.amp = QLineEdit("6,10")
        self.duty = QLineEdit("50,50")
        self.sequence = QLineEdit("120,120")
        self.ssilence = QLineEdit("0,0")
        self.session = QLineEdit("300")
        self.initiation = QLineEdit("120")
        form.addRow("Images per second", self.ips)
        form.addRow("Frequency (min,max)", self.freq)
        form.addRow("Amplitude (min,max)", self.amp)
        form.addRow("DUTY (min,max)", self.duty)
        form.addRow("Sequence (min,max)", self.sequence)
        form.addRow("SSilence (min,max)", self.ssilence)
        form.addRow("Session (seconds)", self.session)
        form.addRow("Initiation (seconds)", self.initiation)
        outer.addLayout(form)
        note = QLabel("Only these settings are changed. Other shaker/CAMS parameters remain at their uploaded-script defaults.")
        note.setWordWrap(True)
        outer.addWidget(note)
        buttons = QHBoxLayout()
        cancel = QPushButton("Cancel")
        start = QPushButton("Create Experiment")
        cancel.clicked.connect(self.reject)
        start.clicked.connect(self._accept)
        buttons.addWidget(cancel)
        buttons.addWidget(start)
        outer.addLayout(buttons)

    def _accept(self):
        try:
            ips = float(self.ips.text())
            session = float(self.session.text())
            initiation = float(self.initiation.text())
            if ips <= 0 or session <= 0 or initiation < 0:
                raise ValueError("Images/second and session must be > 0; initiation must be >= 0.")
            self.values = {
                "images_per_second": ips,
                "freq": parse_pair(self.freq.text(), "Frequency"),
                "amp": parse_pair(self.amp.text(), "Amplitude"),
                "duty": parse_pair(self.duty.text(), "DUTY"),
                "sequence": parse_pair(self.sequence.text(), "Sequence"),
                "ssilence": parse_pair(self.ssilence.text(), "SSilence"),
                "session": session,
                "initiation": initiation,
            }
            self.accept()
        except Exception as exc:
            QMessageBox.warning(self, "Invalid setting", str(exc))


def next_experiment(root: Path):
    root.mkdir(parents=True, exist_ok=True)
    n = 1
    while (root / f"exp{n:05d}").exists():
        n += 1
    return root / f"exp{n:05d}", f"{n:05d}"


def frame_to_pixmap(frame):
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    rgb = np.ascontiguousarray(rgb)
    h, w, ch = rgb.shape
    img = QImage(rgb.data, w, h, ch * w, QImage.Format.Format_RGB888).copy()
    return QPixmap.fromImage(img)


class MainWindow(QMainWindow):
    def __init__(self, settings):
        super().__init__()
        self.settings = settings
        self.setWindowTitle("Fly Shaker / CAMS Experiment")
        self.resize(1050, 760)
        self.bridge = Bridge()
        self.bridge.log.connect(self._log)
        self.bridge.stage.connect(self._set_stage)
        self.bridge.analysis_done.connect(self._analysis_update)
        self.bridge.fatal.connect(self._fatal)
        self.bridge.calibration_ready.connect(self._calibration_prompt)
        self.bridge.experiment_finished.connect(self._finished_message)
        self.bridge.start_actual.connect(self.start_actual_experiment)
        self.experiment_dir, self.experiment_id = next_experiment(EXPERIMENT_ROOT)
        self.frames_dir = self.experiment_dir / "frames"
        self.frames_dir.mkdir(parents=True, exist_ok=False)
        write_cams_config(CAMS_DIR, self.experiment_dir, settings["images_per_second"])
        self.camera = None
        self.shaker = ShakerService(self.bridge.log.emit)
        self.latest_sleep = None
        self.latest_awake = None
        self.actual_phase_saved = 0
        self.analysis_running = False
        self.next_analysis_at = ANALYSIS_BATCH_IMAGES
        self.stop_requested = False
        self.experiment_started_at = None

        central = QWidget(); self.setCentralWidget(central)
        root = QVBoxLayout(central)
        stats = QGridLayout()
        self.freq_label = QLabel("Freq: -")
        self.amp_label = QLabel("Amp: -")
        self.sleep_label = QLabel("Sleep: -")
        self.awake_label = QLabel("Awake: -")
        for w in (self.freq_label, self.amp_label, self.sleep_label, self.awake_label):
            w.setStyleSheet("font-size: 23px;")
        stats.addWidget(self.freq_label, 0, 0); stats.addWidget(self.amp_label, 0, 1)
        stats.addWidget(self.sleep_label, 1, 0); stats.addWidget(self.awake_label, 1, 1)
        root.addLayout(stats)
        self.preview = QLabel("Preparing camera...")
        self.preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview.setMinimumSize(720, 480)
        self.preview.setStyleSheet("background: #222; color: white;")
        root.addWidget(self.preview, 1)
        bottom = QHBoxLayout()
        self.stage_label = QLabel("Stage: setup")
        self.exp_label = QLabel(f"{self.experiment_dir}")
        self.stop_btn = QPushButton("Stop Experiment")
        self.stop_btn.setEnabled(False)
        self.stop_btn.clicked.connect(self.stop_experiment)
        bottom.addWidget(self.stage_label); bottom.addStretch(1); bottom.addWidget(self.exp_label); bottom.addWidget(self.stop_btn)
        root.addLayout(bottom)
        self.log_label = QLabel("")
        self.log_label.setWordWrap(True)
        root.addWidget(self.log_label)

        self.preview_timer = QTimer(self)
        self.preview_timer.timeout.connect(self._refresh_preview)
        self.preview_timer.start(70)
        self.csv_timer = QTimer(self)
        self.csv_timer.timeout.connect(self._poll_shaker_csv)
        self.csv_timer.start(250)
        QTimer.singleShot(100, self.start_initiation)

    def _log(self, text):
        self.log_label.setText(str(text))
        print(text, flush=True)

    def _set_stage(self, text):
        self.stage_label.setText("Stage: " + text)

    def _fatal(self, text):
        QMessageBox.critical(self, "Experiment error", text)
        self.stop_experiment()

    def start_initiation(self):
        self.bridge.stage.emit("initiation capture")
        self._start_camera(start_number=1)
        duration = self.settings["initiation"]
        self._log(f"Initiation capture started for {duration:g} seconds. Images are saving in {self.frames_dir}.")
        QTimer.singleShot(max(1, int(duration * 1000)), self._finish_initiation)

    def _start_camera(self, start_number):
        self.camera = CameraService(
            camera_device=CAMERA_DEVICE, width=CAMERA_WIDTH, height=CAMERA_HEIGHT, fps=CAMERA_FPS,
            images_per_second=self.settings["images_per_second"], demo_mode=DEMO_MODE,
            status_callback=self.bridge.log.emit, image_saved_callback=self._image_saved
        )
        self.camera.start(self.experiment_dir, self.experiment_id, start_number=start_number)

    def _finish_initiation(self):
        if self.camera:
            self.camera.stop()
        self.bridge.stage.emit("initiation complete")
        self.bridge.calibration_ready.emit()

    def _calibration_prompt(self):
        QMessageBox.information(
            self, "Initiation complete",
            "Initiation images are complete. CAMS calibration will now run in this order:\n\n"
            "1. well_grid_tuner.py\n2. measure_activity.py\n3. motion_threshold_tuner.py\n\n"
            "Finish/save each tuner window to continue."
        )
        threading.Thread(target=self._run_calibration, daemon=True).start()

    def _run_script(self, name):
        path = CAMS_DIR / name
        self.bridge.log.emit(f"Running {name}...")
        result = subprocess.run([sys.executable, str(path)], cwd=str(CAMS_DIR))
        if result.returncode != 0:
            raise RuntimeError(f"{name} exited with code {result.returncode}.")

    def _run_calibration(self):
        try:
            self.bridge.stage.emit("well grid tuner")
            self._run_script("well_grid_tuner.py")
            self.bridge.stage.emit("initial activity measurement")
            self._run_script("measure_activity.py")
            self.bridge.stage.emit("motion threshold tuner")
            self._run_script("motion_threshold_tuner.py")
            self.bridge.stage.emit("starting actual experiment")
            self.bridge.start_actual.emit()
        except Exception as exc:
            self.bridge.fatal.emit(str(exc))

    def start_actual_experiment(self):
        existing = sorted(self.frames_dir.glob("frame_*.png"))
        next_number = len(existing) + 1
        self.actual_phase_saved = 0
        self.next_analysis_at = ANALYSIS_BATCH_IMAGES
        self._start_camera(start_number=next_number)
        try:
            self.shaker.start(
                self.experiment_dir, self.experiment_id, SERIAL_PORT, BAUD,
                self.settings, demo_mode=DEMO_MODE
            )
            self.shaker.start_experiment()
        except Exception as exc:
            if self.camera:
                self.camera.stop()
            self.bridge.fatal.emit(str(exc))
            return
        self.experiment_started_at = time.monotonic()
        self.stop_btn.setEnabled(True)
        self.bridge.stage.emit("experiment running")
        self._log(f"Actual experiment started for {self.settings['session']:g} seconds.")
        QTimer.singleShot(int(self.settings["session"] * 1000), self.stop_experiment)

    def _image_saved(self, count, path, ts):
        # CameraService count resets when actual acquisition starts, so it naturally
        # excludes initiation images from the 300-new-image trigger.
        if self.experiment_started_at is None:
            return
        self.actual_phase_saved = count
        if count >= self.next_analysis_at and not self.analysis_running:
            self.next_analysis_at += ANALYSIS_BATCH_IMAGES
            self.analysis_running = True
            threading.Thread(target=self._periodic_analysis, daemon=True).start()

    def _periodic_analysis(self):
        try:
            self.bridge.stage.emit("CAMS 300-image update")
            self._run_script("measure_activity.py")
            self._run_script("classify_sleep.py")
            asleep, awake = self._latest_plate_counts()
            self._append_sleep_data(asleep, awake)
            self.bridge.analysis_done.emit(asleep, awake)
        except Exception as exc:
            self.bridge.log.emit(f"Periodic CAMS analysis warning: {exc}")
        finally:
            self.analysis_running = False
            if not self.stop_requested:
                self.bridge.stage.emit("experiment running")

    def _latest_plate_counts(self):
        plate = self.experiment_dir / f"{self.experiment_dir.name}_plate.csv"
        with plate.open(newline="", encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
        if not rows:
            return 0, 0
        row = rows[-1]
        return int(float(row.get("sleeping_wells") or 0)), int(float(row.get("awake_wells") or 0))

    def _append_sleep_data(self, asleep, awake):
        path = self.experiment_dir / "sleep_data.csv"
        new = not path.exists()
        with path.open("a", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            if new:
                w.writerow(["timestamp", "captured_experiment_images", "sleeping_wells", "awake_wells"])
            w.writerow([time.strftime("%Y-%m-%dT%H:%M:%S"), self.actual_phase_saved, asleep, awake])

    def _analysis_update(self, asleep, awake):
        self.latest_sleep, self.latest_awake = asleep, awake
        self.sleep_label.setText(f"Sleep: {asleep}")
        self.awake_label.setText(f"Awake: {awake}")

    def _poll_shaker_csv(self):
        path = self.shaker.csv_path
        if not path or not Path(path).exists():
            return
        try:
            with Path(path).open(newline="", encoding="utf-8") as f:
                rows = [r for r in csv.DictReader(f) if r.get("event") == "SEQUENCE_START"]
            if rows:
                row = rows[-1]
                self.freq_label.setText(f"Freq: {row.get('frequency_hz') or '-'}")
                self.amp_label.setText(f"Amp: {row.get('amplitude') or '-'}")
        except Exception:
            pass

    def _refresh_preview(self):
        if not self.camera:
            return
        frame = self.camera.get_frame()
        if frame is None:
            return
        pix = frame_to_pixmap(frame).scaled(
            self.preview.size(), Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation
        )
        self.preview.setPixmap(pix)

    def stop_experiment(self):
        if self.stop_requested:
            return
        self.stop_requested = True
        self.stop_btn.setEnabled(False)
        self.bridge.stage.emit("stopping")
        try:
            self.shaker.stop_experiment()
        except Exception:
            pass
        self.shaker.close()
        if self.camera:
            self.camera.stop()
        threading.Thread(target=self._finalize, daemon=True).start()

    def _finalize(self):
        try:
            self.bridge.stage.emit("final CAMS analysis")
            # Ensure the final partial batch is included in the CSVs.
            self._run_script("measure_activity.py")
            self._run_script("classify_sleep.py")
            asleep, awake = self._latest_plate_counts()
            self._append_sleep_data(asleep, awake)
            self.bridge.analysis_done.emit(asleep, awake)

            self.bridge.stage.emit("final outputs")
            self._run_script("compare_first_last.py")
            self._run_script("generate_plots.py")
            self._create_video()
            image_csv = self.experiment_dir / f"image_timestamps_{self.experiment_id}.csv"
            shaker_csv = self.experiment_dir / f"shaker_timestamps_{self.experiment_id}.csv"
            build_alignment(image_csv, shaker_csv, self.experiment_dir / "image_shaker_alignment.csv", SYNC_THRESHOLD_SECONDS)
            self.bridge.stage.emit("complete")
            self.bridge.experiment_finished.emit()
        except Exception as exc:
            self.bridge.fatal.emit(str(exc))

    def _create_video(self):
        # The uploaded img_to_vid.py is a compatibility module with create_video(),
        # not a command-line program, so call that exact function here.
        from img_to_vid import create_video
        images = sorted(self.frames_dir.glob("*.png"))
        if not images:
            return
        first = cv2.imread(str(images[0]))
        if first is None:
            return
        h, w = first.shape[:2]
        out = self.experiment_dir / "experiment.mp4"
        create_video(images, out, frame_duration=1.0 / self.settings["images_per_second"], width=w, height=h)

    def _finished_message(self):
        QMessageBox.information(
            self, "Experiment complete",
            f"Experiment complete.\n\nOutputs: {self.experiment_dir}\n\n"
            "Final CAMS plots/comparisons, experiment.mp4, sleep_data.csv, and the 3-second timestamp alignment CSV have been created."
        )

    def closeEvent(self, event):
        try:
            self.shaker.close()
            if self.camera:
                self.camera.stop()
        finally:
            event.accept()


def main():
    app = QApplication(sys.argv)
    settings = SettingsDialog()
    if settings.exec() != QDialog.DialogCode.Accepted:
        return 0
    win = MainWindow(settings.values)
    win.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
