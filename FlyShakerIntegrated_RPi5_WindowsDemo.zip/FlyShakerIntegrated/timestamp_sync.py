from __future__ import annotations
import csv
from datetime import datetime
from pathlib import Path


def _dt(text):
    return datetime.fromisoformat(text)


def build_alignment(image_csv: Path, shaker_csv: Path, output_csv: Path, threshold_seconds=3.0):
    """Match each image to the nearest SEQUENCE_START within +/- threshold_seconds."""
    image_csv, shaker_csv, output_csv = map(Path, (image_csv, shaker_csv, output_csv))
    if not image_csv.exists() or not shaker_csv.exists():
        return 0
    with image_csv.open(newline="", encoding="utf-8") as f:
        images = list(csv.DictReader(f))
    with shaker_csv.open(newline="", encoding="utf-8") as f:
        shaker = [r for r in csv.DictReader(f) if r.get("event") == "SEQUENCE_START"]
    events = []
    for row in shaker:
        try:
            events.append((_dt(row["timestamp"]), row))
        except Exception:
            pass
    with output_csv.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["image_name", "image_timestamp", "matched_shaker_timestamp", "delta_seconds",
                    "sequence_number", "frequency_hz", "amplitude", "duration_s"])
        for img in images:
            try:
                it = _dt(img["timestamp"])
            except Exception:
                continue
            nearest = min(events, key=lambda e: abs((it - e[0]).total_seconds()), default=None)
            if nearest is None:
                w.writerow([img.get("image_name", ""), img.get("timestamp", ""), "", "", "", "", "", ""])
                continue
            delta = (it - nearest[0]).total_seconds()
            row = nearest[1]
            if abs(delta) <= float(threshold_seconds):
                w.writerow([img.get("image_name", ""), img.get("timestamp", ""), row["timestamp"],
                            f"{delta:.3f}", row.get("sequence_number", ""), row.get("frequency_hz", ""),
                            row.get("amplitude", ""), row.get("duration_s", "")])
            else:
                w.writerow([img.get("image_name", ""), img.get("timestamp", ""), "", "", "", "", "", ""])
    return len(images)
