from __future__ import annotations
from pathlib import Path


def _path_literal(path: Path) -> str:
    return repr(str(Path(path).resolve()))


def write_cams_config(cams_dir: Path, experiment_dir: Path, images_per_second: float) -> Path:
    """Write only CAMS' path/timing config for this experiment.

    The CAMS analysis scripts themselves are not modified.
    """
    cams_dir = Path(cams_dir).resolve()
    experiment_dir = Path(experiment_dir).resolve()
    frames = experiment_dir / "frames"
    rate = float(images_per_second)
    if rate <= 0:
        raise ValueError("Images per second must be greater than zero.")

    # Preserve CAMS' own non-GUI defaults from the uploaded activity_config.py.
    original = (cams_dir / "activity_config.py").read_text(encoding="utf-8")
    values = {
        "DIR": f"Path({_path_literal(experiment_dir.parent)})",
        "EXPERIMENT": repr(experiment_dir.name),
        "EXPERIMENT_DIRECTORY": f"Path({_path_literal(experiment_dir)})",
        "FRAME_DIRECTORY": f"Path({_path_literal(frames)})",
        "FRAME_RATE_FPS": repr(rate),
        "FRAME_INTERVAL_SECONDS": repr(1.0 / rate),
    }

    lines = original.splitlines()
    out = []
    replaced = set()
    for line in lines:
        stripped = line.strip()
        did_replace = False
        for key, value in values.items():
            if stripped.startswith(key + "=") or stripped.startswith(key + " ="):
                out.append(f"{key}={value}")
                replaced.add(key)
                did_replace = True
                break
        if not did_replace:
            out.append(line)

    missing = [k for k in values if k not in replaced]
    if missing:
        raise RuntimeError("Could not update CAMS config fields: " + ", ".join(missing))

    config_path = cams_dir / "activity_config.py"
    config_path.write_text("\n".join(out) + "\n", encoding="utf-8")
    return config_path
