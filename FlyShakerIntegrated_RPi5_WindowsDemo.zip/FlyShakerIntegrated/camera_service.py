from __future__ import annotations

import csv
import math
import platform
import threading
import time
from datetime import datetime
from pathlib import Path

import cv2
import numpy as np


class CameraService:
    def __init__(self, camera_device="/dev/video0", width=1280, height=800, fps=30,
                 images_per_second=1.0, demo_mode=False, status_callback=None,
                 image_saved_callback=None):
        self.camera_device = camera_device
        self.width = int(width)
        self.height = int(height)
        self.fps = float(fps)
        self.images_per_second = float(images_per_second)
        self.demo_mode = bool(demo_mode)
        self.status_callback = status_callback or (lambda text: None)
        self.image_saved_callback = image_saved_callback or (lambda count, path, ts: None)
        self.running = threading.Event()
        self.thread = None
        self.cap = None
        self.frame_lock = threading.Lock()
        self.latest_frame = None
        self.experiment_dir = None
        self.frames_dir = None
        self.csv_file = None
        self.csv_writer = None
        self.csv_path = None
        self.image_number = 1
        self.saved_count = 0
        self.saving_enabled = False

    def _emit(self, text):
        try:
            self.status_callback(text)
        except Exception:
            pass

    def start(self, experiment_dir: Path, experiment_id: str, start_number=1):
        if self.images_per_second <= 0:
            raise ValueError("Images per second must be greater than zero.")
        self.experiment_dir = Path(experiment_dir)
        self.frames_dir = self.experiment_dir / "frames"
        self.frames_dir.mkdir(parents=True, exist_ok=True)
        self.image_number = int(start_number)
        self.saved_count = 0
        self.csv_path = self.experiment_dir / f"image_timestamps_{experiment_id}.csv"
        new_file = not self.csv_path.exists()
        self.csv_file = self.csv_path.open("a", newline="", encoding="utf-8", buffering=1)
        self.csv_writer = csv.writer(self.csv_file)
        if new_file:
            self.csv_writer.writerow(["image_name", "timestamp"])
            self.csv_file.flush()

        if not self.demo_mode:
            if platform.system() == "Linux":
                self.cap = cv2.VideoCapture(self.camera_device, cv2.CAP_V4L2)
            else:
                index = int(self.camera_device) if str(self.camera_device).isdigit() else 0
                self.cap = cv2.VideoCapture(index)
            if not self.cap.isOpened():
                raise RuntimeError(f"Could not open camera device {self.camera_device}.")
            self.cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.width)
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.height)
            self.cap.set(cv2.CAP_PROP_FPS, self.fps)

        self.running.set()
        self.saving_enabled = True
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()

    def _demo_frame(self):
        h, w = self.height, self.width
        frame = np.full((h, w, 3), 215, dtype=np.uint8)
        rows, cols = 4, 8
        now = time.monotonic()
        for r in range(rows):
            for c in range(cols):
                x = int((c + 0.5) * w / cols)
                y = int((r + 0.5) * h / rows)
                rad = max(10, int(min(w / cols, h / rows) * 0.32))
                cv2.circle(frame, (x, y), rad, (100, 100, 100), 2)
                dx = int(math.sin(now * 1.7 + r + c) * rad * 0.35)
                dy = int(math.cos(now * 1.3 + r * 0.4 + c) * rad * 0.35)
                cv2.circle(frame, (x + dx, y + dy), max(3, rad // 10), (20, 20, 20), -1)
        cv2.putText(frame, "WINDOWS DEMO - synthetic camera", (20, h - 25),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.75, (20, 20, 20), 2, cv2.LINE_AA)
        return frame

    def _loop(self):
        interval = 1.0 / self.images_per_second
        next_capture = time.monotonic()
        while self.running.is_set():
            if self.demo_mode:
                frame = self._demo_frame()
                time.sleep(1.0 / max(self.fps, 10.0))
            else:
                ok, frame = self.cap.read()
                if not ok:
                    self._emit("Camera failed to retrieve a frame.")
                    time.sleep(0.05)
                    continue
            with self.frame_lock:
                self.latest_frame = frame.copy()

            now = time.monotonic()
            if self.saving_enabled and now >= next_capture:
                name = f"frame_{self.image_number:06d}.png"
                path = self.frames_dir / name
                if cv2.imwrite(str(path), frame):
                    ts = datetime.now().isoformat(timespec="milliseconds")
                    self.csv_writer.writerow([name, ts])
                    self.csv_file.flush()
                    self.image_number += 1
                    self.saved_count += 1
                    try:
                        self.image_saved_callback(self.saved_count, path, ts)
                    except Exception:
                        pass
                next_capture += interval
                if next_capture < now - interval:
                    next_capture = now + interval

    def get_frame(self):
        with self.frame_lock:
            return None if self.latest_frame is None else self.latest_frame.copy()

    def stop(self):
        self.running.clear()
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=2.0)
        self.thread = None
        if self.cap is not None:
            self.cap.release()
        self.cap = None
        if self.csv_file is not None:
            self.csv_file.flush()
            self.csv_file.close()
        self.csv_file = self.csv_writer = None
