import cv2
import time
import csv
from datetime import datetime
from pathlib import Path


# --------------------------------------------------
# Settings
# --------------------------------------------------

CAMERA_DEVICE = "/dev/video0"

CAMERA_WIDTH = 1280
CAMERA_HEIGHT = 800
CAMERA_FPS = 30

CAPTURE_INTERVAL = 1.0

# Save FS_IMG inside the Raspberry Pi user's home folder
MAIN_FOLDER = Path.home() / "FS_IMG"


# --------------------------------------------------
# Create the next experiment folder
# --------------------------------------------------

def create_experiment_folder():
    """Create exp00001, exp00002, ... and return (folder, number)."""
    MAIN_FOLDER.mkdir(parents=True, exist_ok=True)

    experiment_number = 1

    while True:
        folder_name = f"exp{experiment_number:05d}"
        experiment_folder = MAIN_FOLDER / folder_name

        if not experiment_folder.exists():
            experiment_folder.mkdir()
            return experiment_folder, experiment_number

        experiment_number += 1


# --------------------------------------------------
# Main program
# --------------------------------------------------

experiment_folder, experiment_number = create_experiment_folder()
experiment_id = f"{experiment_number:05d}"

# The CSV number always matches the experiment folder number.
timestamp_csv_path = experiment_folder / f"image_timestamps_{experiment_id}.csv"
timestamp_csv_file = open(timestamp_csv_path, "w", newline="", encoding="utf-8")
timestamp_writer = csv.writer(timestamp_csv_file)
timestamp_writer.writerow(["image_name", "timestamp"])
timestamp_csv_file.flush()

print("Images will be saved in:")
print(experiment_folder.resolve())
print(f"Image timestamp CSV: {timestamp_csv_path.resolve()}")


# Open the USB camera using the Linux V4L2 backend
cap = cv2.VideoCapture(CAMERA_DEVICE, cv2.CAP_V4L2)

if not cap.isOpened():
    timestamp_csv_file.close()
    raise RuntimeError(
        f"Could not open camera device {CAMERA_DEVICE}."
    )


# MJPG often allows USB cameras to use higher resolutions
cap.set(
    cv2.CAP_PROP_FOURCC,
    cv2.VideoWriter_fourcc(*"MJPG")
)

cap.set(cv2.CAP_PROP_FRAME_WIDTH, CAMERA_WIDTH)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, CAMERA_HEIGHT)
cap.set(cv2.CAP_PROP_FPS, CAMERA_FPS)


# Read back what the camera actually accepted
actual_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
actual_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
actual_fps = cap.get(cv2.CAP_PROP_FPS)

print()
print(f"Experiment ID:        {experiment_id}")
print(f"Requested resolution: {CAMERA_WIDTH} x {CAMERA_HEIGHT}")
print(f"Actual resolution:    {actual_width} x {actual_height}")
print(f"Camera FPS:           {actual_fps}")
print()
print(f"Capturing one image every {CAPTURE_INTERVAL:g} second(s).")
print("Press q in the preview window to stop.")


image_number = 1
next_capture_time = time.monotonic()

try:
    while True:
        ret, frame = cap.read()

        if not ret:
            print("Failed to retrieve an image from the camera.")
            break

        cv2.imshow("Camera Preview", frame)

        current_time = time.monotonic()

        if current_time >= next_capture_time:
            image_name = f"image{image_number:05d}.png"
            image_path = experiment_folder / image_name

            saved = cv2.imwrite(str(image_path), frame)

            if saved:
                # Timestamp only successfully-created image files.
                timestamp_writer.writerow([
                    image_name,
                    datetime.now().isoformat(timespec="milliseconds"),
                ])
                timestamp_csv_file.flush()
                print(
                    f"Saved {image_path} "
                    f"({frame.shape[1]} x {frame.shape[0]})"
                )
                image_number += 1
            else:
                print(f"ERROR: Could not save {image_path}")

            next_capture_time += CAPTURE_INTERVAL

        if cv2.waitKey(1) & 0xFF == ord("q"):
            break
finally:
    timestamp_csv_file.close()
    cap.release()
    cv2.destroyAllWindows()

print("Image capture stopped.")
