#!/usr/bin/env python3
"""Compare first and last frames, write a per-well delta table, and generate a labeled yellow-background red/green composite."""
from pathlib import Path
import csv
import re
import cv2
import numpy as np
import activity_config as config

IMAGE_EXTENSIONS=(".png",".jpg",".jpeg",".bmp",".tif",".tiff")

def list_images(directory):
    directory=Path(directory)
    if not directory.exists(): raise FileNotFoundError(f"Frame directory not found: {directory}")
    files=sorted(p for p in directory.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTENSIONS)
    if len(files)<2: raise ValueError(f"Need at least 2 images in {directory}")
    return files

def load_wells(file):
    wells=[]
    with open(file,"r",newline="",encoding="utf-8") as source:
        reader=csv.DictReader(source)
        required={"well","number","xc","yc","radius"}
        if not reader.fieldnames or not required.issubset(reader.fieldnames):
            raise ValueError("Well CSV must contain columns: well,number,xc,yc,radius")
        for row in reader:
            well=row["well"].strip()
            wells.append((well,int(row["number"]),float(row["xc"]),float(row["yc"]),float(row["radius"])))
    if not wells: raise ValueError(f"No wells found in {file}")
    return wells

def load_gray(file):
    image=cv2.imread(str(file),cv2.IMREAD_GRAYSCALE)
    if image is None: raise FileNotFoundError(f"Could not read image: {file}")
    return image

def parse_well_name(name):
    match=re.fullmatch(r"([A-Za-z]+)(\d+)",name.strip())
    if not match: return None,None
    return match.group(1).upper(),int(match.group(2))

def make_well_indices(shape,wells,scale):
    h,w=shape
    yy,xx=np.ogrid[:h,:w]
    result=[]
    for name,number,xc,yc,radius in wells:
        mask=(xx-xc)**2+(yy-yc)**2 <= (radius*scale)**2
        result.append((name,number,np.flatnonzero(mask)))
    return result

def make_well_mask(shape,wells,scale):
    h,w=shape
    yy,xx=np.ogrid[:h,:w]
    mask=np.zeros((h,w),dtype=np.uint8)
    for name,number,xc,yc,radius in wells:
        circle=(xx-xc)**2+(yy-yc)**2 <= (radius*scale)**2
        mask[circle]=255
    return mask

def emphasize_dark_objects(image,mask):
    inv=(255-image).astype(np.float32)
    values=inv[mask>0]
    if values.size==0: raise ValueError("Well mask is empty.")
    low=max(12.0,float(np.percentile(values,85)))
    high=max(low+1.0,float(np.percentile(values,99.8)))
    scaled=np.clip((inv-low)/(high-low),0.0,1.0)**0.8
    scaled[mask==0]=0.0
    return (255.0*scaled).astype(np.uint8)

def make_yellow_red_green_composite(first,last,mask):
    first_obj=emphasize_dark_objects(first,mask)
    last_obj=emphasize_dark_objects(last,mask)

    # Yellow context background: equal signal in red and green, none in blue.
    base=((first.astype(np.float32)+last.astype(np.float32))/2.0).astype(np.uint8)
    bgr=np.zeros((first.shape[0],first.shape[1],3),dtype=np.uint8)
    bgr[...,2]=base   # red channel
    bgr[...,1]=base   # green channel
    bgr[...,0]=0      # blue off

    # Motion overlays: first frame in red, last frame in green.
    bgr[...,2]=np.maximum(bgr[...,2],first_obj)
    bgr[...,1]=np.maximum(bgr[...,1],last_obj)
    return bgr

def row_column_positions(wells):
    row_positions={}
    col_positions={}
    for name,number,xc,yc,radius in wells:
        row,col=parse_well_name(name)
        if row is None: continue
        row_positions.setdefault(row,[]).append(yc)
        col_positions.setdefault(col,[]).append(xc)
    row_positions={row:int(round(sum(vals)/len(vals))) for row,vals in row_positions.items()}
    col_positions={col:int(round(sum(vals)/len(vals))) for col,vals in col_positions.items()}
    return row_positions,col_positions

def add_perimeter_labels(image,wells,title=None):
    if image.ndim==2: image=cv2.cvtColor(image,cv2.COLOR_GRAY2BGR)
    row_positions,col_positions=row_column_positions(wells)
    top_pad=58 if title else 34
    left_pad=46
    bottom_pad=10
    right_pad=10
    h,w=image.shape[:2]
    canvas=np.zeros((h+top_pad+bottom_pad,w+left_pad+right_pad,3),dtype=np.uint8)
    canvas[top_pad:top_pad+h,left_pad:left_pad+w]=image

    if title:
        cv2.putText(canvas,title,(8,24),cv2.FONT_HERSHEY_SIMPLEX,0.70,(255,255,255),1,cv2.LINE_AA)

    for col,xc in sorted(col_positions.items()):
        text=str(col)
        text_size=cv2.getTextSize(text,cv2.FONT_HERSHEY_SIMPLEX,0.65,1)[0]
        x=left_pad+xc-text_size[0]//2
        y=top_pad-12
        cv2.putText(canvas,text,(x,y),cv2.FONT_HERSHEY_SIMPLEX,0.65,(255,255,255),1,cv2.LINE_AA)

    for row,yc in sorted(row_positions.items()):
        text=row
        text_size=cv2.getTextSize(text,cv2.FONT_HERSHEY_SIMPLEX,0.65,1)[0]
        x=left_pad-text_size[0]-10
        y=top_pad+yc+text_size[1]//2
        cv2.putText(canvas,text,(x,y),cv2.FONT_HERSHEY_SIMPLEX,0.65,(255,255,255),1,cv2.LINE_AA)

    return canvas

def make_2x2_panel(first,last,composite,wells):
    composite_left=add_perimeter_labels(composite,wells,"Yellow background composite: first=red, last=green")
    composite_right=add_perimeter_labels(composite,wells,"Yellow background composite: first=red, last=green")
    first_labeled=add_perimeter_labels(first,wells,"First frame")
    last_labeled=add_perimeter_labels(last,wells,"Last frame")

    cell_h=max(composite_left.shape[0],composite_right.shape[0],first_labeled.shape[0],last_labeled.shape[0])
    cell_w=max(composite_left.shape[1],composite_right.shape[1],first_labeled.shape[1],last_labeled.shape[1])

    def pad_to_size(image,height,width):
        if image.shape[0]==height and image.shape[1]==width: return image
        canvas=np.zeros((height,width,3),dtype=np.uint8)
        canvas[:image.shape[0],:image.shape[1]]=image
        return canvas

    composite_left=pad_to_size(composite_left,cell_h,cell_w)
    composite_right=pad_to_size(composite_right,cell_h,cell_w)
    first_labeled=pad_to_size(first_labeled,cell_h,cell_w)
    last_labeled=pad_to_size(last_labeled,cell_h,cell_w)

    top_row=np.hstack([composite_left,composite_right])
    bottom_row=np.hstack([first_labeled,last_labeled])
    return np.vstack([top_row,bottom_row])

def compare_first_last():
    files=list_images(config.FRAME_DIRECTORY)
    wells=load_wells(config.WELLS_CSV)
    first=load_gray(files[0])
    last=load_gray(files[-1])
    if first.shape!=last.shape: raise ValueError(f"Image size changed: {first.shape} vs {last.shape}")

    output_directory=Path(config.OUTPUT_DIRECTORY)
    output_directory.mkdir(parents=True,exist_ok=True)

    scale=float(config.MASK_SCALE)
    indices=make_well_indices(first.shape,wells,scale)
    well_mask=make_well_mask(first.shape,wells,scale)
    diff=cv2.absdiff(last,first).ravel()

    output_csv=output_directory/f"{config.OUTPUT_BASENAME}_first_last_delta.csv"
    output_composite=output_directory/f"{config.OUTPUT_BASENAME}_first_last_yellow_red_green_labeled.png"
    output_panel=output_directory/f"{config.OUTPUT_BASENAME}_first_last_2x2.png"

    rows=[]
    for name,number,idx in indices:
        delta_sum=int(diff[idx].sum())
        rows.append([name,number,delta_sum])

    with output_csv.open("w",newline="",encoding="utf-8") as target:
        writer=csv.writer(target)
        writer.writerow(["well","well_number","delta_sum"])
        writer.writerows(rows)

    composite=make_yellow_red_green_composite(first,last,well_mask)
    labeled_composite=add_perimeter_labels(composite,wells,"Yellow background composite: first=red, last=green")
    panel=make_2x2_panel(first,last,composite,wells)

    if not cv2.imwrite(str(output_composite),labeled_composite): raise IOError(f"Could not write image: {output_composite}")
    if not cv2.imwrite(str(output_panel),panel): raise IOError(f"Could not write image: {output_panel}")

    print(f"First frame: {files[0].name}")
    print(f"Last frame:  {files[-1].name}")
    print()
    print(f"{'well':<6}{'number':>8}{'delta_sum':>14}")
    for name,number,delta_sum in rows:
        print(f"{name:<6}{number:>8}{delta_sum:>14}")
    print()
    print(f"Delta CSV:             {output_csv}")
    print(f"Labeled composite:     {output_composite}")
    print(f"2x2 summary:           {output_panel}")

if __name__=="__main__":
    try:
        compare_first_last()
    except Exception as error:
        print(f"compare_first_last failed: {error}")
        raise SystemExit(1)
