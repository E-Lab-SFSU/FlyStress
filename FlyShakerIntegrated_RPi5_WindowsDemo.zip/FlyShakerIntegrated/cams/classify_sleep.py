#!/usr/bin/env python3
"""Classify CAMS well activity as awake or asleep using per-well motion thresholds and viability metadata."""
from pathlib import Path
import csv
import activity_config as config

def activity_csv_path():
    return Path(getattr(config,"ACTIVITY_CSV",Path(config.OUTPUT_DIRECTORY)/f"{config.OUTPUT_BASENAME}.csv"))

def plate_csv_path():
    return Path(config.OUTPUT_DIRECTORY)/f"{config.OUTPUT_BASENAME}_plate.csv"

def parse_count(text,field,well):
    text=str(text).strip()
    if text=="": raise ValueError(f"{field} is blank for well {well}. Complete well_threshold.csv before classification.")
    value=float(text)
    if not value.is_integer() or value<0: raise ValueError(f"{field} must be a nonnegative integer for well {well}: {text}")
    return int(value)

def load_well_metadata(file):
    file=Path(file)
    if not file.exists(): raise FileNotFoundError(f"Threshold CSV not found: {file}")
    metadata={}
    with file.open("r",newline="",encoding="utf-8") as source:
        reader=csv.DictReader(source)
        required={"well","motion_threshold_AU","fly_count","viable_flies"}
        if not reader.fieldnames or not required.issubset(reader.fieldnames): raise ValueError("Threshold CSV must contain columns: well,motion_threshold_AU,fly_count,viable_flies")
        for row in reader:
            well=row["well"].strip(); threshold_text=row["motion_threshold_AU"].strip()
            threshold=float(threshold_text) if threshold_text else 0.0
            if threshold==0: raise ValueError(f"Threshold calibration incomplete: well {well} still has threshold 0.")
            if threshold<0 and threshold!=-1: raise ValueError(f"Invalid motion threshold for well {well}: {threshold:g}")
            fly_count=parse_count(row["fly_count"],"fly_count",well)
            viable_flies=parse_count(row["viable_flies"],"viable_flies",well)
            if viable_flies>fly_count: raise ValueError(f"viable_flies cannot exceed fly_count for well {well}: {viable_flies}>{fly_count}")
            excluded=(threshold==-1 or fly_count==0 or viable_flies==0)
            metadata[well]={"threshold":threshold,"fly_count":fly_count,"viable_flies":viable_flies,"excluded":excluded}
    if not metadata: raise ValueError("Threshold CSV contains no wells.")
    return metadata

def read_csv(file):
    file=Path(file)
    if not file.exists(): raise FileNotFoundError(f"CSV not found: {file}")
    with file.open("r",newline="",encoding="utf-8") as source:
        reader=csv.DictReader(source); rows=list(reader); fields=list(reader.fieldnames or [])
    return fields,rows

def write_csv(file,fields,rows):
    file=Path(file); temp=file.with_suffix(file.suffix+".tmp")
    with temp.open("w",newline="",encoding="utf-8") as target:
        writer=csv.DictWriter(target,fieldnames=fields); writer.writeheader(); writer.writerows(rows)
    temp.replace(file)

def classify_sleep():
    activity_file=activity_csv_path(); plate_file=plate_csv_path(); threshold_file=Path(config.THRESHOLD_CSV)
    print(f"Activity CSV:   {activity_file}")
    print(f"Threshold CSV:  {threshold_file}")
    print(f"Plate CSV:      {plate_file}")
    metadata=load_well_metadata(threshold_file)
    fields,rows=read_csv(activity_file)
    units=str(getattr(config,"ACTIVITY_UNITS","AU")); activity_col=f"activity_{units}"
    required={"frame","time_s","well",activity_col,"motion_detected","inactive_seconds","awake"}
    if not required.issubset(fields): raise ValueError(f"Activity CSV must contain: {', '.join(sorted(required))}")
    wells=sorted({row["well"].strip() for row in rows})
    unknown=[well for well in wells if well not in metadata]
    if unknown: raise ValueError(f"Missing threshold/viability metadata for wells: {', '.join(unknown)}")
    excluded=[well for well in wells if metadata[well]["excluded"]]
    valid=[well for well in wells if not metadata[well]["excluded"]]
    dt=float(config.FRAME_INTERVAL_SECONDS); sleep_seconds=float(config.SLEEP_INACTIVITY_SECONDS)
    inactive={well:0.0 for well in valid}; awake={well:1 for well in valid}; frame_states={}
    for row in rows:
        well=row["well"].strip(); frame=int(float(row["frame"])); info=metadata[well]
        if info["excluded"]:
            row["motion_detected"]="-1"; row["inactive_seconds"]=""; row["awake"]="-1"; state=-1
        else:
            activity_text=row[activity_col].strip()
            if not activity_text:
                row["motion_detected"]=""; row["inactive_seconds"]="0.000"; row["awake"]="1"; state=1
            else:
                activity=float(activity_text); motion=1 if activity>info["threshold"] else 0
                if motion: inactive[well]=0.0; awake[well]=1
                else:
                    inactive[well]+=dt
                    if inactive[well]>=sleep_seconds: awake[well]=0
                row["motion_detected"]=str(motion); row["inactive_seconds"]=f"{inactive[well]:.3f}"; row["awake"]=str(awake[well]); state=awake[well]
        frame_states.setdefault(frame,{})[well]=state
    write_csv(activity_file,fields,rows)

    total_flies=sum(metadata[well]["fly_count"] for well in wells)
    viable_flies=sum(metadata[well]["viable_flies"] for well in wells)
    plate_fields,plate_rows=read_csv(plate_file)
    for field in ["valid_wells","invalid_wells","awake_wells","sleeping_wells","percent_awake","percent_sleeping","total_flies","viable_flies"]:
        if field not in plate_fields: plate_fields.append(field)
    for row in plate_rows:
        frame=int(float(row["frame"])); states=frame_states.get(frame,{})
        valid_states=[state for state in states.values() if state in (0,1)]
        invalid_count=sum(state==-1 for state in states.values())
        awake_count=sum(state==1 for state in valid_states); sleeping_count=sum(state==0 for state in valid_states); valid_count=len(valid_states)
        row["valid_wells"]=str(valid_count) if states else ""
        row["invalid_wells"]=str(invalid_count) if states else ""
        row["awake_wells"]=str(awake_count) if valid_count else "0" if states else ""
        row["sleeping_wells"]=str(sleeping_count) if valid_count else "0" if states else ""
        row["percent_awake"]=f"{100.0*awake_count/valid_count:.1f}" if valid_count else ""
        row["percent_sleeping"]=f"{100.0*sleeping_count/valid_count:.1f}" if valid_count else ""
        row["total_flies"]=str(total_flies) if states else ""
        row["viable_flies"]=str(viable_flies) if states else ""
    write_csv(plate_file,plate_fields,plate_rows)

    if excluded:
        noun="well" if len(excluded)==1 else "wells"
        print(f"{len(excluded)} {noun} excluded: {', '.join(excluded)}")
    else: print("0 wells excluded.")
    print(f"Fly count: {total_flies} total, {viable_flies} viable")
    print(f"Classified {len(valid)} valid wells using {sleep_seconds:g} s sleep inactivity.")
    print(f"Updated activity CSV: {activity_file}")
    print(f"Updated plate CSV:    {plate_file}")

if __name__=="__main__":
    try: classify_sleep()
    except Exception as error:
        print(f"classify_sleep failed: {error}")
        raise SystemExit(1)
