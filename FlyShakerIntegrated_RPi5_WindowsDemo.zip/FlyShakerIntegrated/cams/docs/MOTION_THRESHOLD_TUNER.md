# CAMS Motion Threshold Tuner
`motion_threshold_tuner.py` determines the activity threshold that separates imaging noise from clear body motion independently for each well.  
Run `measure_activity.py` first so that activity values have already been calculated.

## What the Tuner Shows
The tuner displays candidate wells whose measured activity is at or below the currently selected threshold.  
Each tile cycles through a short sequence of adjacent frames. This makes real body movement easier to recognize than viewing a single still image.

## Display Controls
Use the left and right arrow keys to select `Threshold`, `Toggle Rate`, `SEQLEN`, `Rows`, or `Columns`.  
Use `+` and `-` for fine changes. Hold Shift while using `+` or `-` for larger changes.  
`SEQLEN` is the number of adjacent frames included in the displayed sequence. A value of 3 is a useful default.  
`Toggle Rate` controls how quickly the sequence cycles through those frames.

## Choosing a Motion Threshold
Start with a low threshold and increase it gradually until candidate wells appear.  
Scan the displayed tiles quickly. True body movement should be visually obvious. Select a threshold when movement of the main body or an obvious body part is clearly visible.  
Do not stare at a well looking for extremely subtle movement. Small wing, leg, or foot movements near the imaging-noise level should not be used to establish the threshold.

## Plate or Speaker Motion
Sometimes the entire image of a well may move because the plate or speaker was vibrating when the frame was captured.  
Do not treat this as fly motion. Ignore the sequence unless the organism itself clearly moves relative to the well.

## Assigning a Threshold
Left-click a tile when unmistakable body movement is visible.  
CAMS records the activity value displayed for that tile as the motion threshold for that well. Once selected, the well is removed from the remaining uncalibrated wells.  
Press `U` to undo the most recent selection.

## Excluding a Well
Right-click a well that is empty, contains a dead organism, is unusable, or otherwise cannot be calibrated.  
CAMS records its threshold as `-1`.  
`0` = not yet calibrated  
positive value = calibrated motion threshold  
`-1` = excluded well

## Saving and Quitting
Press `S` to save the current thresholds.  
Press `Q` or Esc to quit.  
The tuner saves `well_threshold.csv`.  
The file contains `well`, `motion_threshold_AU`, `fly_count`, and `viable_flies`.

## After Threshold Tuning
After all wells have either been calibrated or excluded, run `compare_first_last.py`.  
Use the resulting first/last comparison to help review each well, then manually complete the `fly_count` and `viable_flies` columns in `well_threshold.csv`.  
After those fields are complete, run `classify_sleep.py`.
