# CAMS Well Grid Tuner
`well_grid_tuner.py` defines the position and size of the monitored wells.  
Run it after the experiment frames are available and before measuring activity.

## What the Tuner Shows
The program displays one experiment frame with four red corner control points and a calculated grid of green well circles.  
Drag the four red points to the centers of the four extreme corner wells. The remaining well centers are interpolated from those four points.

## Display Controls
Use the left and right arrow keys to select `ROWS`, `COLUMNS`, `WELL RADIUS`, or `FRAME` in the bottom control panel.  
Use `+` and `-` for fine adjustment. Hold Shift while using `+` or `-` for larger adjustment.  
`FRAME` lets you inspect the grid on a different experiment image.

## Adjusting the Grid
Adjust the radius until the green circles follow the physical well boundaries.  
Recheck the entire plate after every corner adjustment because a small error at one corner can accumulate across a row or column. Several passes may be needed.  
Perspective distortion may prevent a mathematically regular grid from matching every well perfectly. Optimize the fit over the full plate.

## Mouse and Keyboard Focus
Click or drag within the image when positioning the four corner points.  
When using keyboard controls, first click the application or control area so the CAMS window has keyboard focus.

## Resetting, Saving, and Quitting
Press `R` to reset the four corner controls.  
Press `S` to save the well grid.  
Press `Q` or Esc to quit.

## Output File
Saving creates `plate_wells_<experiment>.csv`.  
The file contains each well's name, number, row, column, center coordinates, radius, and diameter.  
This saved grid is used by all subsequent well-based CAMS analysis.
