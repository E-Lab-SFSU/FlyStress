# CAMS Output Files
CAMS keeps generated experiment data inside the selected experiment directory.

## Well Grid
`plate_wells_<experiment>.csv` is created by `well_grid_tuner.py`.  
It defines the region of interest for every well and contains the well name and number, row and column, center coordinates, radius, and diameter.

## Median Background
`median_background.png` is created by `measure_activity.py` when an existing background image is not available.  
It represents the median background estimated from sampled experiment frames.

## Well-Level Activity
`<experiment>.csv` is the well-level time-series file.  
`frame` = sequential CAMS frame number  
`time_s` = elapsed experiment time in seconds  
`well` = well name  
`well_number` = numeric well identifier  
`activity_AU` = normalized absolute grayscale image change within the well mask  
`running_avg_60s_AU` = running mean optical activity, with the name changing if a different running window is configured  
`motion_detected` = blank before classification, then 1 for detected motion, 0 for no detected motion, and -1 for an excluded well  
`inactive_seconds` = accumulated time without detected motion for a valid well  
`awake` = blank before classification, then 1 for awake, 0 for sleeping, and -1 for invalid or excluded

## Plate-Level Activity
`<experiment>_plate.csv` contains plate-level activity and running activity.  
After `classify_sleep.py`, it also contains `valid_wells`, `invalid_wells`, `awake_wells`, `sleeping_wells`, `percent_awake`, `percent_sleeping`, `total_flies`, and `viable_flies`.  
Awake and sleeping percentages are calculated from valid wells and are not weighted by the number of flies in each well.

## Motion Thresholds and Viability
`well_threshold.csv` contains `well`, `motion_threshold_AU`, `fly_count`, and `viable_flies`.  
`motion_threshold_AU=0` = calibration incomplete  
positive `motion_threshold_AU` = completed per-well threshold  
`motion_threshold_AU=-1` = excluded well  
`fly_count` = observed total number of flies in the well  
`viable_flies` = number judged viable at the time of analysis  
Viability is assumed to apply throughout the experiment for this CAMS release.  
A well is excluded independently when its threshold is -1, `fly_count` is 0, or `viable_flies` is 0.

## First/Last Comparison
`<experiment>_first_last_delta.csv` is produced by `compare_first_last.py` and reports the total first-to-last pixel-change score for each well.  
`<experiment>_first_last_yellow_red_green_labeled.png` is the labeled first/last color composite.  
`<experiment>_first_last_2x2.png` is the 2 × 2 visual review image used to help assess counts and viability.

## Plots
The `plots` directory is created by `generate_plots.py`.  
It contains `A_plate_sleep_wake_raster.png`, `B_percent_awake_vs_time.png`, `C_stimulus_triggered_average_percent_awake.png`, `D_summary_statistics.png`, and `plot_summary.txt`.

## Interpreting AU
CAMS activity is well-level optical activity.  
AU is not an estimate of movement per individual fly, and simultaneous or overlapping animal motion is not expected to combine linearly.
