#!/usr/bin/env python3
"""Interactive CAMS tuner for per-well motion thresholds."""
from pathlib import Path
import csv
import time
import tkinter as tk
from tkinter import messagebox
import cv2
import numpy as np
import activity_config as config

IMAGE_EXTENSIONS=(".png",".jpg",".jpeg",".bmp",".tif",".tiff")
WINDOW_NAME="CAMS Motion Threshold Tuner"
LEFT_KEYS=(81,2424832)
RIGHT_KEYS=(83,2555904)
QUIT_KEYS=(27,ord("q"),ord("Q"))
WHITE=(255,255,255)
GREEN=(0,255,0)
YELLOW=(0,255,255)
DARK_GRAY=(40,40,40)
SELECT_GRAY=(85,85,85)

def list_images(directory):
    directory=Path(directory)
    if not directory.exists(): raise FileNotFoundError(f"Frame directory not found: {directory}")
    files=sorted(p for p in directory.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTENSIONS)
    if len(files)<2: raise ValueError(f"Need at least 2 images in {directory}")
    return files

def load_wells(file):
    wells=[]
    with open(file,"r",newline="",encoding="utf-8") as source:
        reader=csv.DictReader(source)
        required={"well","number","xc","yc","radius"}
        if not reader.fieldnames or not required.issubset(reader.fieldnames): raise ValueError("Well CSV must contain columns: well,number,xc,yc,radius")
        for row in reader: wells.append({"well":row["well"].strip(),"number":int(row["number"]),"xc":float(row["xc"]),"yc":float(row["yc"]),"radius":float(row["radius"])})
    if not wells: raise ValueError(f"No wells found in {file}")
    return wells

def activity_csv_path():
    if hasattr(config,"ACTIVITY_CSV"): return Path(config.ACTIVITY_CSV)
    return Path(config.OUTPUT_DIRECTORY)/f"{config.OUTPUT_BASENAME}.csv"

def load_activity(file,wells):
    valid_wells={w["well"] for w in wells}; units=str(config.ACTIVITY_UNITS); activity_column=f"activity_{units}"; rows=[]
    with open(file,"r",newline="",encoding="utf-8") as source:
        reader=csv.DictReader(source); required={"frame","well",activity_column}
        if not reader.fieldnames or not required.issubset(reader.fieldnames): raise ValueError(f"Activity CSV must contain columns: frame,well,{activity_column}")
        for row in reader:
            name=row["well"].strip(); value=row[activity_column].strip()
            if name not in valid_wells or not value: continue
            rows.append({"frame":int(row["frame"]),"well":name,"activity":float(value)})
    if not rows: raise ValueError(f"No usable activity measurements found in {file}")
    return rows

def write_thresholds(file,wells,thresholds,fly_count,viable_flies):
    file=Path(file); file.parent.mkdir(parents=True,exist_ok=True); decimals=int(getattr(config,"OUTPUT_DECIMALS",2))
    with file.open("w",newline="",encoding="utf-8") as target:
        writer=csv.writer(target); writer.writerow(["well","motion_threshold_AU","fly_count","viable_flies"])
        for w in wells:
            name=w["well"]; value=float(thresholds.get(name,0.0))
            threshold_text=f"{value:.{decimals}f}" if value not in (0.0,-1.0) else str(int(value))
            writer.writerow([name,threshold_text,fly_count.get(name,""),viable_flies.get(name,"")])

def load_or_create_thresholds(file,wells):
    file=Path(file)
    thresholds={w["well"]:0.0 for w in wells}; fly_count={w["well"]:"" for w in wells}; viable_flies={w["well"]:"" for w in wells}
    if not file.exists():
        write_thresholds(file,wells,thresholds,fly_count,viable_flies)
        print(f"Created threshold file with {len(wells)} wells initialized to 0: {file}")
        return thresholds,fly_count,viable_flies
    with file.open("r",newline="",encoding="utf-8") as source:
        reader=csv.DictReader(source)
        required={"well","motion_threshold_AU"}
        if not reader.fieldnames or not required.issubset(reader.fieldnames): raise ValueError("Threshold CSV must contain columns: well,motion_threshold_AU")
        for row in reader:
            name=row["well"].strip()
            if name not in thresholds: continue
            value=row["motion_threshold_AU"].strip(); thresholds[name]=float(value) if value else 0.0
            fly_count[name]=row.get("fly_count","").strip()
            viable_flies[name]=row.get("viable_flies","").strip()
    write_thresholds(file,wells,thresholds,fly_count,viable_flies)
    return thresholds,fly_count,viable_flies

def candidate_samples(activity_rows,thresholds,t,max_count):
    groups={}
    for row in activity_rows:
        well=row["well"]
        if thresholds.get(well,0.0)!=0 or row["activity"]>t: continue
        groups.setdefault(well,[]).append(row)
    rng=np.random.default_rng()
    candidates=[group[int(rng.integers(len(group)))] for group in groups.values()]
    candidates.sort(key=lambda row:row["activity"],reverse=True)
    return candidates[:max_count]

def crop_well(image,well):
    h,w=image.shape[:2]; scale=float(getattr(config,"THRESH_CROP_SCALE",1.20)); r=max(1,int(round(well["radius"]*scale))); x=int(round(well["xc"])); y=int(round(well["yc"]))
    x1=max(0,x-r); x2=min(w,x+r+1); y1=max(0,y-r); y2=min(h,y+r+1); crop=image[y1:y2,x1:x2]
    if crop.size==0: raise ValueError(f"Empty crop for well {well['well']}")
    return crop

def load_candidate_sequences(candidates,files,wells_by_name,sequence_length):
    sequences=[]
    for row in candidates:
        frame=row["frame"]; first_frame=frame-sequence_length+1
        if first_frame<1 or frame>len(files): continue
        images=[]
        for frame_number in range(first_frame,frame+1):
            image=cv2.imread(str(files[frame_number-1]),cv2.IMREAD_GRAYSCALE)
            if image is None: raise FileNotFoundError(f"Could not read frame {frame_number}")
            images.append(crop_well(image,wells_by_name[row["well"]]))
        combined=np.concatenate([image.ravel() for image in images]).astype(np.float32); low,high=np.percentile(combined,[1,99])
        if high>low: images=[np.clip((image.astype(np.float32)-low)*(255.0/(high-low)),0,255).astype(np.uint8) for image in images]
        sequences.append((row,images))
    return sequences

def make_tile(image,row,width,height):
    tile=cv2.cvtColor(image,cv2.COLOR_GRAY2BGR); usable_h=max(1,height-25); tile=cv2.resize(tile,(width,usable_h),interpolation=cv2.INTER_NEAREST)
    canvas=np.zeros((height,width,3),dtype=np.uint8); canvas[25:]=tile; label=f"{row['well']}  #{row['well_number']}  {row['activity']:.2f} AU"
    cv2.putText(canvas,label,(5,18),cv2.FONT_HERSHEY_SIMPLEX,0.48,WHITE,1,cv2.LINE_AA); return canvas

def compose_display(sequences,sequence_index,rows,columns,width,height,t,toggle_rate,sequence_length,selected,remaining,status):
    panel_height=88; grid_height=max(80,height-panel_height); cell_w=max(40,width//columns); cell_h=max(50,grid_height//rows)
    canvas=np.zeros((height,width,3),dtype=np.uint8); tile_rects=[]
    for i,(row,images) in enumerate(sequences[:rows*columns]):
        rr=i//columns; cc=i%columns; x1=cc*cell_w; y1=rr*cell_h; x2=width if cc==columns-1 else (cc+1)*cell_w; y2=grid_height if rr==rows-1 else (rr+1)*cell_h
        canvas[y1:y2,x1:x2]=make_tile(images[min(sequence_index,len(images)-1)],row,x2-x1,y2-y1); tile_rects.append((x1,y1,x2,y2,row))
    canvas[grid_height:]=DARK_GRAY
    labels=[f"Threshold  {t:.2f} AU",f"Toggle Rate  {toggle_rate:.1f}/s",f"SEQLEN  {sequence_length}",f"Rows  {rows}",f"Columns  {columns}"]; colw=width/5
    for i,label in enumerate(labels):
        x1=round(i*colw); x2=round((i+1)*colw)
        if i==selected: cv2.rectangle(canvas,(x1,grid_height),(x2-1,grid_height+34),SELECT_GRAY,-1)
        cv2.putText(canvas,label,(x1+7,grid_height+23),cv2.FONT_HERSHEY_SIMPLEX,0.47,GREEN if i==selected else WHITE,1,cv2.LINE_AA)
    info=f"{remaining} wells remaining   Left click select   Right click unresolved (-1)   U undo   S save   Q quit"
    cv2.putText(canvas,info,(7,grid_height+54),cv2.FONT_HERSHEY_SIMPLEX,0.39,WHITE,1,cv2.LINE_AA)
    if status: cv2.putText(canvas,status,(7,grid_height+78),cv2.FONT_HERSHEY_SIMPLEX,0.38,YELLOW,1,cv2.LINE_AA)
    return canvas,tile_rects

def ask_save_before_quit(selected_count):
    if selected_count<=0: return False
    root=tk.Tk(); root.withdraw(); answer=messagebox.askyesnocancel("CAMS Motion Threshold Tuner",f"{selected_count} wells selected. Save before quitting?",parent=root); root.destroy(); return answer

def motion_threshold_tuner():
    files=list_images(config.FRAME_DIRECTORY); wells=load_wells(config.WELLS_CSV); wells_by_name={w["well"]:w for w in wells}; activity_file=activity_csv_path()
    if not activity_file.exists(): raise FileNotFoundError(f"Activity CSV not found: {activity_file}")
    activity_rows=load_activity(activity_file,wells)
    for row in activity_rows: row["well_number"]=wells_by_name[row["well"]]["number"]
    thresholds,fly_count,viable_flies=load_or_create_thresholds(config.THRESHOLD_CSV,wells)
    threshold_scale=float(config.THRESH_SCALE); toggle_scale=float(getattr(config,"TOGGLE_RATE_SCALE",0.1)); rows=max(1,int(config.DISPLAY_ROWS)); columns=max(1,int(config.DISPLAY_COLUMNS))
    toggle_rate=max(toggle_scale,float(getattr(config,"TOGGLE_RATE",1.0))); sequence_length=max(2,int(getattr(config,"SEQUENCE_LENGTH",3))); start_percentile=float(config.START_THRESHOLD_PERCENTILE)
    t=float(np.percentile(np.array([row["activity"] for row in activity_rows],dtype=float),start_percentile)); selected=0; status=f"Threshold starts at {start_percentile:g}th percentile = {t:.2f} AU"
    sequence_index=0; sequence_direction=1; last_toggle=time.monotonic(); clicks=[]; undo_stack=[]; tile_rects=[]; cached_sequences=[]; cache_dirty=True
    saved_thresholds=dict(thresholds)
    def unsaved_well_count():
        changed=set()
        for w in wells:
            name=w["well"]
            if thresholds.get(name,0.0)!=saved_thresholds.get(name,0.0): changed.add(name)
        return len(changed)
    def save_results():
        nonlocal saved_thresholds,status
        write_thresholds(config.THRESHOLD_CSV,wells,thresholds,fly_count,viable_flies); saved_thresholds=dict(thresholds); status=f"Saved {config.THRESHOLD_CSV}"; print(status)
    def request_quit():
        count=unsaved_well_count()
        if count==0: return True
        answer=ask_save_before_quit(count)
        if answer is None: return False
        if answer: save_results()
        return True
    cv2.namedWindow(WINDOW_NAME,cv2.WINDOW_NORMAL); cv2.resizeWindow(WINDOW_NAME,int(getattr(config,"THRESH_WINDOW_WIDTH",1100)),int(getattr(config,"THRESH_WINDOW_HEIGHT",850)))
    def mouse_callback(event,x,y,flags,param):
        if event in (cv2.EVENT_LBUTTONDOWN,cv2.EVENT_RBUTTONDOWN): clicks.append((event,x,y))
    cv2.setMouseCallback(WINDOW_NAME,mouse_callback)
    while True:
        remaining=sum(thresholds.get(w["well"],0.0)==0 for w in wells)
        try:
            if cv2.getWindowProperty(WINDOW_NAME,cv2.WND_PROP_VISIBLE)<1:
                if request_quit(): break
                cv2.namedWindow(WINDOW_NAME,cv2.WINDOW_NORMAL); cv2.resizeWindow(WINDOW_NAME,int(getattr(config,"THRESH_WINDOW_WIDTH",1100)),int(getattr(config,"THRESH_WINDOW_HEIGHT",850))); cv2.setMouseCallback(WINDOW_NAME,mouse_callback)
        except cv2.error: pass
        try: _,_,window_w,window_h=cv2.getWindowImageRect(WINDOW_NAME)
        except cv2.error: window_w=int(getattr(config,"THRESH_WINDOW_WIDTH",1100)); window_h=int(getattr(config,"THRESH_WINDOW_HEIGHT",850))
        window_w=max(500,window_w); window_h=max(350,window_h)
        if cache_dirty:
            candidates=candidate_samples(activity_rows,thresholds,t,rows*columns); cached_sequences=load_candidate_sequences(candidates,files,wells_by_name,sequence_length); sequence_index=0; sequence_direction=1; last_toggle=time.monotonic()
            if remaining==0: status="All wells calibrated or marked -1. Press S to save or Q to quit."
            elif len(cached_sequences)<min(rows*columns,remaining): status=f"{len(cached_sequences)} eligible wells at or below {t:.2f} AU; increase Threshold for more."
            cache_dirty=False
        display,tile_rects=compose_display(cached_sequences,sequence_index,rows,columns,window_w,window_h,t,toggle_rate,sequence_length,selected,remaining,status); cv2.imshow(WINDOW_NAME,display); key=cv2.waitKeyEx(1)
        while clicks:
            event,x,y=clicks.pop(0); chosen=None
            for x1,y1,x2,y2,row in tile_rects:
                if x1<=x<x2 and y1<=y<y2: chosen=row; break
            if chosen is None: continue
            well=chosen["well"]
            if event==cv2.EVENT_RBUTTONDOWN:
                previous=thresholds.get(well,0.0); thresholds[well]=-1.0; undo_stack.append(("threshold",well,previous)); status=f"{well} marked unresolved: threshold = -1"; print(status); cache_dirty=True; continue
            if chosen["activity"]<=0: status="0 AU cannot be selected because 0 means uncalibrated."; continue
            previous=thresholds.get(well,0.0); thresholds[well]=chosen["activity"]; undo_stack.append(("threshold",well,previous)); status=f"Selected {well} = {chosen['activity']:.2f} AU"; print(status); cache_dirty=True
        now=time.monotonic()
        if now-last_toggle>=1.0/toggle_rate:
            sequence_index+=sequence_direction
            if sequence_index>=sequence_length-1: sequence_index=sequence_length-1; sequence_direction=-1
            elif sequence_index<=0: sequence_index=0; sequence_direction=1
            last_toggle=now
        if key==-1: continue
        if key in QUIT_KEYS:
            if request_quit(): break
            continue
        if key in LEFT_KEYS: selected=(selected-1)%5; status=""; continue
        if key in RIGHT_KEYS: selected=(selected+1)%5; status=""; continue
        if key in (ord("s"),ord("S")): save_results(); continue
        if key in (ord("u"),ord("U")):
            if not undo_stack: status="Nothing to undo."
            else:
                action,well,previous=undo_stack.pop()
                thresholds[well]=previous
                if previous==-1: status=f"Undo: {well} restored to unresolved (-1)"
                elif previous>0: status=f"Undo: {well} restored to {previous:.2f} AU"
                else: status=f"Undo: {well} returned to uncalibrated"
                print(status); cache_dirty=True
            continue
        direction=0; large=False
        if key==ord("="): direction=1
        elif key==ord("-"): direction=-1
        elif key==ord("+"): direction=1; large=True
        elif key==ord("_"): direction=-1; large=True
        if not direction: continue
        multiplier=10 if large else 1
        if selected==0:
            new_t=max(0.0,t+direction*threshold_scale*multiplier)
            if new_t!=t: t=new_t; cache_dirty=True
        elif selected==1: toggle_rate=max(toggle_scale,toggle_rate+direction*toggle_scale*multiplier)
        elif selected==2:
            new_length=max(2,sequence_length+direction*multiplier)
            if new_length!=sequence_length: sequence_length=new_length; cache_dirty=True
        elif selected==3:
            new_rows=max(1,rows+direction*multiplier)
            if new_rows!=rows: rows=new_rows; cache_dirty=True
        elif selected==4:
            new_columns=max(1,columns+direction*multiplier)
            if new_columns!=columns: columns=new_columns; cache_dirty=True
        status=""
    cv2.destroyAllWindows()

if __name__=="__main__":
    try: motion_threshold_tuner()
    except Exception as error:
        cv2.destroyAllWindows(); print(f"motion_threshold_tuner failed: {error}"); raise SystemExit(1)
