#!/usr/bin/env python3
"""Extract sequential image frames from the configured experiment video using FFmpeg."""
from pathlib import Path
import subprocess
import shutil
import activity_config as config

def extract_frames():
    video_file=Path(config.VIDEO_FILE)
    frame_directory=Path(config.FRAME_DIRECTORY)
    frame_rate=float(config.FRAME_RATE_FPS)
    image_format=getattr(config,"FRAME_IMAGE_FORMAT","png").lower().lstrip(".")
    filename_pattern=getattr(config,"FRAME_FILENAME_PATTERN",f"frame_%06d.{image_format}")

    if not video_file.exists():
        print(f"ERROR: Video file not found: {video_file}")
        return False
    if frame_rate<=0:
        print(f"ERROR: FRAME_RATE_FPS must be greater than zero: {frame_rate}")
        return False
    ffmpeg=shutil.which("ffmpeg")
    if ffmpeg is None:
        print("ERROR: FFmpeg was not found. Install FFmpeg and make sure ffmpeg is in the system PATH.")
        return False

    frame_directory.mkdir(parents=True,exist_ok=True)
    existing=list(frame_directory.glob(f"*.{image_format}"))
    if existing:
        print(f"ERROR: {frame_directory} already contains {len(existing)} .{image_format} image files.")
        print("Remove or move the existing frames before extracting a new set.")
        return False

    output_file=frame_directory/filename_pattern
    command=[ffmpeg,"-hide_banner","-loglevel","error","-i",str(video_file),"-vf",f"fps={frame_rate:g}","-start_number","1",str(output_file)]

    print(f"Video: {video_file}")
    print(f"Frame rate: {frame_rate:g} frame(s)/second")
    print(f"Output directory: {frame_directory}")
    try:
        subprocess.run(command,check=True)
    except subprocess.CalledProcessError as error:
        print(f"ERROR: FFmpeg failed with return code {error.returncode}.")
        return False

    frames=sorted(frame_directory.glob(f"*.{image_format}"))
    if not frames:
        print("ERROR: FFmpeg completed but no image files were created.")
        return False

    print(f"Extracted {len(frames)} frames.")
    return True

if __name__=="__main__":
    raise SystemExit(0 if extract_frames() else 1)
