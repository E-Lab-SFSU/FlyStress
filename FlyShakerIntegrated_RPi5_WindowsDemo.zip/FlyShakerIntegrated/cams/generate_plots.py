#!/usr/bin/env python3
"""Generate four sleep/wake summary plots from activity-analysis CSV outputs using activity_config.py."""
from pathlib import Path
import math
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import activity_config as config

def activity_csv_path():
    if hasattr(config,"ACTIVITY_CSV"): return Path(config.ACTIVITY_CSV)
    return Path(config.OUTPUT_DIRECTORY)/f"{config.OUTPUT_BASENAME}.csv"

def plate_csv_path():
    return Path(config.OUTPUT_DIRECTORY)/f"{config.OUTPUT_BASENAME}_plate.csv"

def plots_directory():
    return Path(getattr(config,"PLOTS_DIRECTORY",Path(config.OUTPUT_DIRECTORY)/"plots"))

def stimulus_times_from_config():
    if hasattr(config,"STIMULUS_TIMES_SECONDS"):
        values=getattr(config,"STIMULUS_TIMES_SECONDS")
        if values is None: return []
        return [float(v) for v in values]
    return []

def infer_stimulus_times(plate_df):
    if "plate_activity_AU" not in plate_df.columns: return []
    series=plate_df[["time_s","plate_activity_AU"]].dropna().sort_values("time_s")
    if len(series)<3: return []
    time=series["time_s"].to_numpy(dtype=float)
    activity=series["plate_activity_AU"].to_numpy(dtype=float)
    threshold=float(activity.mean()+3.0*activity.std())
    merge_seconds=float(getattr(config,"STIMULUS_MERGE_SECONDS",20.0))
    raw_peaks=[]
    for i in range(1,len(activity)-1):
        if activity[i]>threshold and activity[i]>=activity[i-1] and activity[i]>=activity[i+1]:
            raw_peaks.append((time[i],activity[i]))
    merged=[]
    for t,a in raw_peaks:
        if not merged or (t-merged[-1][0])>merge_seconds:
            merged.append([t,a])
        elif a>merged[-1][1]:
            merged[-1]=[t,a]
    return [float(t) for t,a in merged]

def load_data():
    well_file=activity_csv_path()
    plate_file=plate_csv_path()
    if not well_file.exists(): raise FileNotFoundError(f"Activity CSV not found: {well_file}")
    if not plate_file.exists(): raise FileNotFoundError(f"Plate CSV not found: {plate_file}")
    well_df=pd.read_csv(well_file)
    plate_df=pd.read_csv(plate_file)
    for col in ["time_s","frame","awake","motion_detected","inactive_seconds"]:
        if col in well_df.columns: well_df[col]=pd.to_numeric(well_df[col],errors="coerce")
    for col in ["time_s","frame","plate_activity_AU","percent_awake","percent_sleeping","awake_wells","sleeping_wells","invalid_wells","valid_wells","total_flies","viable_flies"]:
        if col in plate_df.columns: plate_df[col]=pd.to_numeric(plate_df[col],errors="coerce")
    return well_df,plate_df,well_file,plate_file

def ensure_plate_percentages(well_df,plate_df):
    if "percent_awake" in plate_df.columns and plate_df["percent_awake"].notna().any():
        return plate_df
    if "awake" not in well_df.columns: raise ValueError("Cannot compute percent_awake because awake column is missing.")
    grouped=well_df.groupby("time_s")
    rows=[]
    for time_s,group in grouped:
        awake_vals=pd.to_numeric(group["awake"],errors="coerce")
        valid=awake_vals[awake_vals.isin([0,1])]
        invalid=(awake_vals==-1).sum()
        awake_count=(valid==1).sum()
        sleep_count=(valid==0).sum()
        valid_count=len(valid)
        row={"time_s":time_s,"valid_wells":valid_count,"awake_wells":awake_count,"sleeping_wells":sleep_count,"invalid_wells":invalid,
             "percent_awake":100.0*awake_count/valid_count if valid_count else np.nan,
             "percent_sleeping":100.0*sleep_count/valid_count if valid_count else np.nan}
        if "plate_activity_AU" in plate_df.columns:
            match=plate_df.loc[plate_df["time_s"]==time_s,"plate_activity_AU"]
            if len(match): row["plate_activity_AU"]=float(match.iloc[0])
        rows.append(row)
    computed=pd.DataFrame(rows).sort_values("time_s").reset_index(drop=True)
    if "plate_activity_AU" in plate_df.columns and "plate_activity_AU" not in computed.columns:
        computed["plate_activity_AU"]=plate_df["plate_activity_AU"].to_numpy()
    return computed

def ordered_wells(well_names):
    well_names=[str(w) for w in well_names]
    def key(name):
        prefix="".join(ch for ch in name if ch.isalpha()).upper()
        suffix="".join(ch for ch in name if ch.isdigit())
        col=int(suffix) if suffix else 9999
        return (prefix,col,name)
    return sorted(well_names,key=key)

def plot_raster(well_df,stim_times,out_dir):
    if "awake" not in well_df.columns: raise ValueError("Activity CSV does not contain awake column.")
    order=ordered_wells(well_df["well"].dropna().unique())
    raster=well_df.pivot(index="well",columns="time_s",values="awake").reindex(order)
    fig,ax=plt.subplots(figsize=(14,7))
    im=ax.imshow(raster.to_numpy(),aspect="auto",interpolation="nearest",
                 extent=[float(raster.columns.min()),float(raster.columns.max()),len(order)-0.5,-0.5])
    ax.set_yticks(range(len(order)))
    ax.set_yticklabels(order)
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Well")
    ax.set_title("A. Plate sleep/wake raster")
    for t in stim_times: ax.axvline(t,linestyle="--")
    cbar=fig.colorbar(im,ax=ax)
    cbar.set_label("Awake state (-1 invalid, 0 asleep, 1 awake)")
    fig.tight_layout()
    path=out_dir/"A_plate_sleep_wake_raster.png"
    fig.savefig(path,dpi=200,bbox_inches="tight")
    plt.close(fig)
    return path

def plot_percent_awake(plate_df,stim_times,out_dir):
    if "percent_awake" not in plate_df.columns: raise ValueError("Plate CSV does not contain percent_awake.")
    fig,ax=plt.subplots(figsize=(14,5))
    ax.plot(plate_df["time_s"],plate_df["percent_awake"])
    for t in stim_times: ax.axvline(t,linestyle="--")
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Percent awake")
    ax.set_title("B. Percent awake vs time")
    fig.tight_layout()
    path=out_dir/"B_percent_awake_vs_time.png"
    fig.savefig(path,dpi=200,bbox_inches="tight")
    plt.close(fig)
    return path

def stimulus_triggered_average(plate_df,stim_times,out_dir):
    if "percent_awake" not in plate_df.columns: raise ValueError("Plate CSV does not contain percent_awake.")
    pre_s=int(getattr(config,"STIMULUS_PRE_SECONDS",120))
    post_s=int(getattr(config,"STIMULUS_POST_SECONDS",180))
    window=np.arange(-pre_s,post_s+1,1)
    series=plate_df.set_index("time_s")["percent_awake"]
    aligned=[]
    for t0 in stim_times:
        vals=[]
        for dt in window:
            vals.append(series.get(t0+dt,np.nan))
        aligned.append(vals)
    aligned=np.array(aligned,dtype=float) if aligned else np.empty((0,len(window)))
    mean_trace=np.nanmean(aligned,axis=0) if aligned.size else np.full(len(window),np.nan)
    if aligned.shape[0]>1:
        sem_trace=np.nanstd(aligned,axis=0,ddof=1)/np.sqrt(np.sum(~np.isnan(aligned),axis=0))
    else:
        sem_trace=np.full(len(window),np.nan)
    fig,ax=plt.subplots(figsize=(12,5))
    ax.plot(window,mean_trace)
    if aligned.shape[0]>1: ax.fill_between(window,mean_trace-sem_trace,mean_trace+sem_trace,alpha=0.3)
    ax.axvline(0,linestyle="--")
    ax.set_xlabel("Time relative to stimulus (s)")
    ax.set_ylabel("Percent awake")
    ax.set_title("C. Stimulus-triggered average")
    fig.tight_layout()
    path=out_dir/"C_stimulus_triggered_average_percent_awake.png"
    fig.savefig(path,dpi=200,bbox_inches="tight")
    plt.close(fig)
    return path

def summary_statistics_plot(plate_df,stim_times,out_dir):
    if "percent_awake" not in plate_df.columns: raise ValueError("Plate CSV does not contain percent_awake.")
    series_awake=plate_df.set_index("time_s")["percent_awake"]
    series_sleep=plate_df.set_index("time_s")["percent_sleeping"] if "percent_sleeping" in plate_df.columns else None
    rows=[]
    for t0 in stim_times:
        before=series_awake.get(t0-1,np.nan)
        after30=series_awake.get(t0+30,np.nan)
        after60=series_awake.get(t0+60,np.nan)
        if series_sleep is not None:
            base_window=series_sleep.loc[(series_sleep.index>=t0-60)&(series_sleep.index<t0)]
            stim_window=series_sleep.loc[(series_sleep.index>=t0)&(series_sleep.index<=t0+60)]
            sleep_base=float(base_window.mean()) if len(base_window) else np.nan
            sleep_stim=float(stim_window.mean()) if len(stim_window) else np.nan
        else:
            sleep_base=np.nan; sleep_stim=np.nan
        rows.append([before,after30,after60,sleep_base,sleep_stim])
    data=np.array(rows,dtype=float) if rows else np.empty((0,5))
    labels=["% awake before","% awake +30 s","% awake +60 s","% sleeping baseline","% sleeping 0-60 s"]
    means=np.nanmean(data,axis=0) if data.size else np.full(5,np.nan)
    fig,ax=plt.subplots(figsize=(10,5))
    x=np.arange(len(labels))
    ax.bar(x,means)
    if data.size:
        for i in range(data.shape[0]): ax.plot(x,data[i],"o")
    ax.set_xticks(x)
    ax.set_xticklabels(labels,rotation=20,ha="right")
    ax.set_ylabel("Percent")
    ax.set_title("D. Summary statistics")
    fig.tight_layout()
    path=out_dir/"D_summary_statistics.png"
    fig.savefig(path,dpi=200,bbox_inches="tight")
    plt.close(fig)
    return path,data,labels,means

def write_summary(out_dir,well_file,plate_file,stim_times,plate_df):
    summary_path=out_dir/"plot_summary.txt"
    with summary_path.open("w",encoding="utf-8") as target:
        target.write("Sleep/wake plot summary\n")
        target.write(f"Activity CSV: {well_file}\n")
        target.write(f"Plate CSV: {plate_file}\n")
        target.write(f"Plot directory: {out_dir}\n")
        target.write(f"Stimulus times (s): {', '.join(f'{t:g}' for t in stim_times) if stim_times else 'none'}\n")
        if "percent_awake" in plate_df.columns and plate_df["percent_awake"].notna().any():
            target.write(f"Percent awake min/max: {float(plate_df['percent_awake'].min()):.1f} / {float(plate_df['percent_awake'].max()):.1f}\n")
        if "valid_wells" in plate_df.columns and plate_df["valid_wells"].notna().any():
            target.write(f"Valid wells min/max: {float(plate_df['valid_wells'].min()):.0f} / {float(plate_df['valid_wells'].max()):.0f}\n")
        if "total_flies" in plate_df.columns and plate_df["total_flies"].notna().any(): target.write(f"Total flies: {float(plate_df['total_flies'].dropna().iloc[0]):.0f}\n")
        if "viable_flies" in plate_df.columns and plate_df["viable_flies"].notna().any(): target.write(f"Viable flies: {float(plate_df['viable_flies'].dropna().iloc[0]):.0f}\n")
    return summary_path

def main():
    well_df,plate_df,well_file,plate_file=load_data()
    plate_df=ensure_plate_percentages(well_df,plate_df)
    out_dir=plots_directory()
    out_dir.mkdir(parents=True,exist_ok=True)

    stim_times=stimulus_times_from_config()
    stimulus_source="config"
    if not stim_times:
        stim_times=infer_stimulus_times(plate_df)
        stimulus_source="inferred from plate activity"

    raster_path=plot_raster(well_df,stim_times,out_dir)
    percent_path=plot_percent_awake(plate_df,stim_times,out_dir)
    triggered_path=stimulus_triggered_average(plate_df,stim_times,out_dir)
    summary_plot_path,summary_data,summary_labels,summary_means=summary_statistics_plot(plate_df,stim_times,out_dir)
    summary_txt=write_summary(out_dir,well_file,plate_file,stim_times,plate_df)

    print(f"Stimulus times source: {stimulus_source}")
    print(f"Stimulus times (s): {', '.join(f'{t:g}' for t in stim_times) if stim_times else 'none'}")
    print(f"Raster plot:          {raster_path}")
    print(f"Percent awake plot:   {percent_path}")
    print(f"Triggered average:    {triggered_path}")
    print(f"Summary statistics:   {summary_plot_path}")
    print(f"Summary text:         {summary_txt}")

if __name__=="__main__":
    try:
        main()
    except Exception as error:
        print(f"generate_plots failed: {error}")
        raise SystemExit(1)
