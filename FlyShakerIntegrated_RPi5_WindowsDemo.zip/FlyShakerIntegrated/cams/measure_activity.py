#!/usr/bin/env python3
"""Measure camera-based well activity using settings from activity_config.py. Sleep/wake classification is performed later by classify_sleep.py."""
from pathlib import Path
from collections import deque
import csv
import cv2
import numpy as np
import activity_config as config

IMAGE_EXTENSIONS=(".png",".jpg",".jpeg",".bmp",".tif",".tiff")

def list_images(directory):
    directory=Path(directory)
    if not directory.exists(): raise FileNotFoundError(f"Frame directory not found: {directory}")
    files=sorted(p for p in directory.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTENSIONS)
    if len(files)<2: raise ValueError(f"Need at least 2 images in {directory}")
    return files

def load_wells(file):
    wells=[]
    with open(file,"r",newline="",encoding="utf-8") as source:
        for row in csv.DictReader(source):
            wells.append((row["well"],int(row["number"]),float(row["xc"]),float(row["yc"]),float(row["radius"])))
    if not wells: raise ValueError(f"No wells found in {file}")
    return wells

def load_gray(file):
    image=cv2.imread(str(file),cv2.IMREAD_GRAYSCALE)
    if image is None: raise FileNotFoundError(f"Could not read image: {file}")
    return image

def load_or_make_background(files,output_directory):
    if str(config.BACKGROUND_METHOD).lower()!="median": raise ValueError("Currently only BACKGROUND_METHOD='median' is supported.")
    background_file=Path(getattr(config,"BACKGROUND_FILE",Path(output_directory)/"median_background.png"))
    if background_file.exists():
        background=load_gray(background_file)
        print(f"Using existing background: {background_file}")
        return background
    sample_count=min(int(config.BACKGROUND_SAMPLE_FRAMES),len(files))
    sample_indices=np.random.default_rng().choice(len(files),size=sample_count,replace=False)
    sample_files=[files[index] for index in sample_indices]
    print(f"No background image found: {background_file}")
    print(f"Calculating median background from {sample_count} randomly selected frames...")
    background=np.median(np.stack([load_gray(file) for file in sample_files],axis=0),axis=0).astype(np.uint8)
    background_file.parent.mkdir(parents=True,exist_ok=True)
    if not cv2.imwrite(str(background_file),background): raise IOError(f"Could not save background image: {background_file}")
    print(f"Saved background: {background_file}")
    return background

def make_well_indices(shape,wells,scale):
    h,w=shape; yy,xx=np.ogrid[:h,:w]; result=[]
    for name,number,xc,yc,radius in wells:
        mask=(xx-xc)**2+(yy-yc)**2 <= (radius*scale)**2
        result.append((name,number,np.flatnonzero(mask)))
    return result

def validate_config():
    if not 0<float(config.MASK_SCALE)<=1: raise ValueError("MASK_SCALE must be >0 and <=1.")
    if float(config.FRAME_INTERVAL_SECONDS)<=0: raise ValueError("FRAME_INTERVAL_SECONDS must be >0.")
    if int(config.RUNNING_WINDOW_SECONDS)<1: raise ValueError("RUNNING_WINDOW_SECONDS must be >=1.")
    if int(config.BACKGROUND_SAMPLE_FRAMES)<1: raise ValueError("BACKGROUND_SAMPLE_FRAMES must be >=1.")
    if float(config.ACTIVITY_SCALE)<=0: raise ValueError("ACTIVITY_SCALE must be >0.")
    if int(config.OUTPUT_DECIMALS)<0: raise ValueError("OUTPUT_DECIMALS must be >=0.")

def measure_activity():
    validate_config()
    files=list_images(config.FRAME_DIRECTORY); wells=load_wells(config.WELLS_CSV)
    output_directory=Path(config.OUTPUT_DIRECTORY); output_directory.mkdir(parents=True,exist_ok=True)
    background=load_or_make_background(files,output_directory)
    indices=make_well_indices(background.shape,wells,float(config.MASK_SCALE))
    background_flat=background.ravel().astype(np.float64)
    background_sum={name:float(background_flat[idx].sum()) for name,number,idx in indices}
    if any(value<=0 for value in background_sum.values()): raise ValueError("One or more wells have zero background brightness.")

    print("Activity measurement mode: calculating AU only; motion/sleep classification will be added later by classify_sleep.py.")
    dt=float(config.FRAME_INTERVAL_SECONDS)
    samples_per_window=max(1,round(float(config.RUNNING_WINDOW_SECONDS)/dt))
    history={name:deque(maxlen=samples_per_window) for name,number,idx in indices}
    running_sum={name:0.0 for name,number,idx in indices}
    plate_history=deque(maxlen=samples_per_window); plate_running_sum=0.0
    previous=load_gray(files[0]); previous_shape=previous.shape

    well_csv=output_directory/f"{config.OUTPUT_BASENAME}.csv"
    plate_csv=output_directory/f"{config.OUTPUT_BASENAME}_plate.csv"
    decimals=int(config.OUTPUT_DECIMALS); scale=float(config.ACTIVITY_SCALE); units=str(config.ACTIVITY_UNITS)

    well_target=well_csv.open("w",newline="",encoding="utf-8") if config.SAVE_WELL_RESULTS else None
    plate_target=plate_csv.open("w",newline="",encoding="utf-8") if config.SAVE_PLATE_RESULTS else None
    try:
        writer=csv.writer(well_target) if well_target else None
        plate_writer=csv.writer(plate_target) if plate_target else None
        if writer:
            writer.writerow(["frame","time_s","well","well_number",f"activity_{units}",f"running_avg_{config.RUNNING_WINDOW_SECONDS}s_{units}","motion_detected","inactive_seconds","awake"])
            for name,number,idx in indices: writer.writerow([1,0,name,number,"","","","",""])
        if plate_writer:
            plate_writer.writerow(["frame","time_s",f"plate_activity_{units}",f"running_avg_{config.RUNNING_WINDOW_SECONDS}s_{units}"])
            plate_writer.writerow([1,0,"",""])

        for frame_index,file in enumerate(files[1:],start=2):
            current=load_gray(file)
            if current.shape!=previous_shape: raise ValueError(f"Image size changed at {file}: {current.shape} vs {previous_shape}")
            diff=cv2.absdiff(current,previous).ravel(); time_s=(frame_index-1)*dt; plate_activity=0.0
            rows=[]
            for name,number,idx in indices:
                activity=(float(diff[idx].sum())/background_sum[name])*scale
                plate_activity+=activity
                q=history[name]
                if len(q)==q.maxlen: running_sum[name]-=q[0]
                q.append(activity); running_sum[name]+=activity
                running_avg=running_sum[name]/len(q)
                rows.append([frame_index,f"{time_s:.3f}",name,number,f"{activity:.{decimals}f}",f"{running_avg:.{decimals}f}","","",""])
            if writer: writer.writerows(rows)

            if len(plate_history)==plate_history.maxlen: plate_running_sum-=plate_history[0]
            plate_history.append(plate_activity); plate_running_sum+=plate_activity
            plate_running_avg=plate_running_sum/len(plate_history)
            if plate_writer: plate_writer.writerow([frame_index,f"{time_s:.3f}",f"{plate_activity:.{decimals}f}",f"{plate_running_avg:.{decimals}f}"])
            previous=current
            if frame_index%60==0 or frame_index==len(files): print(f"Processed {frame_index}/{len(files)} frames")
    finally:
        if well_target: well_target.close()
        if plate_target: plate_target.close()

    if config.SAVE_WELL_RESULTS: print(f"Well activity:  {well_csv}")
    if config.SAVE_PLATE_RESULTS: print(f"Plate activity: {plate_csv}")
    print(f"Running window: {config.RUNNING_WINDOW_SECONDS} s ({samples_per_window} samples)")
    print(f"Activity scale: 1 {units} = {1.0/scale:g} NPD")

if __name__=="__main__":
    try:
        measure_activity()
    except Exception as error:
        print(f"measure_activity failed: {error}")
        raise SystemExit(1)
