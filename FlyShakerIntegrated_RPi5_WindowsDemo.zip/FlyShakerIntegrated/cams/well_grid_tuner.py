#!/usr/bin/env python3
"""Interactive tuner for defining a regular well grid from four corner-well centers."""
from pathlib import Path
import csv
import cv2
import numpy as np
import activity_config as config

IMAGE_DIRECTORY=Path(config.FRAME_DIRECTORY)
OUTPUT_CSV=Path(config.WELLS_CSV)
WINDOW_NAME="Well Grid Tuner"
IMAGE_EXTENSIONS=(".png",".jpg",".jpeg",".bmp",".tif",".tiff")

WHITE=(255,255,255)
YELLOW=(0,255,255)
GREEN=(0,255,0)
RED=(0,0,255)
DARK_GRAY=(45,45,45)
SELECT_GRAY=(85,85,85)

PARAMETERS=("ROWS","COLUMNS","WELL RADIUS","FRAME")
LEFT_KEYS=(81,2424832)
RIGHT_KEYS=(83,2555904)
QUIT_KEYS=(27,ord("q"),ord("Q"))

def list_images():
    if not IMAGE_DIRECTORY.exists(): raise FileNotFoundError(f"Frame directory not found: {IMAGE_DIRECTORY}")
    files=sorted(p for p in IMAGE_DIRECTORY.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTENSIONS)
    if not files: raise FileNotFoundError(f"No images found in: {IMAGE_DIRECTORY}")
    return files

def initial_corners(width,height):
    return [
        [width*0.25,height*0.25],
        [width*0.75,height*0.25],
        [width*0.75,height*0.75],
        [width*0.25,height*0.75],
    ]

def order_corners(points):
    pts=np.asarray(points,dtype=np.float32)
    sums=pts[:,0]+pts[:,1]
    diffs=pts[:,0]-pts[:,1]
    top_left=pts[np.argmin(sums)]
    bottom_right=pts[np.argmax(sums)]
    top_right=pts[np.argmax(diffs)]
    bottom_left=pts[np.argmin(diffs)]
    return np.array([top_left,top_right,bottom_right,bottom_left],dtype=np.float32)

def interpolate_grid(corners,rows,columns):
    top_left,top_right,bottom_right,bottom_left=corners
    grid=[]
    for row in range(rows):
        v=0.0 if rows==1 else row/(rows-1)
        left=(1-v)*top_left+v*bottom_left
        right=(1-v)*top_right+v*bottom_right
        for column in range(columns):
            u=0.0 if columns==1 else column/(columns-1)
            point=(1-u)*left+u*right
            grid.append((row,column,float(point[0]),float(point[1])))
    return grid

def well_name(row,column):
    letters=""
    value=row+1
    while value:
        value,remainder=divmod(value-1,26)
        letters=chr(ord("A")+remainder)+letters
    return f"{letters}{column+1}"

def draw_overlay(image,points,rows,columns,radius):
    display=image.copy()
    corners=order_corners(points)
    polygon=np.round(corners).astype(np.int32)
    cv2.polylines(display,[polygon],True,YELLOW,2,cv2.LINE_AA)

    for row,column,x,y in interpolate_grid(corners,rows,columns):
        center=(round(x),round(y))
        cv2.circle(display,center,round(radius),GREEN,1,cv2.LINE_AA)
        cv2.circle(display,center,2,GREEN,-1)
        cv2.putText(display,well_name(row,column),(center[0]+4,center[1]-4),cv2.FONT_HERSHEY_SIMPLEX,0.38,GREEN,1,cv2.LINE_AA)

    for index,(x,y) in enumerate(points,1):
        center=(round(x),round(y))
        cv2.circle(display,center,7,RED,-1)
        cv2.circle(display,center,10,WHITE,1,cv2.LINE_AA)
        cv2.putText(display,str(index),(center[0]+10,center[1]-10),cv2.FONT_HERSHEY_SIMPLEX,0.5,RED,1,cv2.LINE_AA)
    return display

def add_panel(image,selected,rows,columns,radius,frame_number,frame_count):
    panel_height=64
    height,width=image.shape[:2]
    canvas=np.zeros((height+panel_height,width,3),dtype=np.uint8)
    canvas[:height]=image
    canvas[height:]=DARK_GRAY
    values=(str(rows),str(columns),f"{radius:.0f}",f"{frame_number}/{frame_count}")
    column_width=width/len(PARAMETERS)

    for index,(label,value) in enumerate(zip(PARAMETERS,values)):
        x1=round(index*column_width)
        x2=round((index+1)*column_width)
        if index==selected: cv2.rectangle(canvas,(x1,height),(x2-1,height+42),SELECT_GRAY,-1)
        label_size=cv2.getTextSize(label,cv2.FONT_HERSHEY_SIMPLEX,0.45,1)[0]
        value_size=cv2.getTextSize(value,cv2.FONT_HERSHEY_SIMPLEX,0.53,1)[0]
        cv2.putText(canvas,label,(x1+round((column_width-label_size[0])/2),height+17),cv2.FONT_HERSHEY_SIMPLEX,0.45,WHITE,1,cv2.LINE_AA)
        cv2.putText(canvas,value,(x1+round((column_width-value_size[0])/2),height+38),cv2.FONT_HERSHEY_SIMPLEX,0.53,GREEN if index==selected else WHITE,1,cv2.LINE_AA)

    instructions="Drag red corners   Left/Right select   =/- adjust   Shift +/- x10   R reset   S save   Q/Esc quit"
    cv2.putText(canvas,instructions,(8,height+57),cv2.FONT_HERSHEY_SIMPLEX,0.40,WHITE,1,cv2.LINE_AA)
    return canvas

def save_wells(points,rows,columns,radius):
    corners=order_corners(points)
    wells=interpolate_grid(corners,rows,columns)
    OUTPUT_CSV.parent.mkdir(parents=True,exist_ok=True)
    with OUTPUT_CSV.open("w",newline="",encoding="utf-8") as file:
        writer=csv.writer(file)
        writer.writerow(["well","number","row","column","xc","yc","radius","diameter"])
        for number,(row,column,x,y) in enumerate(wells):
            writer.writerow([well_name(row,column),number,row+1,column+1,round(x),round(y),round(radius),round(radius*2)])
    print(f"Saved {len(wells)} wells to {OUTPUT_CSV}")

def change_value(selected,direction,large,rows,columns,radius,frame_number,frame_count):
    multiplier=10 if large else 1
    if selected==0:
        rows=max(1,rows+direction*multiplier)
    elif selected==1:
        columns=max(1,columns+direction*multiplier)
    elif selected==2:
        radius=max(1.0,radius+direction*1.0*multiplier)
    elif selected==3:
        frame_number=min(frame_count,max(1,frame_number+direction*multiplier))
    return rows,columns,radius,frame_number

def main():
    files=list_images()
    first=cv2.imread(str(files[0]),cv2.IMREAD_COLOR)
    if first is None: raise FileNotFoundError(f"Could not read image: {files[0]}")

    image_height,image_width=first.shape[:2]
    points=initial_corners(image_width,image_height)
    rows=int(config.PLATE_ROWS)
    columns=int(config.PLATE_COLUMNS)
    radius=float(config.INITIAL_WELL_RADIUS)
    frame_number=1
    selected=0
    dragging=None

    def nearest_corner(x,y):
        distances=[(px-x)**2+(py-y)**2 for px,py in points]
        return int(np.argmin(distances))

    def mouse_callback(event,x,y,flags,param):
        nonlocal dragging
        if y>=image_height: return
        if event==cv2.EVENT_LBUTTONDOWN:
            dragging=nearest_corner(x,y)
            points[dragging]=[float(x),float(y)]
        elif event==cv2.EVENT_MOUSEMOVE and dragging is not None and flags&cv2.EVENT_FLAG_LBUTTON:
            points[dragging]=[float(x),float(y)]
        elif event==cv2.EVENT_LBUTTONUP:
            if dragging is not None: points[dragging]=[float(x),float(y)]
            dragging=None

    # AUTOSIZE keeps mouse coordinates aligned with image pixels.
    cv2.namedWindow(WINDOW_NAME,cv2.WINDOW_AUTOSIZE)
    cv2.setMouseCallback(WINDOW_NAME,mouse_callback)

    while True:
        image=cv2.imread(str(files[int(frame_number)-1]),cv2.IMREAD_COLOR)
        if image is None: raise FileNotFoundError(f"Could not read image: {files[int(frame_number)-1]}")
        if image.shape[:2]!=(image_height,image_width): raise ValueError("All source frames must have the same dimensions.")

        overlay=draw_overlay(image,points,rows,columns,radius)
        display=add_panel(overlay,selected,rows,columns,radius,int(frame_number),len(files))
        cv2.imshow(WINDOW_NAME,display)
        key=cv2.waitKeyEx(20)

        if key==-1: continue
        if key in QUIT_KEYS:
            cv2.destroyAllWindows()
            return
        if key in LEFT_KEYS:
            selected=(selected-1)%len(PARAMETERS)
        elif key in RIGHT_KEYS:
            selected=(selected+1)%len(PARAMETERS)
        elif key==ord("="):
            rows,columns,radius,frame_number=change_value(selected,+1,False,rows,columns,radius,frame_number,len(files))
        elif key==ord("-"):
            rows,columns,radius,frame_number=change_value(selected,-1,False,rows,columns,radius,frame_number,len(files))
        elif key==ord("+"):
            rows,columns,radius,frame_number=change_value(selected,+1,True,rows,columns,radius,frame_number,len(files))
        elif key==ord("_"):
            rows,columns,radius,frame_number=change_value(selected,-1,True,rows,columns,radius,frame_number,len(files))
        elif key in (ord("r"),ord("R")):
            points=initial_corners(image_width,image_height)
        elif key in (ord("s"),ord("S")):
            save_wells(points,rows,columns,radius)

if __name__=="__main__":
    try:
        main()
    except Exception as error:
        cv2.destroyAllWindows()
        print(f"Well Grid Tuner failed: {error}")
        raise SystemExit(1)
