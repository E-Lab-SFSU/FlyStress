#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
unset FLYSHAKER_DEMO
python main.py
