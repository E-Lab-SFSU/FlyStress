# Fly Shaker + CAMS integrated controller

Primary target: Raspberry Pi 5. A Windows demonstration mode is included so the GUI/workflow can be shown without the USB camera or ESP32.

## Workflow implemented

1. Settings window exposes only: images/second, frequency, amplitude, DUTY, sequence, SSilence, session, initiation.
2. Creates `~/FS_IMG/expXXXXX/frames/`.
3. Initiation images are captured into `frames/` for the requested initiation duration.
4. Runs the uploaded CAMS tools unchanged in this order: `well_grid_tuner.py`, `measure_activity.py`, `motion_threshold_tuner.py`.
5. Starts camera + shaker for the actual session.
6. Main preview shows the live camera feed. FREQ/AMP are polled from the live shaker CSV, whose values came from ESP output.
7. Every 300 *actual-experiment* images, CAMS `measure_activity.py` + `classify_sleep.py` are run and Sleep/Awake are updated. At 1 image/s, this is every 5 minutes.
8. A separate `sleep_data.csv` is appended without changing CAMS' own CSVs.
9. On experiment end: final activity/classification, `compare_first_last.py`, `generate_plots.py`, video creation via the uploaded `img_to_vid.py` function, and `image_shaker_alignment.csv` using a +/-3 second timestamp threshold.

## Raspberry Pi 5 setup

The CAMS tuners use OpenCV GUI windows, so the Pi should use an OpenCV build with HighGUI support. A reliable Raspberry Pi OS approach is:

```bash
sudo apt update
sudo apt install -y python3-venv python3-opencv libxcb-cursor0
python3 -m venv --system-site-packages .venv
source .venv/bin/activate
pip install -r requirements-pi.txt
./run_raspberry_pi.sh
```

Expected hardware paths remain `/dev/video0` for the USB camera and `/dev/ttyUSB0` for the ESP32, matching the uploaded reference scripts.

If serial permission is denied:

```bash
sudo usermod -aG dialout $USER
```

Then log out/reboot once.

## Windows demonstration

From PowerShell / Command Prompt in this folder:

```bat
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements-windows.txt
run_windows_demo.bat
```

Windows demo mode uses a synthetic 4x8 well-plate camera image and simulated shaker sequence reports. It still creates `expXXXXX`, `frames`, timestamp CSVs, and exercises the same GUI/controller flow. The CAMS tuner windows can be demonstrated with the synthetic frames.

## Important implementation notes

- The files in `cams/` are copied from the supplied CAMS archive and are not internally rewritten by this integration.
- `config_writer.py` changes only the CAMS experiment paths and image timing needed for each new experiment; all other CAMS settings remain from the supplied `activity_config.py`.
- `BURST(3,3)` and `BSILENCE(120,120)` remain the uploaded shakerTerminal defaults because they were intentionally omitted from the requested settings screen.
- `img_to_vid.py` does not contain a runnable `main`; it defines `create_video(...)`. The controller calls that supplied function at finalization.
- Periodic 300-image CAMS updates recompute activity across the frames currently present because the existing `measure_activity.py` is a full-dataset processor. This preserves CAMS code unchanged at the cost of extra computation on long experiments.
